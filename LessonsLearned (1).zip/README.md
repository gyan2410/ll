# International Finance Corporation - Lessons Learned (CSO) Application

## Devloper Installation
High level instructions for provisioning a CSO development environment

1. Install Required Applications
    * Git for Windows
    * Visual Studio Code (may first need uninstallation by administrator)
    * NodeJS 16.19.0
    * Fiddler
        * POST INSTALLATION INSTRUCTIONS
        * ***IMPORTANT*** To decrypt HTTPS traffic Fiddler needs to install a root certificate. Admin rights are required. Make sure to get a temporary local admin password from IT Support.
        * Open Fiddler, Go to Tools -> Options
        * In the options menu Click on the HTTPS tab
        * Check the box Decrypt HTTPS traffic
            * Several dialgos will appear click yes to all to install the Fiddler Root Certificate to your machine
            * When prompted enter the provided temporary admin credentials.
        * ***IMPORTANT*** After installing the root certificate make sure that you click on Skip decryption for... link and make sure it says Perform decryption only for. Failure to do so will result in you creating certificates for every site you visit with HTTPS. Please make sure to perform this step.
    * SharePoint Designer 2013 (Latest build and patches. You may need to perform a regedit modification to connect to SPO. Link here: https://learn.microsoft.com/en-us/sharepoint/troubleshoot/sharing-and-permissions/login-issues-in-a-cloud-scenario)
2. From a command prompt Clone the CSO repository make sure you are on the main branch
    ```shell
    git clone <REPO HTTPS URL>
    ```
3. From Command Prompt (CMD)
    ```shell
    npm i -g @angular/cli
    ```
4. From project repository (again using CMD)
    ```shell
    npm i
    ```

5. Configure Fiddler Script to handle CORS.  Paste this logic into the specified functions. Run Fiddler in the background for localhost debugging
    * Fiddler Settings
        * Open Fiddler, Go to Tools -> Options
        * In the options menu Click on HTTPS tab
        * In the text box for Perform decryption only for... enter the following urls
            * spsec.ifc.org
            * spsecqa.ifc.org
            * spsecnqa.ifc.org
            * ifcsearchapi.ifc.org
            * tab.worldbank.org
            * apigwtst.ifc.org
            * worldbankgroup.sharepoint.com
        * Close Fiddler Settings
    * Click on the FiddlerScript tab in the Fiddler right pane.
    * From the dropdown select the matching function named below and paste the rules below in the approriate functions.
    * Please note, you will need to grab your request cookie via Chrome Developer Tools and replace the text below: GET YOUR COOKIE FROM A WORKING SHAREPOINT REQUEST.
    * With developer tools open click on any request for a SPO asset, index.aspx for example, in the request headers copy the cookie. Paste in the section below.
    * OnBeforeRequest()
    ```javascript
        if(oSession.uriContains('tabqa.worldbank.org')) {
            oSession.oRequest.headers["Origin"] = "https://tabqa.worldbank.org/";
            if(oSession.HTTPMethodIs("OPTIONS")) {
                oSession.utilCreateResponseAndBypassServer();
                oSession.responseCode = 200;
            }
        }
        if(oSession.oRequest.headers['Origin'] == "http://localhost:4200" && oSession.uriContains('ifc-cso-docgen-dev.cit-ouo-ase-asev3-dev.appserviceenvironment.net')) {
            if(oSession.HTTPMethodIs("OPTIONS")) {
                oSession.utilCreateResponseAndBypassServer();
                oSession.responseCode = 200;
            }
        }
        if(oSession.oRequest.headers['Origin'] == "http://localhost:4200" && oSession.uriContains('worldbankgroup.sharepoint.com')) {
            oSession.oRequest.headers["Origin"] = "https://worldbankgroup.sharepoint.com/";
            oSession["X-AutoAuth"] = "(default)";
            oSession.oRequest["Cookie"] = 'GET YOUR COOKIE FROM A WORKING SHAREPOINT REQUEST'
            if(oSession.HTTPMethodIs("OPTIONS")) {
                oSession.utilCreateResponseAndBypassServer();
                oSession.responseCode = 200;
            }
        }
    ```

    * OnBeforeResponse()
    ```javascript
        //OnBeforeResponse Custom Rules
        if(oSession.uriContains('spsec.ifc.org') || 
            oSession.uriContains('api1.ifc.org') || 
            oSession.uriContains('ifcpasskey.ifc.org') || 
            oSession.uriContains('tabqa.worldbank.org') || 
            oSession.uriContains('spsecqa.ifc.org') || 
            oSession.uriContains('worldbankgroup.sharepoint.com') ||
            oSession.uriContains('ifc-cso-docgen-dev.cit-ouo-ase-asev3-dev.appserviceenvironment.net')) {
            oSession.oResponse["Access-Control-Allow-Origin"] = "http://localhost:4200";
            oSession.oResponse["Access-Control-Allow-Credentials"] = true;
            oSession.oResponse["Access-Control-Allow-Methods"] = "POST, GET, OPTIONS, DELETE";
            oSession.oResponse["Access-Control-Allow-Headers"] = "Origin, Content-Type, Accept, X-RequestDigest, IF-MATCH, X-HTTP-METHOD, X-Tableau-Auth, x-requested-with, SharePointError";
        }
        
        if(oSession.uriContains('ifc.org') ) { 
            oSession["ui-color"] = "blue";
        }
    ```
6. To run locally. Open a command prompt to the CSO clone directory. Execute the following command.
    ```shell
    ng serve
    ```
    (cserve = clean serve)
7. Open http://localhost:4200 from the browser

