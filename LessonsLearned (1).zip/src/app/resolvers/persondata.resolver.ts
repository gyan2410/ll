import { Injectable } from '@angular/core';
import {
  Router, Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';
import { concatMap, map, Observable, of, tap } from 'rxjs';
import { SharePointService } from '../services/sharepoint.service';
import { SharePointDataService } from '../services/sharepointdata.service';

@Injectable({
  providedIn: 'root'
})
export class PersonDataResolver implements Resolve<any> {

  constructor(private spService: SharePointService, private spDataService: SharePointDataService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    return this.spDataService.whoAmI().pipe(concatMap(spUser => {
      return this.spDataService.getUserDataFromSearch(spUser.UPI).pipe(map(wbUserResult => {
        let total = parseInt(wbUserResult.total, 10);
        let wbUser = (total > 0) ? wbUserResult.peoples[Object.keys(wbUserResult.peoples)[0]] : {};
        return {
          spUser,
          wbUser
        }
      }))
    }))
  }
}
