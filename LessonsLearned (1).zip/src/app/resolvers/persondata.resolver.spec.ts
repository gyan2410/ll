import { TestBed } from '@angular/core/testing';

import { PersonDataResolver } from './persondata.resolver';

describe('PersondataResolver', () => {
  let resolver: PersonDataResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(PersonDataResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
