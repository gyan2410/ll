import { TestBed } from '@angular/core/testing';

import { RenderLessonResolver } from './renderlesson.resolver';

describe('RenderlessonResolver', () => {
  let resolver: RenderLessonResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(RenderLessonResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
