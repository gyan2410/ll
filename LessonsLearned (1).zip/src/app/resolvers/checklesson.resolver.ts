import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot, Resolve,
  RouterStateSnapshot
} from '@angular/router';
import { Observable } from 'rxjs';
import { DatacontextService } from '../services/datacontext.service';

@Injectable({
  providedIn: 'root'
})
export class CheckLessonResolver implements Resolve<any> {
  constructor(private dataContext: DatacontextService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    let projectId = route.params['id'];
    let accessibility = route.params['type'];
    return this.dataContext.checkId(projectId, accessibility);
  }
}
