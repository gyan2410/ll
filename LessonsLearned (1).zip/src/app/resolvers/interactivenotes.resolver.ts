import { Injectable } from '@angular/core';
import {
  Router, Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';
import { map, Observable, of } from 'rxjs';
import { LessonsLearnedService } from '../services/lessonslearned.service';
import { InteractionNote } from '../../types/InteractionNote';
import { FormDataService } from '../services/formdata.service';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class InteractiveNotesResolver implements Resolve<Array<InteractionNote>> {

  constructor(private lessonService: LessonsLearnedService, private formData: FormDataService, private sanitizer: DomSanitizer) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Array<InteractionNote>> {
    return this.lessonService.getInteractionNotes().pipe(
      map(interactionNotes => {
        interactionNotes.forEach((interactionNote) => {
          if(!this.formData.data.interactionData) {
            this.formData.data.interactionData = {};
          }
          if(!this.formData.data.interactionData[interactionNote.Section]) {
            this.formData.data.interactionData[interactionNote.Section] = {};
          }
          this.formData.data.interactionData[interactionNote.Section][interactionNote.Title] = this.sanitizer.bypassSecurityTrustHtml(interactionNote.InteractionNote);
        });
        return interactionNotes;
      })
    )
  }
}
