import { TestBed } from '@angular/core/testing';

import { CheckLessonResolver } from './checklesson.resolver';

describe('ChecklessonResolver', () => {
  let resolver: CheckLessonResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(CheckLessonResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
