import { TestBed } from '@angular/core/testing';

import { InteractiveNotesResolver } from './interactivenotes.resolver';

describe('InteractivenotesResolver', () => {
  let resolver: InteractiveNotesResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(InteractiveNotesResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
