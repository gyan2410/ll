import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot, Resolve,
  RouterStateSnapshot
} from '@angular/router';
import { Observable } from 'rxjs';
import { DatacontextService } from '../services/datacontext.service';

@Injectable({
  providedIn: 'root'
})
export class RenderLessonResolver implements Resolve<boolean> {
  constructor(private dataContext: DatacontextService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    let projectId = route.params['id'];
    let accessibility = route.params['type'];
    return this.dataContext.readProject(projectId, accessibility);
  }
}
