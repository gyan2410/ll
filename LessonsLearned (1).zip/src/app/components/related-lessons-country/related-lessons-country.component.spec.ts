import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatedLessonsCountryComponent } from './related-lessons-country.component';

describe('RelatedLessonsCountryComponent', () => {
  let component: RelatedLessonsCountryComponent;
  let fixture: ComponentFixture<RelatedLessonsCountryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RelatedLessonsCountryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RelatedLessonsCountryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
