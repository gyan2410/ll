import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { GoogleMap, MapInfoWindow, MapMarker } from '@angular/google-maps';
import * as GoogleMapsLoader from 'google-maps';
import { catchError, map, Observable, of, take, tap } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { SharePointService } from 'src/app/services/sharepoint.service';
import { UtilitiesService } from 'src/app/services/utilities.service';
import { CountryCoordinate } from 'src/types/CountryCoordinate';
import { SPSearchResultItem } from 'src/types/SPSearch';

@Component({
  selector: 'app-related-lessons-country',
  templateUrl: './related-lessons-country.component.html',
  styleUrls: ['./related-lessons-country.component.scss']
})
export class RelatedLessonsCountryComponent implements OnInit {
  @ViewChild('googleMap') googleMap!: GoogleMap;
  @ViewChild('mapInfoWindow') mapInfoWindow!: MapInfoWindow;
  apiLoaded!: Observable<any>;
  countryData!: Array<CountryCoordinate>;
  latLongArray: { [key: string]: number } = {};
  renderType!: string;
  sector = "primary";
  center: google.maps.LatLngLiteral = { lat: 20.0, lng: -1 };
  zoom: number = 1;
  relatedLessons!: SPSearchResultItem[];
  displayLessons!: SPSearchResultItem[];
  lessonSector!: string;

  constructor(private fdSvc: FormDataService, private spService: SharePointService, private utilService: UtilitiesService, private httpClient: HttpClient) { }

  ngOnInit(): void {
    let currForm = this.fdSvc.data.formData;
    this.lessonSector = this.fdSvc.data.formData.lessonSector || '';
    this.renderType = currForm.accessibility;
    this.apiLoaded = this.spService.mapAPILoadedObs$;
    this.spService.getListItems<Array<CountryCoordinate>>('CountryCoordinates', { $top: 275, $select: 'Title,Latitude,Longitude' }).pipe(take(1))
      .subscribe(result => {
        this.countryData = result;
        this.changeLessonTab(0);
      });
  }

  getCountryLatLong(countryName: string) {
    return this.countryData.filter(currCountry => {
      return currCountry.Title === countryName;
    })
  }

  getLatLongCounts(lesson: SPSearchResultItem) {
    let latlongId: string = lesson.LessonLatitude + lesson.LessonLongitude;
    if (!this.latLongArray.hasOwnProperty(latlongId)) {
      this.latLongArray[latlongId] = 1;
    } else {
      this.latLongArray[latlongId] += 1;
    }
  }

  setLessonLatLong(lesson: SPSearchResultItem) {
    if (lesson.RefinableStringFirst26) {
      var lessonCoorData = this.getCountryLatLong(lesson.RefinableStringFirst26);
      if (lessonCoorData.length) {
        lesson.LessonLatitude = lessonCoorData[0].Latitude;
        lesson.LessonLongitude = lessonCoorData[0].Longitude;
        this.getLatLongCounts(lesson);
      }
    }
  }

  getLessonFilter(index: number) {
    let projData = this.fdSvc.data.formData;
    let filterObject: any = {};
    if (index === 0) {
      filterObject.RefinableStringFirst26 = projData.lessonCountry;
    } else if (index === 1) {
      switch (this.sector) {
        case 'tertiary':
          filterObject.RefinableStringFirst27 = projData.lessonSector?.substring(0, 4);
          break;
        case 'secondary':
          filterObject.RefinableStringFirst27 = projData.lessonSector?.substring(0, 3) + '*';
          break;
        default:
          filterObject.RefinableStringFirst27 = projData.lessonSector?.substring(0, 2);
          break;
      }
      console.log(filterObject);
    }

    var listName = (this.renderType === 'internal') ? 'lessonslearned/' : 'lessonslearnedofficial/';
    filterObject.Path = this.utilService.siteCollectionUrl('/lists/' + listName);
    return filterObject;
  }

  Number(val: string | undefined) {
    if (val === undefined) {
      return 0
    }

    return Number(val);
  }

  getLessonData(index: number) {
    this.spService.getSearchData('', this.getLessonFilter(index), 50).pipe(take(1)).subscribe(results => {
      if (results) {
        this.relatedLessons = results.items;
        this.relatedLessons.forEach(lesson => {
          this.setLessonLatLong(lesson);
        })
      }
    })
  }

  changeLessonTab(index: number) {
    this.latLongArray = {};
    let coords = this.getCountryLatLong(this.fdSvc.data.formData.lessonCountry || '');
    if (index === 0 && coords.length) {
      this.center = { lat: Number(coords[0].Latitude), lng: Number(coords[0].Longitude) };
      this.zoom = 4;
    } else {
      this.center = { lat: 20, lng: -1 };
      this.zoom = 1;
    }
    this.getLessonData(index);
  }

  openInfoWindow(marker: MapMarker, lesson: SPSearchResultItem) {
    this.displayLessons = this.relatedLessons.filter((item) => {
      return item.RefinableStringFirst26 === lesson.RefinableStringFirst26;
    })
    this.mapInfoWindow.open(marker);
  }
}
