import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxonomySelectListComponent } from './taxonomy-select-list.component';

describe('TaxonomySelectListComponent', () => {
  let component: TaxonomySelectListComponent;
  let fixture: ComponentFixture<TaxonomySelectListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaxonomySelectListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TaxonomySelectListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
