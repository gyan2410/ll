import { Component, Input, OnInit } from '@angular/core';
import { catchError, map, Observable, of, take } from 'rxjs';
import { TaxonomyService } from 'src/app/services/taxonomy.service';
import { SPTerm } from 'src/types/SPTaxonomy';

@Component({
  selector: 'app-taxonomy-select-list',
  templateUrl: './taxonomy-select-list.component.html',
  styleUrls: ['./taxonomy-select-list.component.scss']
})
export class TaxonomySelectListComponent implements OnInit {
  @Input() termSetId: string = '';
  @Input() storageArray!: Array<any>;
  termObs$!: Observable<Array<SPTerm>>;
  error = false;

  constructor(private taxService: TaxonomyService) { }

  ngOnInit(): void {
    if (this.termSetId) {
      this.termObs$ = this.taxService.getAllTerms(this.termSetId).pipe(
        map(taxonomy => taxonomy.flatTaxonomy)),
        catchError(() => {
          this.error = true;
          return of([]);
        })
    }
  }

  findIndex(value: SPTerm) {
    return this.storageArray.findIndex(item => {
      return item.id === value.id;
    })
  }

  toggle(item: SPTerm) {
    var idx = this.findIndex(item);
    idx > -1 ? this.storageArray.splice(idx, 1) : this.storageArray.push({ id: item.id, defaultLabel: item.defaultLabel });
  }
}
