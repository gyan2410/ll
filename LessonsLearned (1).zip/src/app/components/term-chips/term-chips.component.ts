import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent, MatChipList, MatChipSelectionChange } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { Observable, startWith, map, take } from 'rxjs';
import { AppMetaDataField } from 'src/types/AppData';
import { SPTerm } from 'src/types/SPTaxonomy';

@Component({
  selector: 'app-term-chips',
  templateUrl: './term-chips.component.html',
  styleUrls: ['./term-chips.component.scss']
})
export class TermChipsComponent implements OnInit {
  @Input() flatTerms!: Array<SPTerm>;
  @Input() levelTerms!: Array<SPTerm>;
  @Input() value!: Array<AppMetaDataField>;
  @Input() fieldLabel = '';

  @Output() termAdded = new EventEmitter<AppMetaDataField>();
  @Output() termRemoved = new EventEmitter<any>();
  @Output() termSelected = new EventEmitter<any>();
  separatorKeysCodes: number[] = [ENTER, COMMA];
  termCtrl = new FormControl<string>('');
  filteredTerms: Observable<SPTerm[]>;
  selectedTerms!: Array<AppMetaDataField>;
  @ViewChild('chipList') chipList!: MatChipList;
  @ViewChild('termInput') termInput!: ElementRef<HTMLInputElement>;
  @ViewChild('termExplorerDialog') termExplorerDialog!: TemplateRef<HTMLElement>;
  removedTerms: Array<AppMetaDataField> = [];
  addedTerms: Array<AppMetaDataField> = [];

  constructor(private matDialogt: MatDialog) {
    this.filteredTerms = this.termCtrl.valueChanges.pipe(
      startWith(''),
      map((searchTerm: string | null) => (searchTerm ? this._filter(searchTerm) : this.flatTerms.slice())),
    );
  }

  ngOnInit(): void {
    console.log('levelTerms:', this.levelTerms);
    console.log('flatTerms: ', this.flatTerms);
    console.log('value: ', this.value);
  }

  remove(term: AppMetaDataField): void {
    const index = this.value.indexOf(term);
    if (index >= 0) {
      this.value.splice(index, 1);
      this.termRemoved.emit({ index, term });
    }
  }

  chipClicked(index: number, term: AppMetaDataField) {
    this.chipList.chips.get(index)?.select();
    this.termSelected.emit({ index, term });
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    let newVal = event.option.value;
    let newChip = this.transformChip(newVal);
    if (!this.value.some(val => val.id === newChip.id)) {
      this.value.push(newChip);
      this.termAdded.emit(newChip);
    }
    this.termInput.nativeElement.value = '';
    this.termCtrl.setValue(null);
  }

  private _filter(searchTerm: string): SPTerm[] {
    if (!searchTerm || typeof searchTerm !== 'string') {
      return this.flatTerms;
    }

    const filterValue = searchTerm.toLowerCase();
    return this.flatTerms.filter(spTerm => spTerm.defaultLabel.toLowerCase().includes(filterValue));
  }

  transformChip(chip: SPTerm) {
    let newChip: AppMetaDataField = {
      defaultLabel: chip.defaultLabel,
      parentName: chip.parentTerm ? chip.parentTerm : '',
      id: chip.id
    };
    return newChip;
  }

  openTermSelection() {
    this.selectedTerms = this.value.slice();
    this.removedTerms = [];
    this.addedTerms = [];
    this.matDialogt.open(this.termExplorerDialog, {
      minWidth: '75%'
    }).afterClosed().pipe(take(1)).subscribe(result => {
      if (result) {
        this.addedTerms.forEach(addTerm => {
          if (this.value.indexOf(addTerm) === -1) {
            this.value.push(addTerm);
            this.termAdded.emit(addTerm);
          }
        })
        this.removedTerms.forEach(removeTerm => {
          this.remove(removeTerm);
        })
      }
    })
  }

  expandChildren(term: SPTerm) {
    term.expanded = !term.expanded;
  }

  addTerm(term: SPTerm) {
    var chip = this.transformChip(term);
    var identical = this.selectedTerms.some((item) => {
      return  JSON.stringify(chip) === JSON.stringify(item);
    });
    if (identical) return;
    this.selectedTerms.push(chip);
    this.addedTerms.push(chip);
  }

  removeTerm(index: number) {
    let removedTerm = this.selectedTerms.splice(index, 1)[0];
    let afIdx = this.addedTerms.indexOf(removedTerm);
    if (afIdx >= 0) {
      this.addedTerms.splice(afIdx, 1);
    }
    this.removedTerms.push(removedTerm);
  }
}
