import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermChipsComponent } from './term-chips.component';

describe('TermChipsComponent', () => {
  let component: TermChipsComponent;
  let fixture: ComponentFixture<TermChipsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TermChipsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TermChipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
