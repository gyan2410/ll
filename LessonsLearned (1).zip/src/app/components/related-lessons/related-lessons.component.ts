import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { GoogleMap, MapInfoWindow, MapMarker } from '@angular/google-maps';
import { MatTabChangeEvent } from '@angular/material/tabs';
import 'jquery';
import { forkJoin, map, Observable, of, shareReplay, switchMap, take } from 'rxjs';
import 'slick-carousel';
import { AppconstantsService } from 'src/app/services/appconstants.service';
import { FormDataService } from 'src/app/services/formdata.service';
import { LessonsLearnedService } from 'src/app/services/lessonslearned.service';
import { SharePointService } from 'src/app/services/sharepoint.service';
import { UtilitiesService } from 'src/app/services/utilities.service';
import { SPSearchResultItem } from 'src/types/SPSearch';

@Component({
  selector: 'app-related-lessons',
  templateUrl: './related-lessons.component.html',
  styleUrls: ['./related-lessons.component.scss']
})
export class RelatedLessonsComponent implements OnInit {
  @Input('groupSize') groupSize: number = 4;
  @ViewChild('googleMap') googleMap!: GoogleMap;
  @ViewChild('mapInfoWindow') mapInfoWindow!: MapInfoWindow;
  @ViewChild('lessonItemsContainer') LessonItemsContainer!: ElementRef;
  apiLoaded!: Observable<any>;
  buttonsWidth!: number;
  countriesCoordinateData: any;
  countryDataObs$!: Observable<Array<any>>;
  dataForm: any
  latLongArray: any = {};
  lessonItems: Array<Array<any>> = [];
  lessonPage!: number;
  loading = true;
  outcomesSPCol = this.appCons.columns.workoutOutcomes.spColumnMap;
  queryAmount = 250;
  recoveryStratSPCol = this.appCons.columns.recoveryStrategies.spColumnMap;
  relatedLessons: Array<any> = [];
  relatedQueries!: Array<any>;
  renderType!: string;
  riskFactorsSPCol = this.appCons.columns.riskFactors.spColumnMap;
  selectedIndex = 0;

  constructor(private appCons: AppconstantsService, private fdSvc: FormDataService, private spService: SharePointService, private lessonsService: LessonsLearnedService, private utils: UtilitiesService) { }

  ngOnInit(): void {

    this.dataForm = this.fdSvc.data.formData;
    this.renderType = this.dataForm.accessibility;
    this.relatedQueries = Array(
      {
        name: 'By Risks',
        spField: this.appCons.columns.riskFactors.spColumnMap,
        searchField: this.appCons.columns.riskFactors.spManagedProp,
        dataSource: 'riskFactors',
        olessons: []
      },
      {
        name: 'By Strategies',
        spField: this.appCons.columns.recoveryStrategies.spColumnMap,
        searchField: this.appCons.columns.recoveryStrategies.spManagedProp,
        dataSource: 'recoveryStrategies',
        olessons: []
      },
      {
        name: 'By Outcomes',
        spField: this.appCons.columns.workoutOutcomes.spColumnMap,
        searchField: this.appCons.columns.workoutOutcomes.spManagedProp,
        dataSource: 'workoutOutcomes',
        olessons: []
      },
      {
        name: 'By Country',
        spField: this.appCons.columns.lessonCountry.spColumnMap,
        searchField: this.appCons.columns.lessonCountry.spManagedProp,
        dataSource: 'lessonCountry',
        olessons: []
      },
      {
        name: 'By Sector',
        spField: this.appCons.columns.lessonSector.spColumnMap,
        searchField: this.appCons.columns.lessonSector.spManagedProp,
        dataSource: 'lessonSector',
        olessons: []
      },
      {
        name: 'By Region',
        spField: this.appCons.columns.lessonRegion.spColumnMap,
        searchField: this.appCons.columns.lessonRegion.spManagedProp,
        dataSource: 'lessonRegion',
        olessons: []
      });
    this.relatedQueries.forEach((item, index) => {
      let dataFormValue = this.dataForm[this.relatedQueries[index].dataSource];
      this.relatedQueries[index].searchFilters = (Array.isArray(dataFormValue)) ? dataFormValue.map((taxonomyItem) => {
        return { enabled: true, value: taxonomyItem.defaultLabel, id: '#0' + taxonomyItem.id, count: 0 }
      }) : Array({ enabled: true, value: dataFormValue, id: dataFormValue, count: 0 });
      this.relatedQueries[index].searchFilterArray = (Array.isArray(dataFormValue)) ? dataFormValue.map((taxonomyItem) => {
        return taxonomyItem.defaultLabel
      }) : Array(dataFormValue);
    });
    console.log(this.relatedQueries);
    this.countryDataObs$ = this.spService.getListItems('CountryCoordinates', { '$top': 275, '$select': 'Title,Latitude,Longitude' }).pipe(shareReplay(1));
    this.apiLoaded = this.spService.mapAPILoadedObs$;
    this.changeLessonTab(0);
  }

  getLessonFilter(index: number) {
    var lessonFilter = this.relatedQueries[index].searchFilters.filter((filter: any) => {
      return filter.enabled;
    }).map((filter: any) => {
      return filter.id;
    });
    let filterObject: any = {};
    if (!lessonFilter.length) {
      return null;
    }
    filterObject[this.relatedQueries[index].searchField] = lessonFilter;
    let listName = (this.renderType === 'internal') ? 'lessonslearned' : 'lessonslearnedofficial';
    filterObject.Path = this.utils.siteCollectionUrl(`/lists/${listName}/`);
    console.log('filterobject', filterObject);
    return filterObject;
  }

  getLessonsAtLatLong(lat: number, long: number) {
    return this.relatedQueries[this.selectedIndex].olessons.filter((item: any) => {
      return item.LessonLatitude === lat && item.LessonLongitude === long;
    });
  }

  setLatLongCounts(lesson: SPSearchResultItem) {
    var latlongId = lesson.LessonLatitude + lesson.LessonLongitude;
    if (!this.latLongArray.hasOwnProperty(latlongId)) {
      this.latLongArray[latlongId] = 1;
    } else {
      this.latLongArray[latlongId] += 1;
    }
  }

  setCountryLatLong(lesson: SPSearchResultItem) {
    var cIndex = -1;
    var found = this.countriesCoordinateData.some((currCountry: any, index: number) => {
      cIndex = index;
      return currCountry.Title === lesson.LessonCountry;
    });
    if (found) {
      // $log.log('CountryFound: ', vm.countriesCoordinateData[cIndex], lesson.LessonCountry);
      lesson.LessonLatitude = this.countriesCoordinateData[cIndex].Latitude;
      lesson.LessonLongitude = this.countriesCoordinateData[cIndex].Longitude;
      this.setLatLongCounts(lesson);
    }
  }

  flattenMetadata(metaArray: Array<any>) {
    return metaArray.map((metaValue) => {
      return metaValue.Label;
    })
  }

  changeLessonTab(index: number) {
    // reset filter checkboxes to be enabled
    this.relatedQueries[index].searchFilters.forEach((filter: any) => {
      filter.enabled = true;
    });
    this.getRelatedLesson(index);
  }

  getRelatedLessonData(index: number): Observable<any> {
    var filterObject = this.getLessonFilter(index);
    if (filterObject === null) {
      return of([]);
    } else {
      return this.spService.getSearchData('', filterObject, this.queryAmount).pipe(
        map((searchItems: any) => {
          console.log('searchItems: ', searchItems);

          if (searchItems) {
            let promises: Array<Observable<any>> = [];
            searchItems.items.forEach((item: any) => {
              var listName = (this.renderType === 'internal') ? this.appCons.listNames.lessonsLearned : this.appCons.listNames.lessonsLearnedOfficial;
              var promise = this.lessonsService.findExistingLessonLearned(listName, item.Title, { '$select': 'Title,OData__ModerationStatus,LessonTitle,LessonSnippet,LessonPreviewImageUrl,LessonCountry,LessonRegion,LessonSector,LessonWeight,LegacyLesson,' + this.riskFactorsSPCol + ',' + this.recoveryStratSPCol + ',' + this.outcomesSPCol });
              promises.push(promise);
            });
            return promises;
          } else {
            return of([]);
          }
        }))
    }
  }

  getRelatedLesson(index: number) {
    console.log('running related lessons');
    this.lessonPage = 1;
    this.loading = true;
    this.latLongArray = {};
    // reset retrieve lessons
    this.lessonItems.length = 0;
    this.relatedQueries[index].olessons.length = 0;
    this.relatedQueries[index].searchFilters.forEach((filter: any) => {
      filter.count = 0;
    });
    jQuery('.ifc-lessons-learned-items').off();
    jQuery('.ifc-lessons-learned-items.slick-initialized').slick('unslick');

    this.countryDataObs$.pipe(
      switchMap(countryCoordinates => {
        this.countriesCoordinateData = countryCoordinates;
        return this.getRelatedLessonData(index).pipe(
          switchMap(lessonPromises => {
            if (lessonPromises.length === 0) {
              return of([]);
            }

            return forkJoin(lessonPromises).pipe(map(results => {
              return results as Array<any>;
            }))
          }))
      })
    ).pipe(take(1)).subscribe((lessons: Array<any>) => {
      console.log('Lessons: ', lessons);
      lessons.forEach((lesson, i) => {
        if (lesson.LessonCountry) {
          this.setCountryLatLong(lesson);
        }
        lesson.LessonPreviewImageUrl = (lesson.LessonPreviewImageUrl) ? this.utils.hostUrl() + lesson.LessonPreviewImageUrl.replace(' ', '%20') : '';
        lesson.visible = i < this.groupSize;
        var currFilterField = this.relatedQueries[index].spField;
        var results = (lesson[currFilterField].results) ? lesson[currFilterField].results : Array({ Label: lesson[currFilterField] });
        results.forEach((itemFilterValue: any) => {
          var filterValueIndex = this.relatedQueries[index].searchFilterArray.indexOf(itemFilterValue.Label);
          if (filterValueIndex >= 0) {
            this.relatedQueries[index].searchFilters[filterValueIndex].count++;
          }
        });
      });
      this.relatedQueries[index].searchFilters.forEach((filter: any) => {
        filter.total = filter.count;
      });
      this.relatedQueries[index].olessons = lessons;
      console.log('relatedQueries: ', this.relatedQueries);
      this.lessonItems = this.chunkData(this.relatedQueries[index].olessons, this.groupSize || 2);
      this.loading = false;
      this.buttonsWidth = this.lessonItems.length * 30;
      setTimeout(() => {
        if (this.relatedQueries[this.selectedIndex].olessons.length > 0) {
          jQuery('.ifc-lessons-learned-items.slick-initialized').slick('unslick');
          let slickElem = jQuery('.ifc-lessons-learned-items');
          slickElem.slick(this.sliderSettings());
          slickElem.on('beforeChange', this.onSlideChange.bind(this));
        }
      }, 100);
    })
  }

  chunkData(arr: Array<any>, size: number) {
    var newArr = [];
    for (var i = 0; i < arr.length; i += size) {
      newArr.push(arr.slice(i, i + size));
    }
    return newArr;
  }

  sliderSettings() {
    return {
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      dots: true,
      fade: false,
      appendDots: '.dotsContainer'
    };
  }

  slideLeft() {
    var page = this.lessonPage;
    var currPosition = (page - 1) * (30 * 5);
    var nextSlide = currPosition - (30 * 5);
    if (page === 1) {
      return;
    }
    jQuery('#ifc-lessons-learned .slick-dots').css("transform", "translateX(-" + nextSlide + "px)");
    this.lessonPage--;
  };

  slideRight() {
    var page = this.lessonPage;
    var nextSlide = page * (30 * 5);
    if (nextSlide >= this.buttonsWidth) {
      return;
    }
    jQuery('#ifc-lessons-learned .slick-dots').css("transform", "translateX(-" + nextSlide + "px)");
    this.lessonPage++;
  };

  onSlideChange(event: any, slick: any, currentSlide: number, nextSlide: number) {
    this.lessonItems[nextSlide].forEach((lessonItem) => {
      lessonItem.visible = true;
    });
  }

  toggleClass(event: Event) {
    jQuery(event.currentTarget as HTMLElement).toggleClass('expanded');
  }

  getPinColor(lesson: any) {
    return (lesson.LessonCountry.toLowerCase().indexOf('region') >= 0) ? '119002' : 'FE6256';
  }

  Number(val: string | undefined) {
    if (val === undefined) {
      return 0
    }

    return Number(val);
  }

  openInfoWindow(marker: MapMarker, lesson: any) {
    this.relatedLessons = this.getLessonsAtLatLong(lesson.LessonLatitude, lesson.LessonLongitude);
    this.mapInfoWindow.open(marker);
  }
}
