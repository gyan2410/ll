import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatedLessonsComponent } from './related-lessons.component';

describe('RelatedLessonsComponent', () => {
  let component: RelatedLessonsComponent;
  let fixture: ComponentFixture<RelatedLessonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RelatedLessonsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RelatedLessonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
