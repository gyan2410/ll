import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { map, take } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { IPortalDataService } from 'src/app/services/iportaldata.service';
import { PartnerDetails } from 'src/types/PartnerDetails';

@Component({
  selector: 'app-partnerdetails',
  templateUrl: './partnerdetails.component.html',
  styleUrls: ['./partnerdetails.component.scss']
})
export class PartnerdetailsComponent implements OnInit {
  @Input() editable!: boolean;
  @Input() formGroup!: FormGroup;
  cancelValues: any;
  clientId: number;
  clientProjects!: any[];
  editMode = false;
  errorText: string = '';
  loading = true;
  match = false;
  partnerInfo!: PartnerDetails;
  projectCache = {};
  projectId: string;
  selectedIndex = 0;
  csoStatuses = [
    { name: 'Joint Venture', code: 'J', display: 'CSO JV', icon: 'JV' },
    { name: 'Regular', code: 'Y', display: 'Yes', icon: 'Reg' },
    { name: 'Transferred Out to ID', code: 'T', display: 'Out of CSO/Transferred', icon: 'T' },
    { name: 'Out & Closed', code: 'O', display: 'Out of CSO/Closed', icon: 'O' },
    { name: 'Not CSO', code: 'N', display: 'No', icon: 'N' }
  ]

  constructor(private fdSvc: FormDataService, private iPortalDataService: IPortalDataService) {
    this.projectId = this.fdSvc.data.projectData.projectId;
    this.clientId = this.fdSvc.data.projectData.clientId;
    if (this.fdSvc.data.formData.iPortalData && this.fdSvc.data.formData.iPortalData.relatedProjects) {
      this.partnerInfo = this.fdSvc.data.formData.iPortalData;
      this.clientProjects = this.partnerInfo.relatedProjects;
      this.setDetailData();
    } else if (this.clientId != null) {
      this.getClientData(this.clientId.toString()).pipe(take(1)).subscribe();
    }
  }

  ngOnInit(): void {}

  getClientData(clientId: string) {
    return this.iPortalDataService.retrievePartnerData(clientId).pipe(
      map(result => {
        this.partnerInfo = result;
        this.clientProjects = this.partnerInfo.relatedProjects;
        this.fdSvc.data.formData.iPortalData = result;
        this.setDetailData();
      })
    )
  }

  setDetailData() {
    this.clientProjects.forEach((item, index) => {
      if (!this.match && item.projectId.toString() === this.projectId) {
        this.match = true;
        this.selectedIndex = index + 1;
        if (!this.fdSvc.data.formData.investmentTeam) {
          this.fdSvc.data.formData.investmentTeam = {} as any;
        }
        if (!this.fdSvc.data.formData.investmentTeam.primaryIONB) {
          this.fdSvc.data.formData.investmentTeam.primaryIONB = item.primaryIONewBusiness;
          if (this.editable) {
            this.formGroup.controls['primaryIONB'].setValue(item.primaryIONewBusiness);
          }
        }
        if (!this.fdSvc.data.formData.investmentTeam.primaryIOP) {
          this.fdSvc.data.formData.investmentTeam.primaryIOP = item.primaryIOPortfolio;
          if (this.editable) {
            this.formGroup.controls['primaryIOP'].setValue(item.primaryIOP);
          }
          
        }
      }
      if (typeof item.csoStartDate === 'string') {
        item.csoStartDate = new Date(item.csoStartDate);
      }
      if (typeof item.csoEndDate === 'string') {
        item.csoEndDate = new Date(item.csoEndDate);
      }
    })
    if (!this.fdSvc.data.formData.investmentTeam.regionalHead) {
      this.fdSvc.data.formData.investmentTeam.regionalHead = this.partnerInfo.team.regionalHead;
      if (this.editable) {
        this.formGroup.controls['regionalHead'].setValue(this.partnerInfo.team.regionalHead);
      }
    }
    if (!this.fdSvc.data.formData.investmentTeam.globalHead) {
      this.fdSvc.data.formData.investmentTeam.globalHead = this.partnerInfo.team.globalHead;
      if (this.editable) {
        this.formGroup.controls['globalHead'].setValue(this.partnerInfo.team.globalHead);
      }
    }
    if (!this.fdSvc.data.formData.investmentTeam.portfolioIO) {
      this.fdSvc.data.formData.investmentTeam.portfolioIO = this.partnerInfo.team.portfolioIO;
    }
    if (!this.fdSvc.data.formData.investmentTeam.creditOfficer) {
      this.fdSvc.data.formData.investmentTeam.creditOfficer = this.partnerInfo.team.creditOfficer;
      if (this.editable) {
        this.formGroup.controls['creditOfficer'].setValue(this.partnerInfo.team.creditOfficer);
      }
    }
    this.loading = false;
  }

  convertCurrency(amount: number) {
    if ((typeof amount === 'undefined') || amount === null) {
      return 'Not returned'
    }
    if (amount === 0) {
      return "$0"
    }

    var digits = 3;
    var suffix = ["", "K", "M", "B"];

    var nbDigits = Math.log(amount) / Math.LN10;
    var power = nbDigits - nbDigits % 3;

    var tmp = amount / Math.pow(10, power);
    var suffixIndex = Math.min(3, power / 3);

    var result = "$" + tmp.toFixed(digits) + " " + suffix[suffixIndex];
    return result;
  }

  csoStatusIcon(csoStatus: string) {
    var r = this.findStatus(csoStatus);
    return (r) ? r.icon : 'AS';
  };

  findStatus(code: string) {
    let csoStatus = this.csoStatuses.find(csoStatus => csoStatus.code === code);
    return csoStatus || null;
  }

  setProjectStatus(event: Event) {
    var selectedCode = (event.target as HTMLSelectElement).value
    this.partnerInfo.relatedProjects[this.selectedIndex - 1].csoStatus = this.findStatus(selectedCode)?.display || '';
  }

  cancelEdit() {
    this.partnerInfo.outstandingAmt = this.cancelValues.outstanding;
    this.partnerInfo.disbursedAmt = this.cancelValues.disbursed;
    this.partnerInfo.undisbursedAmt = this.cancelValues.undisbursed;
    this.partnerInfo.relatedProjects.forEach((x, i) => {
      x.csoStatus = this.cancelValues.relatedProjects[i].status;
      x.csoStatusCode = this.cancelValues.relatedProjects[i].statusCode;
      x.csoStartDate = this.cancelValues.relatedProjects[i].start;
      x.csoEndDate = this.cancelValues.relatedProjects[i].end;
      x.projectDisbursedAmt = this.cancelValues.relatedProjects[i].disbursed;
      x.projectOutstandingAmt = this.cancelValues.relatedProjects[i].outstanding;
      x.projectUndisbursedAmt = this.cancelValues.relatedProjects[i].undisbursed;
    });
    this.editMode = !this.editMode;
    this.cancelValues = null;
  }

  beginEdit() {
    if (!this.editMode) {
      this.cancelValues = {
        outstanding: this.partnerInfo.outstandingAmt,
        disbursed: this.partnerInfo.disbursedAmt,
        undisbursed: this.partnerInfo.undisbursedAmt,
        relatedProjects: []
      }
      this.partnerInfo.relatedProjects.forEach((x) => {
        this.cancelValues.relatedProjects.push({
          status: x.csoStatus,
          statusCode: x.csoStatusCode,
          start: x.csoStartDate,
          end: x.csoEndDate,
          disbursed: x.projectDisbursedAmt,
          outstanding: x.projectOutstandingAmt,
          undisbursed: x.projectUndisbursedAmt
        });
      });
    }
    this.editMode = !this.editMode;
  }

}
