import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerdetailsComponent } from './partnerdetails.component';

describe('PartnerdetailsComponent', () => {
  let component: PartnerdetailsComponent;
  let fixture: ComponentFixture<PartnerdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PartnerdetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PartnerdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
