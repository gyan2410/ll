import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({
  name: 'removeStyles'
})
export class RemoveStylesPipe implements PipeTransform {

  constructor(private sanitizer: DomSanitizer){}

  transform(value: string | undefined, ...args: unknown[]): string | SafeHtml {
    if (!value) {
      return '';
    }
    return this.sanitizer.bypassSecurityTrustHtml(value.replace(/ style=['"](.*?)["']/g, ''))
  }

}
