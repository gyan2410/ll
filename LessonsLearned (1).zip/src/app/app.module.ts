import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientJsonpModule, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './modules/material.module';
import { MainComponent } from './content/main/main.component';
import { DetailsComponent } from './content/details/details.component';
import { RisksComponent } from './content/risks/risks.component';
import { SummaryComponent } from './content/summary/summary.component';
import { LessonsComponent } from './content/lessons/lessons.component';
import { SponsorComponent } from './content/sponsor/sponsor.component';
import { StrategyComponent } from './content/strategy/strategy.component';
import { PartnerdetailsComponent } from './components/partnerdetails/partnerdetails.component';
import { QuillModule, QuillToolbarConfig } from 'ngx-quill'
import { ReactiveFormsModule } from '@angular/forms';
import { TermChipsComponent } from './components/term-chips/term-chips.component';
import { TaxonomySelectListComponent } from './components/taxonomy-select-list/taxonomy-select-list.component';
import { RenderComponent } from './content/render/render.component';
import { RelatedLessonsCountryComponent } from './components/related-lessons-country/related-lessons-country.component';
import { GoogleMapsModule } from '@angular/google-maps';
import { FormComponent } from './content/form/form.component';
import { ToggleClassDirective } from './directives/toggle-class.directive';
import { StickyNavDirective } from './directives/sticky-nav.directive';
import { RelatedLessonsComponent } from './components/related-lessons/related-lessons.component';
import {
  MsalGuard, MsalInterceptor, MsalBroadcastService, MsalInterceptorConfiguration, MsalModule, MsalService,
  MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG, MsalGuardConfiguration, MsalRedirectComponent, ProtectedResourceScopes
} from '@azure/msal-angular';
import { IPublicClientApplication, InteractionType, PublicClientApplication } from '@azure/msal-browser';

import { msalConfig, loginRequest, protectedResources } from './auth-config';
import { getClaimsFromStorage } from './storage-utils';
import { RemoveStylesPipe } from './remove-styles.pipe';

var toolbarOptions: QuillToolbarConfig = [
  [{ 'font': [] }],
  [{ 'size': [] }],  // custom dropdown
  ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
  [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
  [{ 'list': 'ordered' }, { 'list': 'bullet' }],
  [{ 'align': [] }],
  ['image', 'link'],
  ['clean']                                         // remove formatting button
];

export function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication(msalConfig);
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string | ProtectedResourceScopes> | null>();

  protectedResourceMap.set(protectedResources.profileApi.endpoint, [...protectedResources.profileApi.scopes, ...protectedResources.documentum.scopes]);

  return {
      interactionType: InteractionType.Popup,
      protectedResourceMap,
      authRequest: (msalService, httpReq, originalAuthRequest) => {
          const resource = new URL(httpReq.url).hostname;
          
          let claim =
              msalService.instance.getActiveAccount() &&
                  getClaimsFromStorage(
                      `cc.${msalConfig.auth.clientId}.${msalService.instance.getActiveAccount()?.idTokenClaims?.oid
                      }.${resource}`
                  )
                  ? window.atob(
                      getClaimsFromStorage(
                          `cc.${msalConfig.auth.clientId}.${msalService.instance.getActiveAccount()?.idTokenClaims?.oid
                          }.${resource}`
                      )
                  )
                  : undefined;
          return {
              ...originalAuthRequest,
              claims: claim,
          };
      },
  };
}

/**
* Set your default interaction type for MSALGuard here. If you have any
* additional scopes you want the user to consent upon login, add them here as well.
*/
export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return {
      interactionType: InteractionType.Redirect,
      authRequest: loginRequest
  };
}

@NgModule({
  declarations: [
    AppComponent,
    DetailsComponent,
    FormComponent,
    LessonsComponent,
    MainComponent,
    PartnerdetailsComponent,
    RelatedLessonsCountryComponent,
    RenderComponent,
    RisksComponent,
    SponsorComponent,
    StrategyComponent,
    SummaryComponent,
    TaxonomySelectListComponent,
    TermChipsComponent,
    ToggleClassDirective,
    StickyNavDirective,
    RelatedLessonsComponent,
    RemoveStylesPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GoogleMapsModule,
    HttpClientModule,
    HttpClientJsonpModule,
    BrowserAnimationsModule,
    MaterialModule,
    ReactiveFormsModule,
    QuillModule.forRoot({
      modules: {
        toolbar: toolbarOptions
      }
    })
  ],
  providers: [    
    {
        provide: MSAL_INSTANCE,
        useFactory: MSALInstanceFactory
    },
    {
        provide: MSAL_GUARD_CONFIG,
        useFactory: MSALGuardConfigFactory
    },
    {
        provide: MSAL_INTERCEPTOR_CONFIG,
        useFactory: MSALInterceptorConfigFactory
    },
    MsalService,
    MsalGuard,
    MsalBroadcastService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
