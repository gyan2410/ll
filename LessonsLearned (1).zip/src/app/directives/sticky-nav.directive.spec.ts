import { StickyNavDirective } from './sticky-nav.directive';

describe('StickyNavDirective', () => {
  it('should create an instance', () => {
    const directive = new StickyNavDirective();
    expect(directive).toBeTruthy();
  });
});
