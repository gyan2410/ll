import { ViewportScroller } from '@angular/common';
import { Directive, ElementRef, HostListener } from '@angular/core';
import * as jQuery from 'jquery';

@Directive({
  selector: '[appStickyNav]'
})
export class StickyNavDirective {
  elHtml: HTMLElement;

  @HostListener('window:scroll') onScroll() {
    let scrollPosition = this.vps.getScrollPosition();
    if (scrollPosition[1] >= 100) {
      jQuery(this.elHtml).addClass('sticky-top');
    } else {
      jQuery(this.elHtml).removeClass('sticky-top');
    }
  }

  constructor(private el: ElementRef, private vps: ViewportScroller) {
    this.elHtml = this.el.nativeElement as HTMLElement;
  }

}
