import { Directive, ElementRef, HostListener } from '@angular/core';
import * as jQuery from 'jquery';

@Directive({
  selector: '[appToggleClass]'
})
export class ToggleClassDirective {
  elHtml: HTMLElement;

  @HostListener('click') onClick() {
    let elClass = this.elHtml.attributes.getNamedItem('appToggleClass')?.value;
    if (elClass) {
      jQuery(this.elHtml).toggleClass(elClass);
      jQuery(this.elHtml).next().slideToggle();
    }
  }

  constructor(private el: ElementRef) {
    this.elHtml = this.el.nativeElement as HTMLElement;
  }
}
