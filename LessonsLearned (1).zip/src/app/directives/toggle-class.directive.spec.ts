import { ToggleClassDirective } from './toggle-class.directive';

describe('ToggleClassDirective', () => {
  it('should create an instance', () => {
    const directive = new ToggleClassDirective();
    expect(directive).toBeTruthy();
  });
});
