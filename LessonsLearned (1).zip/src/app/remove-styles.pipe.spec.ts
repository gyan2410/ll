import { RemoveStylesPipe } from './remove-styles.pipe';

describe('RemoveStylesPipe', () => {
  it('create an instance', () => {
    const pipe = new RemoveStylesPipe();
    expect(pipe).toBeTruthy();
  });
});
