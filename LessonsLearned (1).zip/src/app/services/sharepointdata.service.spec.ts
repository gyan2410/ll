import { TestBed } from '@angular/core/testing';

import { SharePointDataService } from './sharepointdata.service';

describe('SharePointDataService', () => {
  let service: SharePointDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SharePointDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
