import { HttpClient, HttpParams, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, concatMap, map, Observable, of, shareReplay, switchMap } from 'rxjs';
import { SPWebContextInfo } from '../../types/SPContextInfo';
import { SPSearchResult } from '../../types/SPSearch';
import { UtilitiesService } from './utilities.service';

@Injectable({
  providedIn: 'root'
})
export class SharePointService {
  mapAPILoadedObs$!: Observable<boolean>;

  constructor(private http: HttpClient, private utilitiesService: UtilitiesService) {
    this.mapAPILoadedObs$ = this.loadMapAPI().pipe(shareReplay(1));
  }

  getFormDigest() {
    let url = `${this.utilitiesService.siteCollectionUrl('/_api/contextinfo')}`;
    let headers = {
      'Accept': 'application/json;odata=verbose',
      'Content-Type': 'application/json;odata=verbose'
    }
    return this.http.post<SPWebContextInfo>(url, {}, {
      headers,
      withCredentials: true
    }).pipe(map((result: any) => {
      return result.d.GetContextWebInformation as SPWebContextInfo;
    }))
  }

  deleteItem(uri: string, recycle: boolean) {
    return this.getFormDigest().pipe(
      concatMap(digest => {
        let url = (recycle) ? uri + '/recycle()' : uri;
        let headers = {
          'X-RequestDigest': digest.FormDigestValue,
          'Accept': 'application/json;odata=verbose',
          'Content-Type': 'application/json;odata=verbose',
          'IF-MATCH': '*',
          'X-HTTP-Method': 'DELETE'
        };
        return this.http.post(url, '', {
          headers,
          withCredentials: true
        });
      }));
  }

  post(uri: string, payload: any, additionalHeaders?: any) {
    var url = uri.indexOf('http') === 0 ? uri : this.utilitiesService.siteCollectionUrl(uri);
    return this.getFormDigest().pipe(concatMap(digest => {
      var headers = {
        'X-RequestDigest': digest.FormDigestValue,
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose'
      };
      if (additionalHeaders) {
        Object.assign(headers, additionalHeaders);
      }
      if (typeof payload !== 'string') {
        payload = JSON.stringify(payload);
      }
      return this.http.post(url, payload, {
        headers,
        withCredentials: true
      }).pipe(map((result: any) => {
        if (!result) {
          return result;
        }

        let finalResult = result.d.results || result.d;
        return finalResult;
      }))
    }))
  }

  attachFile(uri: string, fileName: string, payLoad: any) {
    let url = uri.indexOf('http') === 0 ? uri : this.utilitiesService.siteCollectionUrl(uri);
    url = `${url}/AttachmentFiles/add(FileName='${fileName}')`;
    return this.getFormDigest().pipe(concatMap(digest => {
      var headers = {
        'X-RequestDigest': digest.FormDigestValue,
        'Accept': 'application/json;odata=verbose'
      };
      return this.http.request('POST', url, {
        withCredentials: true,
        body: payLoad,
        headers: headers
      })

      return this.http.post(url, payLoad, {
        headers,
        withCredentials: true
      })
    }))
  }

  deleteAttachment(uri: string, fileName: string) {
    let url = uri.indexOf('http') === 0 ? uri : this.utilitiesService.siteCollectionUrl(uri);
    url = `${url}/AttachmentFiles/getByFileName('${fileName}')`;
    return this.getFormDigest().pipe(concatMap(digest => {
      var headers = {
        'X-RequestDigest': digest.FormDigestValue,
        'X-HTTP-Method': "DELETE"
      };
      return this.http.post(url, {}, {
        headers,
        withCredentials: true
      })
    }))
  }

  get<T = any>(uri: string, args: any, isHtml: boolean = false) {
    let url = this.utilitiesService.siteCollectionUrl(uri);
    if (args) {
      url += '?' + Object.keys(args).filter((k: string) => {
        return (args[k] !== null || args[k] !== '' || args[k] !== 'undefined');
      }).map((k: string) => {
        return k + '=' + encodeURIComponent(args[k])
      }).join('&');
    }
    let headers = isHtml ? { 'Accept': 'text/html; charset=utf-8' } : { 'Accept': 'application/json; odata=verbose' };
    let type = isHtml ? 'text' : 'json';
    return this.http.get(url, {
      headers,
      withCredentials: true,
      responseType: type as 'json'
    }).pipe(map((result: any) => {
      if (isHtml) {
        return result as T;
      }
      let finalResult = result.d.results || result.d;
      return finalResult as T;
    }))
  }

  getListItems<T = any>(listName: string, args: any) {
    let url = `/_api/web/lists/GetByTitle('${listName}')/Items`;
    return this.get<T>(url, args);
  }

  getList<T = any>(listName: string, args: any) {
    let url = `/_api/web/lists/GetByTitle('${listName}')`;
    return this.get<T>(url, args);
  }

  getSearchData(relativePath: string, args: any, count: number) {
    return this.get('/_api/search/query', {
      querytext: this.createQueryText(args),
      selectproperties: "'Title,RefinableIntFirst01,RefinableStringFirst21,RefinableStringFirst26,RefinableStringFirst27,RefinableStringFirst28,RefinableIntFirst00,RefinableStringFirst35'",
      rowlimit: count || 10,
      trimDuplicates: true,
      sortlist: "'RefinableInt10:descending,LastModifiedTime:descending'"
    }).pipe(map(data => {
      if (data.query.PrimaryQueryResult === null) {
        return null;
      }

      var searchResults = data.query.PrimaryQueryResult.RelevantResults;
      var returnData: SPSearchResult = {
        rowItems: searchResults.RowCount,
        totalItems: searchResults.TotalRows,
        items: []
      };
      returnData.items = searchResults.Table.Rows.results.map((item: any) => {
        return item.Cells.results;
      }).map((properties: any) => {
        return properties.reduce((prev: any, curr: any) => {
          prev[curr.Key] = curr.Value;
          return prev;
        }, {});
      });
      return returnData;
    }))
  }

  parseValue(value: any) {
    return (typeof value === 'boolean' || typeof value === 'number') ? value : `"${value}"`;
  }

  createQueryText(queryObject: any) {
    var queryText = Object.keys(queryObject)
      .map((key) => {
        var currValue = queryObject[key];
        if (key === 'freeText') {
          return (currValue) ? currValue : null;
        } else if (Array.isArray(currValue)) {
          return currValue.reduce((acc, curr) => { return acc + (acc ? ' ' : '') + key + ':' + this.parseValue(curr); }, '');
        } else if (currValue === Object(currValue)) {
          var currObject = currValue;
          var andQ = Object.keys(currObject).reduce((acc, curr) => { return acc + (acc ? ' AND ' : '') + key + ':' + this.parseValue(currObject[curr]) }, '');
          return '(' + andQ + ')';
        }
        return key + ':' + this.parseValue(currValue);
      }).join(' ');
    if (queryText.indexOf("'") >= 0) {
      queryText = queryText.replace(/'/g, "''");
    }
    return "'" + queryText + "'";
  }

  loadMapAPI() {
    return this.http.jsonp('https://maps.google.com/maps/api/js?key=AIzaSyCHF2ffx_9129ej0b9hwl67fbj6cxsEtbU', 'callback')
    .pipe(
      map(() => true),
      catchError(() => of(false))
    );
  }
}
