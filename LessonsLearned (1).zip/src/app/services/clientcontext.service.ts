import { Injectable } from '@angular/core';
import { BehaviorSubject, catchError, concat, concatMap, map, of, ReplaySubject, Subject, switchMap } from 'rxjs';
import { ScriptloaderService, ScriptModel } from './scriptloader.service';
import { UtilitiesService } from './utilities.service';

@Injectable({
  providedIn: 'root'
})
export class ClientContextService {
  scriptStore: Array<ScriptModel> = [
    { name: 'ajax', src: '//ajax.aspnetcdn.com/ajax/4.0/1/MicrosoftAjax.js', loaded$: new ReplaySubject<boolean>(1) },
    { name: 'init', src: `${this.util.hostUrl()}/_layouts/15/init.js`, loaded$: new ReplaySubject<boolean>(1) },
    { name: 'spruntime', src: `${this.util.hostUrl()}/_layouts/15/sp.runtime.js`, loaded$: new ReplaySubject<boolean>(1) },
    { name: 'sp', src: `${this.util.hostUrl()}/_layouts/15/sp.js`, loaded$: new ReplaySubject<boolean>(1) },
    { name: 'taxonomy', src: `${this.util.hostUrl()}/_layouts/15/sp.taxonomy.js`, loaded$: new ReplaySubject<boolean>(1) }
  ]

  constructor(private scriptLoader: ScriptloaderService, private util: UtilitiesService) { }

  public getCurrentContext() {
    return this.scriptLoader.load(this.scriptStore[0]).pipe(
      switchMap(loaded1 => (loaded1) ? this.scriptLoader.load(this.scriptStore[1]).pipe(
        switchMap(loaded2 => (loaded2) ? this.scriptLoader.load(this.scriptStore[2]).pipe(
          switchMap(loaded3 => (loaded3) ? this.scriptLoader.load(this.scriptStore[3]).pipe(
            switchMap(loaded4 => (loaded4) ? this.scriptLoader.load(this.scriptStore[4]).pipe(
              map(loaded5 => {
                if (loaded5) {
                  let sp = (window as any).SP;
                  return new sp.ClientContext(this.util.hostUrl());
                }
                return null;
              })
            ) : of(null) )
          ) : of(null))
        ) : of(null))
      ): of(null)))
  }
}
