import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map, take, throwError, switchMap } from 'rxjs';
import { iPortalProjectResult, iPortalProject, iPortalProjectData } from '../../types/iPortalData';
import { AppconstantsService } from './appconstants.service';
import { FormDataService } from './formdata.service';
import { MSALService } from './MSAL.service';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private fdSvc: FormDataService, private constants: AppconstantsService, private httpClient: HttpClient, private msal: MSALService) { }

  setProjectData(item: iPortalProject) {
    this.fdSvc.data.projectData.projectId = item.project_id.toString();
    this.fdSvc.data.projectData.clientId = item.project_basic_info.client_id;
    this.fdSvc.data.projectData.lessonTitle = item.project_basic_info.project_name;
    this.fdSvc.data.projectData.lessonRegion = item.project_basic_info.region;
    this.fdSvc.data.projectData.lessonSector = item.project_basic_info.sector_name;
  }

  getiPortalProjectById(projectId: string) {
    let auth = this.constants.GetScopeValue();

    return this.msal.getToken(auth.iPortalScope).pipe(switchMap((res) => {
      let headrs = new HttpHeaders()
        .append("apiKey", auth.iPortalKey)
        .append("Authorization", `Bearer ${res}`);

      let url = `${auth.iPortalUrl}/ideskintegration/project/${projectId}/details?format=jsonp`;
      return this.httpClient.get<iPortalProjectResult>(url, {
        headers: headrs
      }).pipe(
        map(result => {
          this.fdSvc.data.projectData.accessLevel = result.header.accessLevel;
          if (result.header.accessLevel !== 'DENIED' && result.data) {
            this.setProjectData(result.data[0].Project);
            return result.data;
          }
          throw result;
        }));
    }));
  }
}
