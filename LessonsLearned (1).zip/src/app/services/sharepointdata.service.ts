import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { concatMap, map, Observable, of } from 'rxjs';
import { FinancialInstrument } from '../../types/FinancialInstrument';
import { ProjectMember } from '../../types/ProjectMember';
import { SPUserProfileProperty, SPUserProfileResult } from '../../types/SPProfileUser';
import { SPProfileUser, SPUser } from '../../types/SPUser';
import { WBProfileUserResult } from '../../types/WBProfileUser';
import { AppconstantsService } from './appconstants.service';
import { SharePointService } from './sharepoint.service';

@Injectable({
  providedIn: 'root'
})
export class SharePointDataService {

  constructor(private http: HttpClient, private spData: AppconstantsService, private spService: SharePointService) { }

  getUserProperty(key: string, userProperties: Array<SPUserProfileProperty>) {
    var matchedProperty = userProperties.filter(x => { return x.Key === key; });
    return matchedProperty.length > 0 ? matchedProperty[0].Value : '';
  }

  whoAmI(): Observable<SPProfileUser> {
    var select = 'DisplayName,UserProfileProperties';
    return this.spService.get<SPUserProfileResult>('/_api/SP.UserProfiles.PeopleManager/GetMyProperties', { '$select': select }).pipe(
      map(result => {
        return {
          displayName: result.DisplayName,
          workEmail: this.getUserProperty('WorkEmail', result.UserProfileProperties.results),
          UPI: this.getUserProperty('UPI', result.UserProfileProperties.results)
        }
      }))
  }

  loadFinancialInstruments(): Observable<Array<FinancialInstrument>> {
    var select = "Title,SecurityType";
    var orderby = "Title"
    return this.spService.get(`/_api/web/lists/GetByTitle('${this.spData.listNames.financialInstruments}')/Items`, { '$select': select, '$orderby': orderby })
  }

  loadProjectTeam(projectId: string): Observable<Array<ProjectMember>> {
    let listName = 'Project Team'
    return this.spService.get(`/../projects/${projectId}/Lists/ProjectTeam/AllItems.aspx`, null, true).pipe(
      concatMap(result => {
        if (result.indexOf('AccessDenied') === -1) {
          return this.spService.get(`/../projects/${projectId}/_api/web/lists/GetByTitle('${listName}')/Items`, { $select: 'ProjectMemberId,ProjectRole,ProjectMember/Title', $expand: 'ProjectMember' });
        }
        return of([]);
      }))
  }

  getUserById(userId: string): Observable<SPUser> {
    return this.spService.get<SPUser>(`/_api/web/GetUserById(${userId})`, {});
  }

  getUserDataFromSearch(userEmail: string) {
    let url = `https://searchfeeds.worldbank.org/people/bank?format=json&qterm=${encodeURIComponent(userEmail)}&srt=0&order=desc&nohighlight=true&keyword_select=allwords&boost_value=true&pu=false`;
    var req = {
      headers: {
        Accept: 'application/json; odata=verbose'
      },
      xhrFields: {
        withCredentials: true
      }
    };
    return this.http.get<WBProfileUserResult>(url, req);
  }
}
