import { Injectable } from '@angular/core';
import { EnvId } from '../../types/EnvIdType';

interface ScopeVals {
  documentumScope: string,
  documentumKey: string,
  documentumUrl: string,
  iPortalScope: string,
  iPortalUrl: string,
  iPortalKey: string
}

@Injectable({
  providedIn: 'root'
})
export class AppconstantsService {
  public listNames = {
    projects: 'Projects',
    lessonsLearned: 'Lessons Learned',
    lessonsLearnedOfficial: 'Lessons Learned Official',
    financialInstruments: 'FinancialInstruments',
    interactionNotes: 'InteractionNotes',
    publishedLessons: 'Final'
  }

  public dummyProjectColumns = {
    projectId: 'ProjectID',
    projectShortName: 'ShortName',
    projectName: 'Title',
    startDate: 'StartDate'
  }

  public iPortalUrls = {
    iDesk: 'https://api1.ifc.org/ideskintegration/project/',
    Partner: 'https://api1.ifc.org/services-1.5.0/partner/',
    iPortal: 'https://iportalapp.ifc.org/projectcycle/',
    iPortalAuth: 'https://ifcpasskey.ifc.org/2FA/ssldocs/login.fcc?TYPE=33554432&REALMOID=06-0001b0a1-cef4-1512-98b0-82270a3130fd&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-JCQ5h7xJBOLKQLGATo3s5o%2bsJ4%2fTnV%2fPpeqRT0RdYBN%2bHTqo04mwG7WSqa%2blgbJY&TARGET=-SM-HTTP'
  }

  public colTypes = {
    text: 0,
    metadata: 1,
    array: 2,
    boolean: 3,
    object: 4,
    parent: 10
  }

  public columns = {
    projectId: { spColumnMap: 'Title', type: 0 },
    lessonTitle: { spColumnMap: 'LessonTitle', type: 0 },
    lessonCountry: { spColumnMap: 'LessonCountry', type: 0, spManagedProp: 'RefinableStringFirst26' },
    lessonRegion: { spColumnMap: 'LessonRegion', type: 0, spManagedProp: 'RefinableStringFirst28' },
    lessonSector: { spColumnMap: 'LessonSector', type: 0, spManagedProp: 'RefinableStringFirst27' },
    saveStatus: { spColumnMap: 'SaveStatus', type: 0 },
    projectOverview: { spColumnMap: 'ProjectOverview', type: 0 },
    transferReason: { spColumnMap: 'TransferReason', type: 0 },
    riskFactors: { spColumnMap: 'RiskFactor', type: 1, envLookup: 'riskFactors', infoSPField: 'RisksIdentified', spManagedProp: 'owstaxIdRiskFactor' },
    riskFactorsInfo: { spColumnMap: 'RiskFactorDetails', type: 2 },
    oldRiskFactors: { spColumnMap: 'RisksIdentified', type: 4 },
    selectedFinancialInstruments: { spColumnMap: 'FinancialInstruments', type: 2 },
    financialInstrumentOtherDetails: { spColumnMap: 'FinancialInstrumentsOther', type: 0 },
    warrantExercised: { spColumnMap: 'WarrantExercised', type: 0 },
    selectedSecurityTypes: { spColumnMap: 'SecurityType', type: 2 },
    securityTypeDetails: { spColumnMap: 'SecurityTypeDetails', type: 0 },
    securityPerfected: { spColumnMap: 'SecurityPerfected', type: 0 },
    securityPerfectionStatus: { spColumnMap: 'SecurityPerfectionStatus', type: 0 },
    securityTypeOtherSpecification: { spColumnMap: 'SecurityTypeOtherSpecification', type: 2 },
    selectedExitAlternatives: { spColumnMap: 'ExitAlternatives', type: 2 },
    exitAlternativesOtherDetails: { spColumnMap: 'ExitAlternativesOtherDetails', type: 0 },
    selectedExitOptions: { spColumnMap: 'ExitOptionIssue', type: 2 },
    exitOptionOtherSpecification: { spColumnMap: 'ExitOptionOtherSpecification', type: 0 },
    relevantSupport: { spColumnMap: 'RelevantSupport', type: 1, envLookup: 'relevantSupport' },
    investmentHistory: { spColumnMap: 'InvestmentHistory', type: 1, envLookup: 'investmentHistory' },
    clientExperience: { spColumnMap: 'ClientExperience', type: 0 },
    clientExperienceDetails: { spColumnMap: 'ClientExperienceDetails', type: 0 },
    illegalActions: { spColumnMap: 'IllegalActions', type: 0 },
    breachSuspicions: { spColumnMap: 'BreachSuspicions', type: 0 },
    recoveryStrategies: { spColumnMap: 'RecoveryStrategy', type: 1, infoSPField: 'RecoveryStrategyInfo', envLookup: 'workoutStrategy', spManagedProp: 'owstaxIdRecoveryStrategy' },
    recoveryStrategyDetails: { spColumnMap: 'RecoveryStrategyDetails', type: 0 },
    recoveryStrategiesInfo: { spColumnMap: 'RecoveryStrategyInfo', type: 4 },
    ifcLessonsLearned: { spColumnMap: 'IFCLessonsLearned', type: 0 },
    csoLessonsLearned: { spColumnMap: 'CSOLessonsLearned', type: 0 },
    internalUse: { spColumnMap: 'InternalUse', type: 0 },
    publicUse: { spColumnMap: 'PublicDissemination', type: 0 },
    lessonImageUrl: { spColumnMap: 'LessonImageUrl', type: 0 },
    lessonSnippet: { spColumnMap: 'LessonSnippet', type: 0 },
    lessonPreviewImageUrl: { spColumnMap: 'LessonPreviewImageUrl', type: 0 },
    workoutOutcomes: { spColumnMap: 'WorkoutOutcome', type: 1, infoSPField: 'WorkoutOutcomeDetails', envLookup: 'workoutOutcome', spManagedProp: 'owstaxIdWorkoutOutcome' },
    workoutOutcomesInfo: { spColumnMap: 'WorkoutOutcomeDetails', type: 4 },
    team: {
      type: 10,
      columns: {
        transactionLeader: { spColumnMap: 'TransactionLeader', type: 0 },
        regionalDirector: { spColumnMap: 'RegionalDirector', type: 0 },
        industryDirector: { spColumnMap: 'IndustryDirector', type: 0 },
        csoDirector: { spColumnMap: 'CSODirector', type: 0 },
        csoLeadIo: { spColumnMap: 'CSOLeadIo', type: 0 },
        csoSecondIo: { spColumnMap: 'CSOSecondIo', type: 0 },
        csoLawyer: { spColumnMap: 'CSOLawyer', type: 0 }
      }
    },
    investmentTeam: { spColumnMap: 'InvestmentTeam', type: 4 },
    iPortalData: { spColumnMap: 'iPortalData', type: 4 },
    summarySponsor: { spColumnMap: 'SummarySponsor', type: 0 },
    summaryInvestment: { spColumnMap: 'SummaryInvestment', type: 0 },
    summarySecurity: { spColumnMap: 'SummarySecurity', type: 0 },
    recoveryMetric: { spColumnMap: 'RecoveryMetric', type: 0 },
    relevantSupportOther: { spColumnMap: 'RelevantSupportOther', type: 0 },
    lessonWeight: { spColumnMap: 'LessonWeight', type: 0 },
    legacyLesson: { spColumnMap: 'LegacyLesson', type: 3 }
  };

  public columnNames = {
    projectId: 'Title',
    saveStatus: 'SaveStatus',
    attachments: 'AttachmentFiles'
  };

  public envIds: EnvId = {
    dev: {
      riskFactors: {
        termStoreId: 'efcc9279-7070-43b2-8054-01abcea2a22c',
        columnId: 'a1c4942529584b939896198e47a04859'
      },
      relevantSupport: {
        termStoreId: 'c379747e-9917-495e-b485-1e637f640902',
        columnId: 'i2f732ecef214cca99e1197a6138b583'
      },
      investmentHistory: {
        termStoreId: '895691f0-705c-4005-aa21-718dca388945',
        columnId: 'g48c62172e3e4ada98fc476f840818a2'
      },
      workoutStrategy: {
        termStoreId: '6e99eaa9-9636-4395-bbe7-fb343e2cf02e',
        columnId: 'aec55ac2b9c84ffe91a3c9432e98b36d'
      }
    },
    csoDev: {
      riskFactors: {
        termStoreId: 'a0495044-344d-41dc-aa12-e5e201fd7d91',
        columnId: 'cd81847f8e694b929dedd7228a8e9cf2'
      },
      relevantSupport: {
        termStoreId: '6d435e64-0ae1-49ed-9318-308b2fc62056',
        columnId: 'pe1524c433cf4e8c866d66bfdb28d97f'
      },
      investmentHistory: {
        termStoreId: '1bbb1b7d-567c-4f8b-86b8-bca5a6bdce17',
        columnId: 'g021514821194942a39a42775406f1b4'
      },
      workoutStrategy: {
        termStoreId: '6becfe98-60e8-4960-979b-d8ff348694dc',
        columnId: 'aab901deee2d421fa613a76a07a721ef'
      },
      workoutOutcome: {
        termStoreId: '66a6fb10-4f8b-4764-af97-bb65a3af0b1d',
        columnId: 'lf0f5c85b1a04840a9e0e8f86d75fa2e'
      }
    },
    csoProd: {
      riskFactors: {
        termStoreId: 'a0495044-344d-41dc-aa12-e5e201fd7d91',
        columnId: 'cd81847f8e694b929dedd7228a8e9cf2'
      },
      relevantSupport: {
        termStoreId: '6d435e64-0ae1-49ed-9318-308b2fc62056',
        columnId: 'pe1524c433cf4e8c866d66bfdb28d97f'
      },
      investmentHistory: {
        termStoreId: '1bbb1b7d-567c-4f8b-86b8-bca5a6bdce17',
        columnId: 'g021514821194942a39a42775406f1b4'
      },
      workoutStrategy: {
        termStoreId: '6becfe98-60e8-4960-979b-d8ff348694dc',
        columnId: 'aab901deee2d421fa613a76a07a721ef'
      },
      workoutOutcome: {
        termStoreId: '66a6fb10-4f8b-4764-af97-bb65a3af0b1d',
        columnId: 'lf0f5c85b1a04840a9e0e8f86d75fa2e'
      }
    },
    csoSPO: {
      riskFactors: {
        termStoreId: '95cf68f8-0db0-4da2-a1f0-1d254e7b8df3',
        columnId: 'cd81847f8e694b929dedd7228a8e9cf2'
      },
      relevantSupport: {
        termStoreId: 'dceeae27-c9d4-471d-9985-b31f743315d9',
        columnId: 'pe1524c433cf4e8c866d66bfdb28d97f'
      },
      investmentHistory: {
        termStoreId: 'ac6ff0e6-9836-4a08-bcfa-2f1016ac9c31',
        columnId: 'g021514821194942a39a42775406f1b4'
      },
      workoutStrategy: {
        termStoreId: '045f1f41-f03c-4c33-b98a-4d2ef2e815ca',
        columnId: 'aab901deee2d421fa613a76a07a721ef'
      },
      workoutOutcome: {
        termStoreId: 'a65654fa-7d9f-48aa-afb2-2c3393de0d8b',
        columnId: 'lf0f5c85b1a04840a9e0e8f86d75fa2e'
      }
    }
  }
  private auth = {
    dev: {
      documentumScope: "https://api1oauthqa.ifc.org/SearchAPI//user_impersonation",
      documentumKey: "5Ij0AoklGINS6PeZGnmz2R8eGj5CU4RO",
      documentumUrl: "https://apigwtst.ifc.org/ifcsearch/v1/docshub",
      //iPortalScope: "https://worldbankgroup.onmicrosoft.com/qa_smsession_apigee/user_impersonation",
      iPortalScope: "https://worldbankgroup.onmicrosoft.com/STG_ifc-iportal_iPortal_WebAPI/021a89f1-c718-4344-b16a-1f4ea9648b14/user_impersonation",
      iPortalUrl: "https://apigwtst.ifc.org",
      iPortalKey: "WtD6bEoG3rSMIpcdQZL9lQaR1PsTxWIZ"
    } as ScopeVals,
    prod: {
      documentumScope: "https://api1oauth.ifc.org/SearchAPI//user_impersonation",
      documentumKey: "cts8w4OsjlQ4GXkJaUr7x1FQnf5nyTRM",
      documentumUrl: "https://apigw.ifc.org/ifcsearch/v1/docshub",
      iPortalScope: "https://worldbankgroup.onmicrosoft.com/ifc-iportal_WebAPI/4393c8c6-6923-4a18-b1b1-2125aba17e98/user_impersonation",
      iPortalUrl: "https://apigw.ifc.org",
      iPortalKey: "OEBv6DvG6jXmIBf1t6lXAAeCTXwc2elz"
    } as ScopeVals
  }

  constructor() { }

  GetScopeValue():ScopeVals {
    type devObjectKey = keyof typeof this.auth.dev;
    switch (window.location.hostname) {
      case 'cfernandezdev.sharepoint.com':
      case 'localhost':
      case 'wbgmsspcso001':
      case 'spsecqa.ifc.org':
      case 'spsecnqa.ifc.org':
        return this.auth.dev;
      case 'spsec.ifc.org':
      case 'worldbankgroup.sharepoint.com':
        type prodObjectKey = keyof typeof this.auth.prod;
        if(window.location.href.toLowerCase().indexOf("worldbankgroup.sharepoint.com/sites/csodev") >0) { //Dev Site
          return this.auth.dev;
        }
        return this.auth.prod;
      default:
        return {
          documentumScope: "",
          documentumKey: "",
          documentumUrl: "",
          iPortalScope: "",
          iPortalUrl: "",
          iPortalKey: ""
        }
    }
  }
}
