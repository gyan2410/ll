import { Injectable } from '@angular/core';
import { BehaviorSubject, ReplaySubject, throwError } from 'rxjs';

export interface ScriptModel {
  name: string;
  src: string;
  loaded$: ReplaySubject<boolean>;
}

@Injectable({
  providedIn: 'root'
})
export class ScriptloaderService {
  private scripts: ScriptModel[] = [];

  constructor() { }

  public load(script: ScriptModel) {
    const existingScript = this.scripts.findIndex(s => s.name === script.name);

    if (existingScript > -1) {
      return this.scripts[existingScript].loaded$;
    } else {
      //script.loaded$ = new BehaviorSubject(false);
      const scriptElement = document.createElement('script');
      scriptElement.async = true;
      scriptElement.type = 'text/javascript';
      scriptElement.src = script.src;

      scriptElement.onload = () => {
        script.loaded$.next(true);
      }
      scriptElement.onerror = () => {
        console.error('ERROR: Script load failed: ', script.src);
        script.loaded$.next(false);
      }
      document.getElementsByTagName('body')[0].appendChild(scriptElement);
      this.scripts.push(script);
      return script.loaded$.asObservable();
    }
  }
}
