import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MsalBroadcastService, MsalService } from '@azure/msal-angular';
import { from, Observable, of, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { UtilitiesService } from './utilities.service';

@Injectable({
  providedIn: 'root'
})
export class MSALService {
  globalScopes: {[key: string]: Subject<string>} = {};

  constructor(private http: HttpClient, private authService: MsalService, private msalBroadcastService: MsalBroadcastService, private utilities:UtilitiesService) { }

  private tokens: any = {};

  private setValue(key:string, value:string, expiration:Date) {
    let val = {
      expiration: expiration,
      value: value
    };
    type StoreObjectKey = keyof typeof this.tokens;
    this.tokens[key as StoreObjectKey] = JSON.stringify(val);
  }
  private getCachedToken(key:string) {
    type StoreObjectKey = keyof typeof this.tokens;
    let val = this.tokens[key as StoreObjectKey];
    if(val != null) {
      let p = JSON.parse(val);
      let now = new Date();
      if(new Date(Date.parse(p.expiration)) < now) {
        return p.value;
      }
      else {
        localStorage.removeItem(key);
        return null;
      }
    }
    return val;
  }

  getToken(scope:string): Observable<string> {
    let indexOfScope = this.globalScopes[scope];

    let cacheToken = this.utilities.getLocalStorageValue(scope);
    if (cacheToken !== null) {
      return of(cacheToken);
    }

    if (indexOfScope === undefined) {
      this.globalScopes[scope] = new Subject<string>();
      let promise = this.authService.instance.acquireTokenPopup({
        account: this.authService.instance.getActiveAccount() as any,
        scopes: [scope]
        //claims: claimsChallengeMap['claims']
      });
      let obsProm$ = from(promise).pipe(map(res => {
        console.log(res);
        let token = res.accessToken;
        let exp = res.expiresOn;
  
        this.utilities.setLocalStorageValue(scope, token, exp as Date);
        this.globalScopes[scope].next(token);
        return token;
      }));
      return obsProm$;
    } else {
        return this.globalScopes[scope].asObservable();
    }
  }
}
