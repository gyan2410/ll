import { Injectable } from '@angular/core';
import { concatMap, forkJoin, map, Observable, of, Subject, take } from 'rxjs';
import { SPTerm } from 'src/types/SPTaxonomy';
import { ClientContextService } from './clientcontext.service';
import { UtilitiesService } from './utilities.service';

@Injectable({
  providedIn: 'root'
})
export class TaxonomyService {
  termCache: { [key: string]: { [key: string]: SPTerm } } = {};
  termResults$ = new Subject<{ taxonomy: Array<SPTerm>, flatTaxonomy: Array<SPTerm>}>();
  sp: any;

  constructor(private util: UtilitiesService, private context: ClientContextService) { }

  public getAllTerms(termSetGuid: string) {
    const ret: Array<any> = [];
    const flat: Array<any> = [];

    return this.context.getCurrentContext().pipe(concatMap((ctx: any) => {
      let result = new Observable<{ taxonomy: Array<SPTerm>, flatTaxonomy: Array<SPTerm>}>(subscriber => {
        this.sp = (window as any).SP;
        const spGuid = new this.sp.Guid(termSetGuid);
        const taxSession = this.sp.Taxonomy.TaxonomySession.getTaxonomySession(ctx);
        const termStore = taxSession.getDefaultSiteCollectionTermStore();
        //const termStores = taxSession.get_termStores();
        //const termStore = termStores.getByName('Taxonomy_mWRGk5xMmZpfGDbIB1XHHg==')
        const termSet = termStore.getTermSet(spGuid);
        const terms = termSet.getAllTerms();
        ctx.load(termStore);
        ctx.load(termSet);
        ctx.load(terms);
  
        ctx.executeQueryAsync(() => {
          const dic: any = {};
          const termsEnumerator = terms.getEnumerator();
          while (termsEnumerator.moveNext()) {
            const cterm = termsEnumerator.get_current();
            const arr = cterm.get_pathOfTerm().split(';');
            let p = dic;
            for(let i = 0; i < arr.length - 1; i++) {
              const label = arr[i];
              let c = p[label];
              if (!c) {
                p[label] = c = {};
              }
              p = c;
            }
            const nodeLabel = arr[arr.length - 1];
            if (p[nodeLabel] === undefined) {
              p[nodeLabel] = { __term: null };
            }
            p[nodeLabel].__term = cterm;
          }
          this.provisionTerms(termSetGuid, dic, null, ret, flat);
          // let obs$ = [];
          // for(let term of flat) {
          //   obs$.push(this.getLabels(term));
          // }
          // forkJoin(obs$).pipe(take(1)).subscribe(result => {
          //   console.log('forkJoin: ', result);
          // })
          subscriber.next({ taxonomy: ret, flatTaxonomy: flat });
        })
      })
      return result;
    }))
  }

  private provisionTerms(termSetId: string, collection: any, parentTerm: SPTerm | null, tiered: Array<SPTerm>, flat: Array<SPTerm>) {
    const keysSorted: Array<any> = [];
    for(const k in collection) {
      if (k !== '__term') {
        keysSorted.push(k);
      }
    };
    keysSorted.sort().map(termKey => {
      const child = collection[termKey];
      const currTerm: any = child.__term;
      const term = this.getTerm(currTerm.get_id().toString(), currTerm.get_name(), termSetId, parentTerm, currTerm.get_isDeprecated(), currTerm.get_isAvailableForTagging());
      if (!term.isDeprecated) {
        if (parentTerm) {
          if (!parentTerm.children) {
            parentTerm.children = [];
          }
          if (!parentTerm.children.some(t => t.id === term.id)) {
            parentTerm.children.push(term);
          }
        } else {
          tiered.push(term);
        }
        flat.push(term);
      }
      this.provisionTerms(termSetId, child, term, tiered, flat);
    })
    if (parentTerm && parentTerm.children) {
      parentTerm.cc = parentTerm.children.length;
    }
  }

  private getTerm(guid: string, title: string, termSetId: string, parentTerm: any, deprecated: boolean, available: boolean): SPTerm {
    guid = guid.toLowerCase();
    termSetId = termSetId.toLowerCase();

    let termSet = this.termCache[termSetId];
    if (!termSet) {
      this.termCache[termSetId] = termSet = {};
    }
    let term = termSet[guid];
    if (!term) {
      termSet[guid] = term = {
        cc: 0,
        children: [],
        id: guid,
        defaultLabel: title ? title.replace(/\uFF06/g, '&') : title,
        termSetId,
        parentTerm: parentTerm ? parentTerm.defaultLabel : null,
        parentTermId: parentTerm ? parentTerm.id : null,
        level: parentTerm ? parentTerm.level + 1 : 0,
        isDeprecated: deprecated,
        isAvailable: available,
      };
    }
    if (!term.defaultLabel && title) {
      term.defaultLabel = title;
    }
    return term;
  }

  private getLabels(currTerm: SPTerm) {
    return this.context.getCurrentContext().pipe(map((ctx: any) => {
      this.sp = (window as any).SP;
      const spTSGuid = new this.sp.Guid(currTerm.termSetId);
      const spTGuid = new this.sp.Guid(currTerm.id);
      let taxonomySession = this.sp.Taxonomy.TaxonomySession.getTaxonomySession(ctx);
      let termStore = taxonomySession.getDefaultSiteCollectionTermStore();
      let termSet = termStore.getTermSet(spTSGuid);
      let term = termSet.getTerm(spTGuid);
      let labels = term.getAllLabels(1033);
      ctx.load(labels);
      ctx.executeQueryAsync(function () {
          var labelEnumerator = labels.getEnumerator();
          var synonyms = [];
          while (labelEnumerator.moveNext()) {
              var label = labelEnumerator.get_current();
              var value = label.get_value();
              if (value != currTerm.defaultLabel) {
                  synonyms.push(value);
              }
          }
          currTerm.synonyms = synonyms.length > 0 ? synonyms.join("|") : null;
      });
      return currTerm;
    }), take(1));
  }
}
