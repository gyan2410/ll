import { Injectable } from '@angular/core';
import { concatMap, map, Observable, of, tap } from 'rxjs';
import { AppMetaDataField } from 'src/types/AppData';
import { InteractionNote } from 'src/types/InteractionNote';
import { SPAttachmentField, SPLessonItem, SPMetaDataField, SPTermField } from 'src/types/SPLessonItem';
import { AppconstantsService } from './appconstants.service';
import { FormDataService } from './formdata.service';
import { SharePointService } from './sharepoint.service';
import { UtilitiesService } from './utilities.service';

@Injectable({
  providedIn: 'root'
})
export class LessonsLearnedService {

  constructor(private spData: AppconstantsService, private utilities: UtilitiesService, private formData: FormDataService, private spService: SharePointService) { }

  getFileBuffer(file: File) {
    let obs$ = new Observable<Array<any>>((observer) => {
      let reader = new FileReader();
      reader.onload = (e) => {
        observer.next([e.target?.result, file.name] as any);
      }
      reader.onerror = (e) => {
        observer.error([e.target?.error]);
      }
      reader.readAsArrayBuffer(file);
    })
    return obs$;
  }

  createMetadataChips(taxonomyObject: SPMetaDataField, infoField: string) {
    let ret: Array<AppMetaDataField> = [];
    let terms = taxonomyObject.results;
    let termsInfo = (infoField) ? JSON.parse(infoField) : null;
    for (var i = 0; i < terms.length; i++) {
      let term: AppMetaDataField = {
        id: terms[i].TermGuid,
        defaultLabel: terms[i].Label,
        parentName: (termsInfo && termsInfo[terms[i].TermGuid]) ? termsInfo[terms[i].TermGuid].parent : null
      }
      ret.push(term);
    }
    return ret;
  }

  setAppData(storageArray: any, columns: any, item: SPLessonItem) {
    for (var prop in columns) {
      var colType = columns[prop].type;
      switch (colType) {
        case this.spData.colTypes.text:
          storageArray[prop] = item[columns[prop].spColumnMap as keyof SPLessonItem];
          break;
        case this.spData.colTypes.metadata:
          let mmCol = item[columns[prop].spColumnMap as keyof SPLessonItem];
          let mmInfoCol = item[columns[prop].infoSPField as keyof SPLessonItem];
          storageArray[prop] = this.createMetadataChips(mmCol as SPMetaDataField, mmInfoCol as string);
          break;
        case this.spData.colTypes.array:
          let arrayCol = item[columns[prop].spColumnMap as keyof SPLessonItem];
          storageArray[prop] = (JSON.parse(arrayCol as string) || []);
          break;
        case this.spData.colTypes.object:
          let jsonCol = item[columns[prop].spColumnMap as keyof SPLessonItem];
          storageArray[prop] = JSON.parse(jsonCol as string);
          break;
        case this.spData.colTypes.boolean:
          let boolCol = item[columns[prop].spColumnMap as keyof SPLessonItem];
          storageArray[prop] = (boolCol === true || boolCol === "true") ? true : false;
          break;
        case this.spData.colTypes.parent:
          this.setAppData(storageArray[prop], columns[prop].columns, item);
          break;
      }
    }
  }

  setPayLoadData(payload: any, columns: any, item: any) {
    for (var prop in columns) {
      var colType = columns[prop].type;
      switch (colType) {
        case this.spData.colTypes.text:
          payload[columns[prop].spColumnMap] = item[prop];
          break;
        case this.spData.colTypes.metadata:
          payload[this.utilities.GetEnvValue(columns[prop].envLookup).columnId] = this.formatMetadataString(item[prop]);
          break;
        case this.spData.colTypes.array:
        case this.spData.colTypes.object:
          payload[columns[prop].spColumnMap] = JSON.stringify(item[prop]);
          break;
        case this.spData.colTypes.boolean:
          payload[columns[prop].spColumnMap] = (item[prop]) ? 'true' : 'false';
          break;
        case this.spData.colTypes.parent:
          this.setPayLoadData(payload, columns[prop].columns, item[prop]);
          break;
      }
    }
  }

  setLessonsLearnedData(item: SPLessonItem) {
    let appData = this.formData.data.formData || {} as any;
    appData.updateUri = item.__metadata.uri;
    appData.updateType = item.__metadata.type;
    appData.curator = item.LessonCuratorId;
    appData.author = item.LessonAuthorId;
    this.setAppData(appData, this.spData.columns, item);
    appData.attachments = [];

    var spColNameAttach = this.spData.columnNames.attachments;
    var attachmentsCol = item[spColNameAttach as keyof SPLessonItem] as SPAttachmentField;
    if (attachmentsCol && attachmentsCol.results.length > 0) {
      attachmentsCol.results.forEach(item => {
        let isLessonImage = item.ServerRelativeUrl.toLowerCase() === appData.lessonImageUrl?.toLowerCase();
        let isLessonPreview = item.ServerRelativeUrl.toLowerCase() === appData.lessonPreviewImageUrl?.toLowerCase();
        let attachmentItem = {
          fileName: item.FileName,
          url: item.ServerRelativeUrl,
          isLessonImage: isLessonImage,
          isLessonPreviewImage: isLessonPreview
        }
        this.formData.data.formData?.attachments.push(attachmentItem);
      })
    }

    if (appData.saveStatus === "Submitted") {
      this.formData.data.stateData = {
        DetailsController: 'complete',
        StrategyController: 'complete',
        LessonsController: 'complete',
        RisksController: 'complete',
        SponsorController: 'complete'
      };
    }
  }

  formatMetadataString(terms: Array<AppMetaDataField>) {
    var termStrings = [];
    if (terms) {
      for (var i = 0; i < terms.length; i++) {
        termStrings.push("-1;#" + terms[i].defaultLabel + "|" + terms[i].id + ";");
      }
    }
    return termStrings.length > 0 ? termStrings.join("#") : "";
  }

  createPayload(payload: any) {
    var appData = this.formData.data.formData;
    this.setPayLoadData(payload, this.spData.columns, appData);
    payload[this.spData.columns.projectId.spColumnMap] = this.formData.data.projectData.projectId;
    payload[this.spData.columns.lessonTitle.spColumnMap] = this.formData.data.projectData.lessonTitle;
    payload[this.spData.columns.lessonCountry.spColumnMap] = this.formData.data.projectData.lessonCountry;
    payload[this.spData.columns.lessonRegion.spColumnMap] = this.formData.data.projectData.lessonRegion;
    payload[this.spData.columns.lessonSector.spColumnMap] = this.formData.data.projectData.lessonSector;
  }

  findExistingLessonLearned(listName: string, projectId: string, addFilters: any) {
    let id = (projectId) ? projectId : this.formData.data.projectData.projectId;
    let oDataCommands = {
      $filter: `${this.spData.columnNames.projectId} eq '${id}'`,
      $expand: this.spData.columnNames.attachments
    };
    if (addFilters) {
      Object.assign(oDataCommands, addFilters);
    }
    return this.spService.getListItems<Array<SPLessonItem>>(listName, oDataCommands).pipe(
      map(result => {
        if (result && result.length > 0) {
          return result[0];
        }
        return null;
      }));
  }

  getInteractionNotes() {
    let oDataCommands = {
      $select: 'Title,Section,InteractionNote',
      $orderby: 'Title'
    }
    return this.spService.getListItems<Array<InteractionNote>>(this.spData.listNames.interactionNotes, oDataCommands);
  }

  getLessonListData(listName: string) {
    let oDataCommands = {
      $select: 'Title,ListItemEntityTypeFullName'
    }
    return this.spService.get(`/_api/web/lists/GetByTitle('${listName}')`, oDataCommands);
  }

  createNewLessonLearned(listName: string, setLessonData: boolean) {
    return this.getLessonListData(listName).pipe(
      concatMap((listData: any) => {
        let lessonsLearnedPayload: any = {
          '__metadata': {
            'type': listData.ListItemEntityTypeFullName
          }
        }
        lessonsLearnedPayload[this.spData.columnNames.projectId] = this.formData.data.projectData.projectId;
        lessonsLearnedPayload[this.spData.columnNames.saveStatus] = 'Unsaved';
        return this.spService.post(`/_api/web/lists/GetByTitle('${listName}')/Items`, lessonsLearnedPayload).pipe(
          map((newLessonLearned: any) => {
            if (newLessonLearned) {
              if (setLessonData && this.formData.data.formData) {
                this.formData.data.formData.updateUri = newLessonLearned.__metadata.uri;
                this.formData.data.formData.updateType = newLessonLearned.__metadata.type;
                this.formData.data.formData.saveStatus = newLessonLearned[this.spData.columnNames.saveStatus];
                this.formData.data.formData.author = newLessonLearned.AuthorId;
                this.formData.data.formData.curator = newLessonLearned.EditorId;
              }
              return newLessonLearned;
            }
          })
        )
      }))
  }

  attachFile(file: File): Observable<any> {
    return this.getFileBuffer(file).pipe(
      concatMap((result: Array<any>) => {
        let url = (this.formData.data.formData) ? this.formData.data.formData.updateUri : '';
        if (url) {
          return this.spService.attachFile(url, result[1], result[0]).pipe(
            concatMap((file: any) => {
              var fileIndex = this.formData.data.formData?.attachments.map(file => {
                return file.fileName;
              }).indexOf(file.d.FileName);
              if (fileIndex) {
                this.formData.data.formData.attachments[fileIndex].url = file.d.ServerRelativeUrl;
                let nextFile = this.formData.data.formData.attachmentsToUpload.pop();
                if (nextFile) {
                  return this.attachFile(nextFile)
                }
              }
              return of({});
            })
          )
        }
        return of({});
      }))
  }

  deleteAttachment(fileName: string) {
    return this.spService.deleteAttachment(this.formData.data.formData.updateUri, fileName);
  }

  findOrCreateLessonLearned(createLesson: boolean, setLessonData: boolean) {
    var listName = (this.formData.data.formData.accessibility === 'internal') ? this.spData.listNames.lessonsLearned : this.spData.listNames.lessonsLearnedOfficial;
    return this.findExistingLessonLearned(listName, '', null).pipe(
      concatMap(existingLesson => {
        if (existingLesson && setLessonData) {
          this.setLessonsLearnedData(existingLesson);
          return of(existingLesson);
        }
        if (createLesson) {
          return this.createNewLessonLearned(listName, setLessonData);
        }
        return of(null);
      }))
  }

  saveLessonLearned(submit: any) {
    var additionalHeaders = {
      "X-HTTP-METHOD": "MERGE",
      "IF-MATCH": "*"
    };
    var payload = {
      '__metadata': {
        'type': this.formData.data.formData.updateType
      }
    } as any;
    this.formData.data.formData.saveStatus = submit ? 'Submitted' : 'Saved';
    payload[this.spData.columnNames.saveStatus] = this.formData.data.formData.saveStatus;
    this.createPayload(payload);
    return this.spService.post(this.formData.data.formData.updateUri, payload, additionalHeaders).pipe(
      concatMap(result => {
        if (this.formData.data.formData.attachmentsToUpload && this.formData.data.formData.attachmentsToUpload.length) {
          return this.attachFile(this.formData.data.formData.attachmentsToUpload.pop());
        }
        return of(result);
      })
    )
  }

  findPublishedLesson() {
    let oDataCommands = {
      $filter: `Name eq '${this.formData.data.projectData.projectId}.aspx'`
    }
    let apiUrl = `/_api/web/GetFolderByServerRelativeUrl('${this.spData.listNames.publishedLessons}')/Files`;
    return this.spService.get<Array<any>>(apiUrl, oDataCommands).pipe(
      map(result => {
        if (result && result.length) {
          return result[0];
        }
        return null;
      }))
  }

  findOrCreatePublishedLesson() {
    return this.findPublishedLesson().pipe(concatMap(result => {
      if (result) {
        return result;
      }
      return this.createPublishedLesson();
    }))
  }

  createPublishedLesson() {
    let apiUrl = `/_api/web/GetFolderByServerRelativeUrl('${this.spData.listNames.publishedLessons}')`;
    return this.spService.get(apiUrl, {}).pipe(
      concatMap(listData => {
        let listUrl = listData.ServerRelativeUrl;
        let payload: any = {};
        let fileName = this.formData.data.projectData.projectId;
        let postUrl = `/_api/web/GetFolderByServerRelativeUrl('${listUrl}')/Files/AddTemplateFile(urlOfFile='${listUrl}/${fileName}.aspx',templateFileType=1)`;
        return this.spService.post(postUrl, payload);
      }))
  }

  savePublishedLesson(publishedLesson: any, markup: string) {
    let additionalHeaders = {
      "X-HTTP-METHOD": "MERGE",
      "IF-MATCH": "*"
    };
    let payload = {
      '__metadata': { 'type': 'SP.Data.FinalItem' },
      'WikiField': markup
    }
    let apiUrl = `${publishedLesson.__metadata.uri}/ListItemAllFields`;
    this.spService.post(apiUrl, payload, additionalHeaders);
  }

  deleteLessonLearned() {
    return this.spService.deleteItem(this.formData.data.formData.updateUri, false);
  }
}
