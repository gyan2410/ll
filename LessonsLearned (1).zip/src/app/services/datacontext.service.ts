import { Injectable } from '@angular/core';
import { catchError, concatMap, map, of } from 'rxjs';
import { FormDataService } from './formdata.service';
import { LessonsLearnedService } from './lessonslearned.service';
import { ProjectService } from './project.service';

@Injectable({
  providedIn: 'root'
})
export class DatacontextService {

  constructor(private fdSvc: FormDataService, private lessonsService: LessonsLearnedService, private projectService: ProjectService) { }

  checkLesson(id: string) {
    this.fdSvc.data.projectData.projectId = id;
    return this.lessonsService.findOrCreateLessonLearned(false, true).pipe(
      map((result: any) => {
        return (result) ? result : null;
      })
    )
  }

  loadProject(id: string, createMissingLesson: boolean) {
    return this.checkLesson(id).pipe(
      concatMap(lesson => {
        console.info('Following Lesson found: ', lesson);
        if (lesson) {
          return this.projectService.getiPortalProjectById(id);
        }

        return this.projectService.getiPortalProjectById(id).pipe(
          concatMap(lesson => this.lessonsService.findOrCreateLessonLearned(createMissingLesson, true))
        )
      })
    )
  }

  checkId(id: string, type: string) {
    if (!type || !id) {
      return of(null);
    } else if (id && !this.fdSvc.data.projectData.projectId) {
      this.fdSvc.data.formData.accessibility = type;
      return this.loadProject(id, true).pipe(catchError(() => of(null)));
    } else {
      return of(true);
    }
  }

  readProject(id: string, accessibility: string) {
    this.fdSvc.data.formData.accessibility = accessibility;
    this.fdSvc.data.projectData.projectId = id;
    return this.lessonsService.findOrCreateLessonLearned(false, true).pipe(
      catchError((x) => {
        this.fdSvc.data.projectData.projectIdOrTitle = id;
        this.fdSvc.data.projectData.loadProjectError = true;
        if (x && x.status === 404) {
          this.fdSvc.data.projectData.error = '404 error';
        } else if (x && x.data.header.accessLevel === 'DENIED') {
          this.fdSvc.data.projectData.error = 'Access to project: ' + id + ' was denied. Please contact an iDesk admin for access to this project';
        } else if (x && x.data.header.status.message === 'Not Applicable ') {
          this.fdSvc.data.projectData.error = 'The project: ' + id + ' was not found through iPortal api';
        } else {
          this.fdSvc.data.projectData.error = 'The project: ' + id + ' does not have a corresponding lesson learned entered.';
        }
        return of(null);
      })
    )
  }
}
