import { TestBed } from '@angular/core/testing';

import { LessonsLearnedService } from './lessonslearned.service';

describe('LessonsLearnedService', () => {
  let service: LessonsLearnedService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LessonsLearnedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
