import { TestBed } from '@angular/core/testing';

import { DatacontextService } from './datacontext.service';

describe('DatacontextService', () => {
  let service: DatacontextService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatacontextService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
