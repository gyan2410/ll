import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { concatMap, forkJoin, map, Observable, switchMap, take } from 'rxjs';
import { PartnerDetails } from 'src/types/PartnerDetails';
import { iPortalPartnerResult, iPortalProjectResult, iPortalTeamResult } from '../../types/iPortalData';
import { RelatedProjectData } from '../../types/RelatedProject';
import { AppconstantsService } from './appconstants.service';
import { MSALService } from './MSAL.service';

@Injectable({
  providedIn: 'root'
})
export class IPortalDataService {

  constructor(private httpClient: HttpClient, private spData: AppconstantsService, private msal: MSALService) { }

  retrievePartnerData(clientId: string) {
    let auth = this.spData.GetScopeValue();
    return this.msal.getToken(auth.iPortalScope).pipe(switchMap((res) => {
      let headrs = new HttpHeaders()
        .append("apiKey", auth.iPortalKey)
        .append("Authorization", `Bearer ${res}`);

      let url = `${auth.iPortalUrl}/services-1.5.0/partner/${clientId}/basicInfo,teamInfo,crrInfo,balanceInfo,productCount,team,relatedProjects?start=-1&limit=-1`;
      return this.httpClient.get<iPortalPartnerResult>(url, {
        headers: headrs
      }).pipe(
        concatMap(result => {
          let basicInfo = result.data.basicInfo.data;
          let crrInfo = result.data.crrInfo.data;
          let balanceInfo = result.data.balanceInfo.data;
          let cTeam = result.data.team.data[0].roles;
          let mTeam = result.data.team.data[1].roles;

          let partnerInfo: PartnerDetails = {
            partnerName: basicInfo.shortName,
            instituationNo: basicInfo.clientId,
            primarySector: basicInfo.sectorName,
            country: basicInfo.countryName,
            region: basicInfo.regionName,
            tier: basicInfo.tierName,
            countryRRCode: (crrInfo) ? crrInfo.countryRatingCode : 'None',
            countryRR: (crrInfo) ? crrInfo.countryRatingDesc : 'None',
            riskRating: (crrInfo) ? crrInfo.irp_pd_rating : 'None',
            riskRatingDate: (crrInfo) ? crrInfo.riskReviewDate : 'None',
            productCount: result.data.productCount.data,
            outstandingAmt: (balanceInfo) ? balanceInfo.outstandingAmt : null,
            disbursedAmt: (balanceInfo) ? balanceInfo.disbursedAmt : null,
            undisbursedAmt: (balanceInfo) ? balanceInfo.undisbursedAmt : null,
            relatedProjects: new Array<RelatedProjectData>,
            team: {
              regionalHead: (mTeam[1].primary !== null) ? mTeam[1].primary.accessorName : 'None',
              globalHead: (mTeam[2].primary !== null) ? mTeam[2].primary.accessorName : 'None',
              creditOfficer: (cTeam[3].primary !== null) ? cTeam[3].primary.accessorName : 'None',
              portfolioIO: (cTeam[3].primary !== null) ? cTeam[3].primary.accessorName : 'None'
            }
          }

          let observables: Array<Observable<any>> = [];
          let relatedProjects = result.data.relatedProjects.data;
          relatedProjects.forEach(item => {
            let proj = {
              projectId: item.relatedProject.data.projectId,
              projectName: item.relatedProject.data.projectName,
              projectShortName: item.relatedProject.data.projectShortName,
              clientName: item.relatedProject.data.clientName,
              clientId: item.relatedProject.data.clientId,
              projectCountry: item.relatedProject.data.countryName,
              projectDisbursedAmt: (item.projectBalance.data) ? item.projectBalance.data.disbursedAmt : null,
              projectOutstandingAmt: (item.projectBalance.data) ? item.projectBalance.data.outstandingAmt : null,
              projectUndisbursedAmt: (item.projectBalance.data) ? item.projectBalance.data.undisbursedAmt : null,
            };
            partnerInfo.relatedProjects.push(proj);
            observables.push(this.retrieveProjectDetails(item.relatedProject.data.projectId.toString()));
          })

          return forkJoin(observables).pipe(map(results => {
            results.forEach((result, index) => {
              partnerInfo.relatedProjects[index] = Object.assign(partnerInfo.relatedProjects[index], result);
            })
            return partnerInfo;
          }))
        }))
    }));
  }

  retrievePartnerTeam(clientId: string) {
    let auth = this.spData.GetScopeValue();

    return this.msal.getToken(auth.iPortalScope).pipe(switchMap((res) => {
      let headrs = new HttpHeaders()
        .append("apiKey", auth.iPortalKey)
        .append("Authorization", `Bearer ${res}`);
      //let url = `https://api1stg.ifc.org/services-1.5.0/partner/${clientId}/team?format=jsonp`;
      //let url = `https://api1.ifc.org/services-1.5.0/partner/${clientId}/team?format=jsonp`;
      let url = `${auth.iPortalUrl}/services-1.5.0/partner/${clientId}/team?format=jsonp`;

      return this.httpClient.get(url, {
        headers: headrs
      })
    }));
  }

  retrieveProjectDetails(projectId: string) {
    let auth = this.spData.GetScopeValue();

    return this.msal.getToken(auth.iPortalScope).pipe(switchMap((res) => {
      let headrs = new HttpHeaders()
        .append("apiKey", auth.iPortalKey)
        .append("Authorization", `Bearer ${res}`);

      let url = `${auth.iPortalUrl}/ideskintegration/project/${projectId}/details?format=jsonp`;
      return this.httpClient.get<iPortalProjectResult>(url, {
        headers: headrs
      }).pipe(
        map(result => {
          let iProject = result.data[0].Project;
          let formattedStart = (iProject.project_details.cso_start_date) ? iProject.project_details.cso_start_date.split('-') : null;
          let formattedEnd = (iProject.project_details.cso_end_date) ? iProject.project_details.cso_end_date.split('-') : null;
          let relatedReturn = {
            csoStatus: iProject.project_details.cso_status,
            csoStatusCode: iProject.project_details.cso_status_code,
            csoStartDate: (formattedStart) ? new Date(parseInt(formattedStart[0]), parseInt(formattedStart[1]) - 1, parseInt(formattedStart[2])) : null,
            csoEndDate: (formattedEnd) ? new Date(parseInt(formattedEnd[0]), parseInt(formattedEnd[1]) - 1, parseInt(formattedEnd[2])) : null,
            projectRegion: iProject.project_basic_info.region,
            projectFirstDisbursement: iProject.project_details.first_disb_actual_date,
            projectLastDisbursement: null,
            projectOwningDept: iProject.project_basic_info.owning_dept_div,
            projectIndustryGroupSector: iProject.project_basic_info.ind_grp_sector_category,
            projectSector: iProject.project_basic_info.sector_name,
            projectTier: iProject.project_basic_info.project_tier,
            projectGreenField: iProject.project_basic_info.green_field_name,
            projectCategory: iProject.project_basic_info.category_name,
            projectSubCategory: iProject.project_basic_info.sub_category_name,
            primaryIONewBusiness: iProject.project_details.primary_IO_newBusiness,
            primaryIOPortfolio: iProject.project_details.primary_IO_portfolio
          }
          return relatedReturn;
        }))
    }));
  }

  retrieveProjectProducts(projectId: string) {
    let auth = this.spData.GetScopeValue();

    return this.msal.getToken(auth.iPortalScope).pipe(switchMap((res) => {
      let headrs = new HttpHeaders()
        .append("apiKey", auth.iPortalKey)
        .append("Authorization", `Bearer ${res}`);
      //let url = `https://iportalapp.ifc.org/projectcycle/ProductSummary/Index/${projectId}`;
      //let url = `https://iportalappstg.ifc.org/projectcycle/ProductSummary/Index/${projectId}`;
      let url = `${auth.iPortalUrl}/projectcycle/ProductSummary/index/${projectId}`;
      return this.httpClient.get(url, {
        headers: headrs
      })
    }));
  }

  retrieveProjectSimilar(projectId: string) {
    let auth = this.spData.GetScopeValue();

    return this.msal.getToken(auth.iPortalScope).pipe(switchMap((res) => {
      let headrs = new HttpHeaders()
        .append("apiKey", auth.iPortalKey)
        .append("Authorization", `Bearer ${res}`);
      //let url = `https://iportalappstg.ifc.org/projectcycle/SimilarProjects/List?Id=${projectId}`;
      //let url = `https://iportalapp.ifc.org/projectcycle/SimilarProjects/List?Id=${projectId}`
      let url = `${auth.iPortalUrl}/projectcycle/SimilarProjects/List?Id=${projectId}`;
      return this.httpClient.get(url, {
        headers: headrs
      })
    }));
  }
}
