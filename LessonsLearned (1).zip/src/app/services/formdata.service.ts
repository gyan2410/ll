import { Injectable } from '@angular/core';
import { AppData, AppStates } from '../../types/AppData';

@Injectable({
  providedIn: 'root'
})
export class FormDataService {
  public data: AppData;

  constructor() {
    this.data = {
      formData: {} as any,
      stateData: {},
      projectData: {} as any,
      financialInstruments: null,
      risksDisplayPanel: [0, 0, 0, 0, 0]
    };
    this.resetData();
  }

  resetData() {
    this.data.formData = {
      //relevantSecurities: [],
      accessibility: 'internal',
      attachments: [],
      attachmentsToUpload: [],
      author: '',
      curator: '',
      investmentHistory: [],
      investmentTeam: {} as any,
      iPortalData: {} as any,
      recoveryStrategies: [],
      recoveryStrategiesInfo: {},
      relevantSupport: [],
      riskFactors: [],
      riskFactorsInfo: [],
      securityTypeOtherSpecification: [],
      selectedExitAlternatives: [],
      selectedExitOptions: [],
      selectedFinancialInstruments: [],
      selectedSecurityTypes: [],
      team: {} as any,
      updateUri: '',
      workoutOutcomes: [],
      workoutOutcomesInfo: {}
    };
    this.data.projectData = {} as any;
    this.data.stateData = {
      routeCurr: AppStates.form,
      DetailsController: 'untouched',
      StrategyController: 'untouched',
      LessonsController: 'untouched',
      RisksController: 'untouched',
      SponsorController: 'untouched',
      SummaryController: 'untouched'
    };
  }
}
