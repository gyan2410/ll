import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppconstantsService } from './appconstants.service';

@Injectable({
  providedIn: 'root'
})
export class UtilitiesService {
  qaUrl: string = 'https://worldbankgroup.sharepoint.com';

  constructor(private spData: AppconstantsService) { }

  hostUrl() {
    return (window.location.hostname === 'localhost') ? this.qaUrl : window.location.origin;
  }

  siteCollectionUrl(appendUrl: string) {
    var addUrl = appendUrl || '';

    if (window.location.hostname === 'localhost') {
      return `${this.qaUrl}/sites/CSODev/lessons${addUrl}`;
    }

    var currUrl = window.location.href.toLowerCase();
    var appIndex = currUrl.indexOf('csoapp') - 1;
    return window.location.href.substring(0, appIndex) + addUrl;
  }

  GetEnvValue(value: string) {
    switch (window.location.hostname) {
      case 'localhost':
      case 'wbgmsspcso001':
        return this.spData.envIds.csoSPO[value];
      case 'spsecqa.ifc.org':
      case 'spsecnqa.ifc.org':
        return this.spData.envIds.csoDev[value];
      case 'spsec.ifc.org':
        return this.spData.envIds.csoProd[value];
      case 'worldbankgroup.sharepoint.com':
        return this.spData.envIds.csoSPO[value];
    }
    return { columnId: '', termStoreId: '' };
  }

  getPersonPhoto(accountEmail: string, photoSize: string = 'M') {
    return `/_layouts/15/userphoto.aspx?size=${photoSize}&accountname=${accountEmail}`;
  }
  
  setLocalStorageValue(key: string, value: string, expiration: Date) {
    let val = {
      expiration: expiration,
      value: value
    };
    localStorage.setItem(key, JSON.stringify(val));
  }
  getLocalStorageValue(key: string): string | null {
    let val = localStorage.getItem(key);
    if (val != null) {
      let p = JSON.parse(val);
      let now = new Date();
      if (new Date(Date.parse(p.expiration)) > now) {
        return p.value;
      }
      else {
        localStorage.removeItem(key);
        return null;
      }
    }
    return val;
  }
}
