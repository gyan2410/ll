import { TestBed } from '@angular/core/testing';

import { SharePointService } from './sharepoint.service';

describe('SharePointService', () => {
  let service: SharePointService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SharePointService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
