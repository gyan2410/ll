import { TestBed } from '@angular/core/testing';

import { IPortalDataService } from './iportaldata.service';

describe('IPortalDataService', () => {
  let service: IPortalDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IPortalDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
