import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuillModule } from 'ngx-quill';
import { PersonDataResolver } from './resolvers/persondata.resolver';
import { MsalRedirectComponent } from '@azure/msal-angular';
import { RootComponent } from './content/root/root.component';

const routes: Routes = [
  /*{
    path: '',
    redirectTo: '/form',
    pathMatch: 'full'
  },*/
  {
    path: '',
    component: RootComponent
  },
  {
    path: 'form',
    loadChildren: () => import('./content/form/form.module').then(m => m.FormModule)
  },
  {
    path: 'render',
    loadChildren: () => import('./content/render/render.module').then(m => m.RenderModule),
    resolve: {
      spPersonData: PersonDataResolver
    }
  },
  {
    // Needed for handling redirect after login
    path: 'auth',
    component: MsalRedirectComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, onSameUrlNavigation: 'reload' }), QuillModule.forRoot()],
  exports: [RouterModule]
})
export class AppRoutingModule { }
