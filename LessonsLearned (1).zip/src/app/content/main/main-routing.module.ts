import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckLessonResolver } from 'src/app/resolvers/checklesson.resolver';
import { AppStates } from 'src/types/AppData';
import { DetailsComponent } from '../details/details.component';
import { LessonsComponent } from '../lessons/lessons.component';
import { RisksComponent } from '../risks/risks.component';
import { SponsorComponent } from '../sponsor/sponsor.component';
import { StrategyComponent } from '../strategy/strategy.component';
import { SummaryComponent } from '../summary/summary.component';
import { MainComponent } from './main.component';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    pathMatch: 'full'
  },
  {
    path: 'details/:type/:id',
    component: DetailsComponent,
    data: {
      prev: AppStates.summary,
      next: AppStates.risks
    },
    resolve: {
      resolveData: CheckLessonResolver
    }
  },
  {
    path: 'risks/:type/:id',
    component: RisksComponent,
    data: {
      prev: AppStates.details,
      next: AppStates.sponsor
    },
    resolve: {
      resolveData: CheckLessonResolver
    }
  },
  {
    path: 'strategy/:type/:id',
    component: StrategyComponent,
    data: {
      prev: AppStates.sponsor,
      next: AppStates.lessons
    },
    resolve: {
      resolveData: CheckLessonResolver
    }
  },
  {
    path: 'lessons/:type/:id',
    component: LessonsComponent,
    data: {
      prev: AppStates.strategy,
      next: AppStates.summary
    },
    resolve: {
      resolveData: CheckLessonResolver
    }
  },
  {
    path: 'sponsor/:type/:id',
    component: SponsorComponent,
    data: {
      prev: AppStates.risks,
      next: AppStates.strategy
    },
    resolve: {
      resolveData: CheckLessonResolver
    }
  },
  {
    path: 'summary/:type/:id',
    component: SummaryComponent,
    data: {
      prev: AppStates.lessons,
      next: AppStates.details
    },
    resolve: {
      resolveData: CheckLessonResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainRoutingModule { }
