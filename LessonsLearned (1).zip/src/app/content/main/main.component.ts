import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, take, throwError } from 'rxjs';
import { AppconstantsService } from 'src/app/services/appconstants.service';
import { DatacontextService } from 'src/app/services/datacontext.service';
import { FormDataService } from 'src/app/services/formdata.service';
import { AppStateData, AppStates } from 'src/types/AppData';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  currState: AppStateData;
  loading = false;
  loadProjectError = false;
  sessionExpired = false;
  accessDenied = false;
  authUrl: string = '';

  constructor(public fdSvc: FormDataService, private dataContext: DatacontextService, private title: Title, private router: Router, private appConstants: AppconstantsService, private activateRoute: ActivatedRoute) {
    this.currState = this.fdSvc.data.stateData;
    this.fdSvc.data.stateData.routeCurr = AppStates.form;
  }

  ngOnInit(): void {
    this.authUrl = this.appConstants.iPortalUrls.iDesk;
  }

  initialLoad() {
    this.loadProjectError = false;
    this.sessionExpired = false;
    this.accessDenied = false;
    this.loading = true;

    this.dataContext.loadProject(this.fdSvc.data.projectData.projectIdOrTitle, true).pipe(take(1)).subscribe({
      next: (result) => {
        this.loading = false;
        this.title.setTitle(`${this.fdSvc.data.projectData.projectId} : Lesson Input`);
        this.router.navigate(['details', this.fdSvc.data.formData.accessibility, this.fdSvc.data.projectData.projectId], { relativeTo: this.activateRoute});
      },
      error: (err) => {
        if (err.status === 0 && err.statusText.toLowerCase() === 'jsonp error') {
          this.authUrl = this.authUrl + this.fdSvc.data.projectData.projectIdOrTitle + '/details?format=jsonp&callback=JSON_CALLBACK';
          this.sessionExpired = true;
        } else if (err.header.accessLevel === 'DENIED') {
          this.accessDenied = true;
        } else {
          this.loadProjectError = true;
        }
        this.loading = false;
      }
    })
  }
}
