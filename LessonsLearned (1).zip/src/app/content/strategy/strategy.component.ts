import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, Observable, Subject, takeUntil } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { TaxonomyService } from 'src/app/services/taxonomy.service';
import { UtilitiesService } from 'src/app/services/utilities.service';
import { AppMetaDataField, AppStateData, AppStates } from 'src/types/AppData';

@Component({
  selector: 'app-strategy',
  templateUrl: './strategy.component.html',
  styleUrls: ['./strategy.component.scss']
})
export class StrategyComponent implements OnInit, OnDestroy {
  unsubscribe$ = new Subject<boolean>();
  currState: AppStateData;
  formGroup: FormGroup;
  interactionNote = '';
  stratObs$!: Observable<any>;
  outcomeObs$!: Observable<any>;
  selectedIndexStrat = 0;
  selectedIndexOutcome = 0;

  constructor(public fdSvc: FormDataService, private activatedRoute: ActivatedRoute, private router: Router, private fb: FormBuilder, private utilService: UtilitiesService, private taxonomy: TaxonomyService) {
    this.router.events.pipe(takeUntil(this.unsubscribe$)).subscribe(routeEvent => {
      if (routeEvent instanceof NavigationStart) {
        this.fdSvc.data.stateData.StrategyController = this.formGroup.status;
      }
    })

    this.currState = this.fdSvc.data.stateData;
    this.currState.routeProjectType = this.activatedRoute.snapshot.params['type'];
    this.currState.routeProjectId = this.activatedRoute.snapshot.params['id'];
    this.fdSvc.data.stateData.routeCurr = AppStates.strategy;
    this.currState.routeNext = this.activatedRoute.snapshot.data['next'];
    this.currState.routePrev = this.activatedRoute.snapshot.data['prev'];

    let currForm = this.fdSvc.data.formData;
    this.formGroup = this.fb.group({
      recoveryStrategies: this.fb.array([]),
      workoutOutcomes: this.fb.array([]),
      recoveryStrategyDetails: [currForm.recoveryStrategyDetails, Validators.required],
      recoveryMetric: [currForm.recoveryMetric]
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
  }

  ngOnInit(): void {
    this.stratObs$ = this.taxonomy.getAllTerms(this.utilService.GetEnvValue('workoutStrategy').termStoreId);
    this.outcomeObs$ = this.taxonomy.getAllTerms(this.utilService.GetEnvValue('workoutOutcome').termStoreId);
    let currForm = this.fdSvc.data.formData;
    if (currForm.recoveryStrategiesInfo) {
      let keys = Object.keys(currForm.recoveryStrategiesInfo);
      keys.forEach(key => {
        let strat = currForm.recoveryStrategiesInfo[key];
        this.addStrat(key, strat);
      })
    } else {
      currForm.recoveryStrategiesInfo = {} as any;
    }
    if (currForm.workoutOutcomesInfo) {
      let keys = Object.keys(currForm.workoutOutcomesInfo);
      keys.forEach(key => {
        let outcome = currForm.workoutOutcomesInfo[key];
        this.addOutcome(key, outcome);
      })
    } else {
      currForm.workoutOutcomesInfo = {} as any;
    }

    this.formGroup.valueChanges.pipe(
      distinctUntilChanged(),
      debounceTime(500),
      takeUntil(this.unsubscribe$)
    ).subscribe(valueChange => {
      console.info({ 'formData: ': this.fdSvc }, { 'valueChange: ': valueChange }, { 'formGroup: ': this.formGroup });
      if (valueChange.recoveryStrategies) {
        valueChange.recoveryStrategies.forEach((recoveryStrat: any) => {
          currForm.recoveryStrategiesInfo[recoveryStrat.id] = {
            defaultLabel: recoveryStrat.defaultLabel,
            details: recoveryStrat.details,
            parent: recoveryStrat.parent
          }
        });
      }
      if (valueChange.workoutOutcomes) {
        valueChange.workoutOutcomes.forEach((outcome: any) => {
          currForm.workoutOutcomesInfo[outcome.id] = {
            details: outcome.details,
            partial: outcome.partial
          }
        })
      }
      currForm.recoveryStrategyDetails = valueChange.recoveryStrategyDetails;
      currForm.recoveryMetric = valueChange.recoveryMetric;
    })
  }

  addStrat(id: string, stratInfo: any) {
    if (!this.fdSvc.data.formData.recoveryStrategiesInfo) {
      this.fdSvc.data.formData.recoveryStrategiesInfo = {};
    }
    if (this.fdSvc.data.formData.recoveryStrategiesInfo) {
      const control = this.formGroup.controls['recoveryStrategies'] as FormArray<FormGroup<any>>;
      const newStrat = this.fb.group({
        id: id,
        defaultLabel: [stratInfo.defaultLabel],
        details: [stratInfo.details, Validators.required],
        parent: [stratInfo.parent]
      });
      control.push(newStrat);
    }
  }

  addOutcome(id: string, outcomeInfo: any) {
    if (!this.fdSvc.data.formData.workoutOutcomesInfo) {
      this.fdSvc.data.formData.workoutOutcomesInfo = {};
    }
    if (this.fdSvc.data.formData.workoutOutcomesInfo) {
      const control = this.formGroup.controls['workoutOutcomes'] as FormArray<FormGroup<any>>;
      const newOutcome = this.fb.group({
        id: id,
        defaultLabel: [outcomeInfo.defaultLabel],
        partial: [outcomeInfo.partial],
        details: [outcomeInfo.details, Validators.required],
        parent: [outcomeInfo.parent]
      });
      control.push(newOutcome);
    }
  }

  get dynamicStrats() {
    return this.formGroup.get('recoveryStrategies') as FormArray<FormGroup<any>>;
  }

  get dynamicOutcomes() {
    return this.formGroup.get('workoutOutcomes') as FormArray<FormGroup<any>>;
  }

  stratAdded(chip: AppMetaDataField) {
    if (!this.fdSvc.data.formData.recoveryStrategies) {
      this.fdSvc.data.formData.recoveryStrategies = [];
    }
    if (this.fdSvc.data.formData.recoveryStrategies) {
      const control = this.formGroup.controls['recoveryStrategies'] as FormArray<FormGroup<any>>;
      const newStrat = this.fb.group({
        id: chip.id,
        defaultLabel: chip.defaultLabel,
        details: ['', Validators.required],
        parent: chip.parentName
      });
      control.push(newStrat);
      this.selectedIndexStrat = control.length - 1;
    }
  }

  stratRemoved(data: { index: number, term: AppMetaDataField }) {
    if (this.fdSvc.data.formData.recoveryStrategiesInfo) {
      delete this.fdSvc.data.formData.recoveryStrategiesInfo[data.term.id];
      this.dynamicStrats.removeAt(data.index);
    }
  }

  stratSelected(data: { index: number, term: AppMetaDataField }) {
    this.selectedIndexStrat = data.index;
  }

  outcomeAdded(chip: AppMetaDataField) {
    if (!this.fdSvc.data.formData.workoutOutcomes) {
      this.fdSvc.data.formData.workoutOutcomes = [];
    }
    if (this.fdSvc.data.formData.workoutOutcomes) {
      const control = this.formGroup.controls['workoutOutcomes'] as FormArray<FormGroup<any>>;
      const newOutcome = this.fb.group({
        id: chip.id,
        defaultLabel: chip.defaultLabel,
        partial: [false],
        details: ['', Validators.required],
        parent: chip.parentName
      });
      control.push(newOutcome);
      this.selectedIndexOutcome = control.length - 1;
    }
  }

  outcomeRemoved(data: { index: number, term: AppMetaDataField }) {
    if (this.fdSvc.data.formData.workoutOutcomesInfo) {
      delete this.fdSvc.data.formData.workoutOutcomesInfo[data.term.id];
      this.dynamicOutcomes.removeAt(data.index);
    }
  }

  outcomeSelected(data: { index: number, term: AppMetaDataField }) {
    this.selectedIndexOutcome = data.index;
  }

  removeStratTab(index: number) {
    let fbArr = this.formGroup.controls['recoveryStrategies'] as FormArray;
    let stratId = fbArr.at(index).get('id')?.value;
    if (stratId) {
      delete this.fdSvc.data.formData.recoveryStrategiesInfo[stratId];
    }
    fbArr.removeAt(index);
  }

  removeOutcomeTab(index: number) {
    let fbArr = this.formGroup.controls['workoutOutcomes'] as FormArray;
    let outcomeId = fbArr.at(index).get('id')?.value;
    if (outcomeId) {
      delete this.fdSvc.data.formData.workoutOutcomesInfo[outcomeId];
    }
    fbArr.removeAt(index);
  }
}
