import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RenderRoutingModule } from './render-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RenderRoutingModule
  ]
})
export class RenderModule { }
