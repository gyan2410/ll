import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RenderLessonResolver } from 'src/app/resolvers/renderlesson.resolver';
import { RenderComponent } from './render.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/form'
  },
  {
    path: ':type/:id',
    component: RenderComponent,
    resolve: {
      resolveData: RenderLessonResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RenderRoutingModule { }
