import { ViewportScroller } from '@angular/common';
import { AfterViewInit, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer, Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { take } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { SharePointService } from 'src/app/services/sharepoint.service';
import { SharePointDataService } from 'src/app/services/sharepointdata.service';
import { UtilitiesService } from 'src/app/services/utilities.service';
import { AppAttachmentFile, AppData, AppFormData } from 'src/types/AppData';
import { CountryCoordinate } from 'src/types/CountryCoordinate';
import { RelatedProjectData } from 'src/types/RelatedProject';
import { RiskInfo } from '../risks/risks.component';

interface IRiskFactors {
  High: RiskInfo[];
  Normal: RiskInfo[];
  Low: RiskInfo[];
  None: RiskInfo[];
}

@Component({
  selector: 'app-render',
  templateUrl: './render.component.html',
  styleUrls: ['./render.component.scss']
})
export class RenderComponent implements OnInit, AfterViewInit {
  @ViewChild('termsDialog') termsDialog!: TemplateRef<HTMLElement>
  authorEmail!: string;
  authorName!: string;
  authorPhoto!: string;
  curatorEmail!: string;
  curatorName!: string;
  curatorPhoto!: string;
  currForm: AppFormData;
  dataIFC!: RelatedProjectData;
  generatingDoc = false;
  lessonImageUrl!: string;
  loadError: boolean = false;
  loading = true;
  projectData: any;
  riskFactors!: IRiskFactors;
  siteUrl!: string;
  acceptError!: string;
  attachments!: AppAttachmentFile[];
  imageLoaded: boolean = true;

  constructor(public fdSvc: FormDataService, private activatedRoute: ActivatedRoute, private utils: UtilitiesService, private vps: ViewportScroller, private title: Title, private spDataService: SharePointDataService, private spService: SharePointService, private matDialog: MatDialog, public sanitizer: DomSanitizer) {
    console.info('Route: ', this.activatedRoute.snapshot);
    this.currForm = this.fdSvc.data.formData;
  }

  ngOnInit(): void {
    if (this.currForm.accessibility === 'official') {
      this.siteUrl = `${this.utils.siteCollectionUrl('')}/../external`;
    } else {
      this.siteUrl = `${this.utils.siteCollectionUrl('')}/..`;
    }
    this.vps.scrollToPosition([0, 0]);
    this.title.setTitle(`Lesson Learned (${this.fdSvc.data.projectData.projectId})`);
    this.lessonImageUrl = (this.currForm.lessonImageUrl && this.currForm.lessonImageUrl.indexOf('http') >= 0) ? encodeURI(this.currForm.lessonImageUrl) : encodeURI(this.currForm.lessonImageUrl || '');
    this.initializeProjectData();
    this.initializeRiskData();
    this.initializePersonData();
    this.getCountryCoordinates();

    this.attachments = this.currForm.attachments.filter(item => {
      if (!this.isImageFile(item.fileName)) {
        if (item.fileName.indexOf('.doc') > 0 || item.fileName.indexOf('.docx') > 0) {
          item.fileExtension = 'docx';
        } else if (item.fileName.indexOf('.xls') > 0 || item.fileName.indexOf('.xlsx') > 0) {
          item.fileExtension = 'xlsx';
        } else if (item.fileName.indexOf('.ppt') > 0 || item.fileName.indexOf('.pptx') > 0) {
          item.fileExtension = 'pptx';
        } else if (item.fileName.indexOf('.pdf') > 0) {
          item.fileExtension = 'pdf';
        } else {
          item.fileExtension = '';
        }
        return item;
      }
      return;
    })
  }

  ngAfterViewInit(): void {
    this.initializeTerms();
    console.log(this);
  }

  initializeProjectData() {
    let formData = this.fdSvc.data.formData;
    if (formData.iPortalData && formData.iPortalData.relatedProjects) {
      formData.iPortalData.relatedProjects.some(iProject => {
        if (iProject.projectId.toString() === formData.projectId) {
          this.dataIFC = iProject;
          this.loadError = false;
          this.loading = false;
          return true;
        }
        return false;
      });
    }
    if (this.fdSvc.data.projectData.loadProjectError === true) {
      this.projectData = this.fdSvc.data.projectData;
      this.loadError = true;
      this.loading = false;
      return;
    }
  }

  initializeRiskData() {
    this.riskFactors = { High: [], Normal: [], Low: [], None: [] }
    this.currForm.riskFactorsInfo.forEach(element => {
      switch (element.riskLevel) {
        case "High":
          this.riskFactors.High.push(element);
          break;
        case "Normal":
          this.riskFactors.Normal.push(element);
          break;
        case "Low":
          this.riskFactors.Low.push(element);
          break;
        default:
          this.riskFactors.None.push(element);
          break;
      }
    });
  }

  initializePersonData() {
    if (this.currForm.curator === null || this.currForm.curator == '') {
      this.curatorName = 'No Curator';
    } else {
      this.spDataService.getUserById(this.currForm.curator).pipe(take(1)).subscribe(curator => {
        this.curatorPhoto = this.siteUrl + this.utils.getPersonPhoto(curator.Email);
        this.curatorName = curator.Title;
        this.curatorEmail = curator.Email;
      });
    }

    if (this.currForm.author === null || this.currForm.author == '') {
      this.authorName = 'No Author';
    } else {
      this.spDataService.getUserById(this.currForm.author).pipe(take(1)).subscribe(author => {
        this.authorPhoto = this.siteUrl + this.utils.getPersonPhoto(author.Email);
        this.authorName = author.Title;
        this.authorEmail = author.Email;
      });
    }
  }

  initializeTerms() {
    var accepted = window.sessionStorage.getItem('lessonTerms');
    if (!accepted) {
      let dialogRef = this.matDialog.open(this.termsDialog, {
        disableClose: true,
        panelClass: 'cso-terms-dialog'
      });
      dialogRef.afterClosed().pipe(take(1)).subscribe(accepted => {
        if (accepted) {
          window.sessionStorage.setItem('lessonTerms', 'true');
        } else {
          this.acceptError = 'You have chosen to decline the confidentiality requirement associated with this content and so you will not be able to proceed further to view the Lesson Learned. You will now be redirected to the homepage.';
          this.loadError = true;
          window.setTimeout(() => {
            if (this.currForm.accessibility === 'official') {
              console.log(this.utils.siteCollectionUrl('/../external'));
              window.location.replace(this.utils.siteCollectionUrl('/../external'));
            } else {
              console.log(this.utils.siteCollectionUrl('/../'));
              window.location.replace(this.utils.siteCollectionUrl('/../'));
            }
          }, 4000)
        }
      })
    }
  }

  getCountryCoordinates() {
    this.spService.getListItems<Array<CountryCoordinate>>('CountryCoordinates', {
      $filter: `Title eq '${this.fdSvc.data.formData.iPortalData.country}'`,
      $select: 'Title,Latitude,Longitude,Zoom'
    }).pipe(take(1)).subscribe(coordsArray => {
      if (coordsArray.length) {
        this.fdSvc.data.formData.CountryZoom = coordsArray[0].Zoom;
        this.fdSvc.data.formData.CountryCoords = `${coordsArray[0].Latitude},${coordsArray[0].Longitude}`;
      }
    })
  }

  isImageFile(fileUrl: string) {
    let imageExtentionTypes = ['.jpg', '.jpeg', '.gif', '.png'];
    return imageExtentionTypes.some(ext => fileUrl.toLowerCase().indexOf(ext) > -1);
  }

  envType() {
    return window.location.href.toLowerCase().indexOf('official') === -1;
  }

  scrollTo(anchor: string) {
    let yOffSet = -40;
    let wOffSet = (window.pageYOffset < 90) ? -(90 - window.pageYOffset) : window.pageYOffset + yOffSet;
    let docElem = document.getElementById(anchor) as HTMLElement;
    let boundingCalc = docElem.getBoundingClientRect().top;
    let y = boundingCalc + wOffSet;
    window.scrollTo({ top: y, behavior: "smooth" });
  }

  errorLessonImageLoad(event: Event) {
    (event.target as HTMLImageElement).style.display = 'none';
    this.imageLoaded = false;
  }

  downloadDocument(fileType: string) {
    this.generatingDoc = true;
    var data = this.buildDataObject();
    console.log('this is data: ', data);
    var rawJson = JSON.stringify({"data": data, "fileType": fileType, "renderType": this.currForm.accessibility});
    var xhr = new XMLHttpRequest();
    // Post for Dev
     xhr.open("POST", "https://ifc-cso-docgen-dev.cit-ouo-ase-asev3-dev.appserviceenvironment.net/api/GenerateFile?code=u_gZrzJznxCsIgbLOGdZWgO3AcKXvNTY6itijf6hsXz6AzFu1MUt8Q==");
    // Post for Production
   // xhr.open("POST", "https://ifc-cso-docgen-prod.cit-common-sc-asev3-prod.appserviceenvironment.net/api/GenerateFile?code=TVKvF7dEzK2gFYMjN8ynJU0Uc73eLLnh6dF084-XNunTAzFutC6TDg==");

    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.withCredentials = false;
    xhr.responseType = 'blob';
    xhr.onload = () => {
      if (xhr.status === 200) {
        var blob = xhr.response;
        var link = window.document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = data.Title + '_' + new Date().toLocaleDateString() + "." + fileType;
        link.click();
        //saveAs(xhr.response, new Date() + ".docx");
      }
      this.generatingDoc = false;
    };
    xhr.onerror = () => {
        this.generatingDoc = false;
    }
    xhr.send(rawJson);
  }

  buildDataObject() {
    var startDate = this.dataIFC.csoStartDate ? new Date(this.dataIFC.csoStartDate) : null;
    var endDate = this.dataIFC.csoEndDate ? new Date(this.dataIFC.csoEndDate) : null;
    var csoStartDate = startDate ? startDate.toLocaleDateString() : 'None';
    var csoEndDate = endDate ? endDate.toLocaleDateString() : 'None';
    var payload: any = {
      Title: (this.dataIFC) ? this.dataIFC.clientName?.trim() : '',
      // TODO Author
      Author: this.authorName || this.curatorName,
      // TODO Date published
      DatePublished: '' || '',
      Summary: this.currForm.projectOverview || '',
      PrimaryIONewBusiness: this.currForm.investmentTeam.primaryIONB || 'None',
      RegionalIndustryHead: this.currForm.investmentTeam.regionalHead || 'None',
      GlobalIndustryHead: this.currForm.investmentTeam.globalHead || 'None',
      PrimaryIOPortfolio: this.currForm.investmentTeam.primaryIOP || 'None',
      InvestmentLeader: this.currForm.investmentTeam.investmentLeader || 'None',
      CreditOfficer: this.currForm.investmentTeam.creditOfficer || 'None',
      CSODirector: this.currForm.team.csoDirector || 'None',
      CSOLeadIO: this.currForm.team.csoLeadIo || 'None',
      CSOSecondIO: this.currForm.team.csoSecondIo || 'None',
      CSOLawyer: this.currForm.team.csoLawyer || 'None',
      Country: this.currForm.iPortalData.country || '',
      CountryZoom: this.currForm.CountryZoom || 5,
      CountryCoords: this.currForm.CountryCoords || '',
      CompanySponsor: this.currForm.summarySponsor || '',
      Investment: this.currForm.summaryInvestment || '',
      Security: this.currForm.summarySecurity || '',
      RiskFactors: Object.keys(this.riskFactors).reduce((acum: any, cur: any) => {
        return acum.concat((this.riskFactors[cur as keyof IRiskFactors]).map((x: any) => {
          return {
            Title: x.defaultLabel,
            Level: x.riskLevel || 'None',
            Identified: x.identified ? 'Yes' : 'No',
            Materialized: x.materialized ? 'Yes' : 'No',
            Details: x.details,
            Structure: x.structure ? 'Yes' : 'No',
            Portfolio: x.portfolio ? 'Yes' : 'No'
          }
        }));
      }, []),
      TransferReason: this.currForm.transferReason || '',
      InvestmentHistory: this.currForm.investmentHistory.map(function (x) { return x.defaultLabel }),
      ExperienceRating: this.currForm.clientExperience || '',
      ExperienceDetails: this.currForm.clientExperienceDetails || '',
      ImproperActivity: this.currForm.illegalActions || '',
      CorporateGovernance: this.currForm.breachSuspicions || '',
      RecoveryStrategies: this.currForm.recoveryStrategies.map(
        (x) => { return { Title: x.defaultLabel, Text: this.returnDetails(x.defaultLabel) } }
      ),
      RecoveryStrategyDetails: this.currForm.recoveryStrategyDetails || '',
      RecoveryOutcomes: this.currForm.workoutOutcomes.map(
        (x) => { return { Title: x.defaultLabel, Text: this.returnDetailOutcome(x.defaultLabel,this.currForm.workoutOutcomesInfo) || '' } }
      ),
      RecoveryMetric: this.currForm.recoveryMetric || 'None Provided.',
      IFCLessonsLearned: this.currForm.ifcLessonsLearned || 'None Provided',
      CSOLessonsLearned: this.currForm.csoLessonsLearned || 'None Provided',
      ProjectDetails: {
        ProjectID: this.dataIFC.projectId || '',
        ShortName: this.dataIFC.projectShortName || '',
        DateOfTransfer: csoStartDate,
        DateOfResolution: csoEndDate,
        Country: this.dataIFC.projectCountry || '',
        Region: this.dataIFC.projectRegion || '',
        Sector: this.dataIFC.projectSector || '',
        Coinvestments: this.currForm.securityTypeOtherSpecification ? this.currForm.securityTypeOtherSpecification.join(', ') : 'None'
      },
      // TODO EXPOSURE DETAILS
      //ExposureDetails: null,
      FinancialInstruments: this.currForm.selectedFinancialInstruments || [],
      FinancialOtherInstruments: this.currForm.financialInstrumentOtherDetails || 'N/A',
      ExitAlternatives: this.currForm.selectedExitAlternatives || [],
      ExitAlternativesDetails: this.currForm.exitAlternativesOtherDetails || 'N/A',
      ExitAlternativesIssues: this.currForm.selectedExitOptions || [],
      ExitAlternativesOther: this.currForm.exitOptionOtherSpecification || 'N/A',
      ExitOtherRepayment: this.currForm.relevantSupport.map(
        (x) => { return x.defaultLabel }
      ) || [],
      SecurityTypes: this.currForm.selectedSecurityTypes || [],
      SecurityTypeDetails: this.currForm.securityTypeDetails || 'N/A',
      SecurityPerfected: this.currForm.securityPerfected || 'N/A',
      SecuityPerfection: this.currForm.securityPerfectionStatus || 'N/A',
      WarrantDetails: this.currForm.warrantExercised || 'N/A'
    }
    if (this.imageLoaded) {
      payload.Image = this.getBase64Image();
    }
    var cleanPayload = JSON.stringify(payload).replace(/ style=['](.*?)[']/g, '').replace(/ style=[\\]["](.*?)[\\]["]/g, '');
    return JSON.parse(cleanPayload);
  }

  getBase64Image() {
    var img = document.getElementById("lessonImage") as HTMLImageElement;
    if (img) {
      var canvas = document.createElement("canvas");
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      var ctx = canvas.getContext("2d");
      ctx?.drawImage(img, 0, 0);
      var dataURL = canvas.toDataURL("image/png");
      return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
    } else {
      return null;
    }
  }

  returnDetails(propertyValue: any) {
    var details = '';
    Object.keys(this.currForm.recoveryStrategiesInfo).forEach((key) => {
      var item = this.currForm.recoveryStrategiesInfo[key];
      if (item.defaultLabel === propertyValue) {
        details = item.details;
      }
    });
    return details;
  }

  returnDetailshtml(propertyValue: any, renderobject: any) {
    var details = '';
    Object.keys(renderobject).forEach((key) => {
      var item = renderobject[key];
      if (item.defaultLabel === propertyValue) {
        details = item.details;
      }
    });
    return details;
  }
  returnDetailOutcome(propertyValue: any, renderobject: any) {
    var details = '';
    Object.keys(renderobject).forEach((key) => {
      var item = renderobject[key];
      if (item.defaultLabel === propertyValue) {
        details = item.details;
     }
    });
    return details;
  }
}
