import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { AppStateData, AppStates } from 'src/types/AppData';

@Component({
  selector: 'app-lessons',
  templateUrl: './lessons.component.html',
  styleUrls: ['./lessons.component.scss']
})
export class LessonsComponent implements OnInit, OnDestroy {
  unsubscribe$ = new Subject<boolean>();
  currState: AppStateData;
  formGroup: FormGroup;
  interactionNote = '';

  constructor(public fdSvc: FormDataService, private activatedRoute: ActivatedRoute, private router: Router, private fb: FormBuilder) {
    this.router.events.pipe(takeUntil(this.unsubscribe$)).subscribe(routeEvent => {
      if (routeEvent instanceof NavigationStart) {
        this.fdSvc.data.stateData.LessonsController = this.formGroup.status;
      }
    })
    let currForm = this.fdSvc.data.formData;
    this.formGroup = this.fb.group({
      ifcLessonsLearned: [currForm.ifcLessonsLearned, Validators.required],
      csoLessonsLearned: [currForm.csoLessonsLearned, Validators.required]
    });

    this.currState = this.fdSvc.data.stateData;
    this.currState.routeProjectType = this.activatedRoute.snapshot.params['type'];
    this.currState.routeProjectId = this.activatedRoute.snapshot.params['id'];
    this.fdSvc.data.stateData.routeCurr = AppStates.lessons;
    this.currState.routeNext = this.activatedRoute.snapshot.data['next'];
    this.currState.routePrev = this.activatedRoute.snapshot.data['prev'];
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
  }

  ngOnInit(): void {
    this.formGroup.valueChanges.pipe(
      distinctUntilChanged(),
      debounceTime(500),
      takeUntil(this.unsubscribe$)
    ).subscribe(valueChange => {
      let currForm = this.fdSvc.data.formData;
      currForm.ifcLessonsLearned = valueChange.ifcLessonsLearned;
      currForm.csoLessonsLearned = valueChange.csoLessonsLearned;
    })
  }

}
