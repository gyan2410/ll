import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.scss']
})
export class RootComponent implements OnInit {

  constructor(private authService: MsalService, private router: Router) { }

  ngOnInit(): void {
    this.authService.handleRedirectObservable().subscribe();
    
    if(window.location.href.indexOf("#code") < 0) {
      this.router.navigateByUrl("/form");
    }
  }

}
