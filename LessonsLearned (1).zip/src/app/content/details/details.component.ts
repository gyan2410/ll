import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, Subject, take, takeUntil } from 'rxjs';
import { ClientContextService } from 'src/app/services/clientcontext.service';
import { FormDataService } from 'src/app/services/formdata.service';
import { SharePointDataService } from 'src/app/services/sharepointdata.service';
import { TaxonomyService } from 'src/app/services/taxonomy.service';
import { AppStateData, AppStates } from 'src/types/AppData';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit, OnDestroy {
  unsubscribe$ = new Subject<boolean>();
  currState: AppStateData;
  formGroup: FormGroup;
  interactionNote = '';

  constructor(public fdSvc: FormDataService, private activatedRoute: ActivatedRoute, private fb: FormBuilder, private spService: SharePointDataService, private router: Router) {
    this.router.events.pipe(takeUntil(this.unsubscribe$)).subscribe(routeEvent => {
      if (routeEvent instanceof NavigationStart) {
        this.fdSvc.data.stateData.DetailsController = this.formGroup.status;
      }
    })

    this.currState = this.fdSvc.data.stateData;
    this.currState.routeProjectType = this.activatedRoute.snapshot.params['type'];
    this.currState.routeProjectId = this.activatedRoute.snapshot.params['id'];
    this.fdSvc.data.stateData.routeCurr = AppStates.details;
    this.currState.routeNext = this.activatedRoute.snapshot.data['next'];
    this.currState.routePrev = this.activatedRoute.snapshot.data['prev'];

    let teamInfo = this.fdSvc.data.formData.team;
    let investmentTeam = this.fdSvc.data.formData.investmentTeam;
    this.formGroup = this.fb.group({
      primaryIONB: [investmentTeam?.primaryIONB || ''],
      regionalHead: [investmentTeam?.regionalHead || ''],
      globalHead: [investmentTeam?.globalHead || ''],
      primaryIOP: [investmentTeam?.primaryIOP || ''],
      investmentLeader: [investmentTeam?.investmentLeader || ''],
      creditOfficer: [investmentTeam?.creditOfficer || ''],
      csoDirector: [teamInfo.csoDirector || ''],
      csoLeadIo: [teamInfo.csoLeadIo || ''],
      csoSecondIo: [teamInfo.csoSecondIo || ''],
      csoLawyer: [teamInfo.csoLawyer || ''],
      lessonSummary: [this.fdSvc.data.formData.lessonSnippet || '', Validators.required],
      projectOverview: [this.fdSvc.data.formData.projectOverview || '', Validators.required],
      sponsorSummary: [this.fdSvc.data.formData.summarySponsor || '', Validators.required],
      investmentSummary: [this.fdSvc.data.formData.summaryInvestment || '', Validators.required],
      securitySummary: [this.fdSvc.data.formData.summarySecurity || '', Validators.required],
      transferReason: [this.fdSvc.data.formData.transferReason || '', Validators.required]
    })
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
  }

  ngOnInit(): void {
    this.spService.getUserById(this.fdSvc.data.formData.author as string).pipe(take(1)).subscribe(result => {
      this.fdSvc.data.formData.authorName = result.Title;
      this.fdSvc.data.formData.authorEmail = result.Email;
    })

    this.spService.loadProjectTeam(this.fdSvc.data.projectData.projectId).pipe(take(1)).subscribe(result => {
      let teamInfo = this.fdSvc.data.formData.team;
      result.forEach(member => {
        if (!teamInfo.csoDirector && member.ProjectRole.toLowerCase().indexOf('director') >= 0) {
          this.formGroup.controls['csoDirector'].setValue(member.ProjectMember.Title);
        }
        if (!teamInfo.csoLeadIo && member.ProjectRole.toLowerCase().indexOf('primary') >= 0 && member.ProjectRole.toLowerCase().indexOf('io') >= 0) {
          this.formGroup.controls['csoLeadIo'].setValue(member.ProjectMember.Title);
        }
        if (!teamInfo.csoSecondIo && member.ProjectRole.toLowerCase().indexOf('back-up') >= 0 && member.ProjectRole.toLowerCase().indexOf('io') >= 0) {
          this.formGroup.controls['csoSecondIo'].setValue(member.ProjectMember.Title);
        }
        if (!teamInfo.csoLawyer && member.ProjectRole.toLowerCase().indexOf('primary') >= 0 && member.ProjectRole.toLowerCase().indexOf('lawyer') >= 0) {
          this.formGroup.controls['csoLawyer'].setValue(member.ProjectMember.Title);
        }
      })
    })

    this.formGroup.valueChanges.pipe(
      distinctUntilChanged(),
      debounceTime(500),
      takeUntil(this.unsubscribe$)
    ).subscribe(valueChange => {
      if (this.fdSvc.data.formData.investmentTeam) {
        this.fdSvc.data.formData.investmentTeam.primaryIONB = valueChange.primaryIONB;
        this.fdSvc.data.formData.investmentTeam.regionalHead = valueChange.regionalHead;
        this.fdSvc.data.formData.investmentTeam.globalHead = valueChange.globalHead;
        this.fdSvc.data.formData.investmentTeam.primaryIOP = valueChange.primaryIOP;
        this.fdSvc.data.formData.investmentTeam.investmentLeader = valueChange.investmentLeader;
        this.fdSvc.data.formData.investmentTeam.creditOfficer = valueChange.creditOfficer
      }

      this.fdSvc.data.formData.team.csoDirector = valueChange.csoDirector;
      this.fdSvc.data.formData.team.csoLeadIo = valueChange.csoLeadIo;
      this.fdSvc.data.formData.team.csoSecondIo = valueChange.csoSecondIo;
      this.fdSvc.data.formData.team.csoLawyer = valueChange.csoLawyer;

      this.fdSvc.data.formData.lessonSnippet = valueChange.lessonSummary;
      this.fdSvc.data.formData.projectOverview = valueChange.projectOverview;
      this.fdSvc.data.formData.summarySponsor = valueChange.sponsorSummary;
      this.fdSvc.data.formData.summaryInvestment = valueChange.investmentSummary;
      this.fdSvc.data.formData.summarySecurity = valueChange.securitySummary;
      this.fdSvc.data.formData.transferReason = valueChange.transferReason;
      console.log({'formData: ': this.fdSvc}, {'valueChange: ': valueChange}, {'formGroup: ': this.formGroup});
    })
  }

}
