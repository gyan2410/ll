import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatRadioChange } from '@angular/material/radio';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, Observable, Subject, take, takeUntil } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { SharePointDataService } from 'src/app/services/sharepointdata.service';
import { TaxonomyService } from 'src/app/services/taxonomy.service';
import { UtilitiesService } from 'src/app/services/utilities.service';
import { AppMetaDataField, AppStateData, AppStates } from 'src/types/AppData';
import { SPTerm } from 'src/types/SPTaxonomy';
import { FinancialInstrument } from '../../../types/FinancialInstrument';

export interface RiskInfo {
  id: string;
  defaultLabel: string;
  details: string;
  riskLevel: string;
  identified: boolean;
  materialized: boolean;
  structure: boolean;
  portfolio: boolean;
}

@Component({
  selector: 'app-risks',
  templateUrl: './risks.component.html',
  styleUrls: ['./risks.component.scss']
})
export class RisksComponent implements OnInit, OnDestroy {
  unsubscribe$ = new Subject<boolean>();
  currState: AppStateData;
  taxObs$!: Observable<any>;
  riskLevels = [{ name: "Low" }, { name: "Normal" }, { name: "High" }];
  selectedIndex!: number;
  formGroup: FormGroup;
  showSecurityPerfectionDetails = false;
  natureOfSecurity = [
    {
      name: "Lien/Charge on Fixed Assets",
      value: "Lien/Charge on Fixed Assets"
    },
    {
      name: "Lien/Charge on Movable Assets",
      value: "Lien/Charge on Movable Assets"
    },
    {
      name: "Share Pledge",
      value: "Share Pledge"
    },
    {
      name: "Other (please specify)",
      value: "Other Security"
    },
    {
      name: "No Security",
      value: "None"
    }
  ];
  exitAlternatives = [
    { name: "IPO", value: "IPO" },
    { name: "Put Option", value: "Put Option" },
    { name: "Sale of Equity to Financial Investor", value: "Sale of Equity to Financial Investor" },
    { name: "Sale of Equity to Strategic Investor", value: "Sale of Equity to Strategic Investor" },
    { name: "Settlement", value: "Settlement" },
    { name: "Other (please specify)", value: "Other" },
    { name: "No Exit", value: "None" }
  ];
  exitOptionIssues = [
    {
      name: "Equity in Public/Private Company",
      value: "Equity in Public/Private Company"
    },
    {
      name: "Liquidity of Equity",
      value: "Liquidity of Equity"
    },
    {
      name: "Put Option Structure",
      value: "Put Option Structure"
    },
    {
      name: "Return Characteristics",
      value: "Return Characteristics"
    },
    {
      name: "Other (please specify)",
      value: "Other Exit"
    },
    {
      name: "No Issues",
      value: "None"
    }
  ];
  securityLoanDetails = [
    { name: "B loans", value: "B loans" },
    { name: "Parallel Loans", value: "Parallel Loans" },
    { name: "MCPP", value: "MCPP" },
    { name: "AMC", value: "AMC" }
  ];
  relevantSupportTaxId = this.utilService.GetEnvValue('relevantSupport').termStoreId;
  interactionNote = '';

  constructor(public fdSvc: FormDataService, private activatedRoute: ActivatedRoute, private taxonomy: TaxonomyService, private fb: FormBuilder, private router: Router, private spDataService: SharePointDataService, private utilService: UtilitiesService) {
    this.router.events.pipe(takeUntil(this.unsubscribe$)).subscribe(routeEvent => {
      if (routeEvent instanceof NavigationStart) {
        this.fdSvc.data.stateData.RisksController = this.formGroup.status;
      }
    })
    this.fdSvc.data.risksDisplayPanel = [0, 0, 0, 0, 0];

    this.currState = this.fdSvc.data.stateData;
    this.currState.routeProjectType = this.activatedRoute.snapshot.params['type'];
    this.currState.routeProjectId = this.activatedRoute.snapshot.params['id'];
    this.fdSvc.data.stateData.routeCurr = AppStates.risks;
    this.currState.routeNext = this.activatedRoute.snapshot.data['next'];
    this.currState.routePrev = this.activatedRoute.snapshot.data['prev'];

    let currForm = this.fdSvc.data.formData;
    this.formGroup = this.fb.group({
      warrantExercised: [currForm.warrantExercised],
      fiDetailsOther: [currForm.financialInstrumentOtherDetails],
      risks: this.fb.array([]),
      financialInstruments: this.fb.group({}),
      securityTypes: this.fb.group({}),
      securityTypeDetails: [currForm.securityTypeDetails],
      securityPerfected: [currForm.securityPerfected],
      securityPerfectionStatus: [currForm.securityPerfectionStatus],
      exitAlternatives: this.fb.group({}),
      exitAlternativesOtherDetails: [currForm.exitAlternativesOtherDetails],
      exitOptionIssues: this.fb.group({}),
      exitOptionOtherSpecification: [currForm.exitOptionOtherSpecification],
      securityTypeOtherSpecification: this.fb.group({}),
      relevantSupportOther: [currForm.relevantSupportOther]
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
  }

  initFormValues() {
    let currForm = this.fdSvc.data.formData;
    this.showSecurityPerfectionDetails = currForm.securityPerfected === 'No' || currForm.securityPerfected === 'Partial';
    if (currForm.riskFactorsInfo) {
      currForm.riskFactorsInfo.forEach(risk => this.addRiskInfo(risk));
    }
    if (!this.fdSvc.data.financialInstruments) {
      this.spDataService.loadFinancialInstruments().pipe(take(1)).subscribe(results => {
        this.fdSvc.data.financialInstruments = results;
        this.initFinancialInstruments(results);
      })
    } else {
      this.initFinancialInstruments(this.fdSvc.data.financialInstruments);
    }
    this.natureOfSecurity.forEach(nosItem => {
      let selected = currForm.selectedSecurityTypes.indexOf(nosItem.value) > -1;
      let stG = this.formGroup.controls['securityTypes'] as FormGroup;
      stG.addControl(nosItem.name, new FormControl(selected));
    });
    this.exitAlternatives.forEach(eaItem => {
      let selected = currForm.selectedExitAlternatives.indexOf(eaItem.value) > -1;
      let eaG = this.formGroup.controls['exitAlternatives'] as FormGroup;
      eaG.addControl(eaItem.name, new FormControl(selected));
    });
    this.exitOptionIssues.forEach(eoItem => {
      let selected = currForm.selectedExitOptions.indexOf(eoItem.value) > -1;
      let eoG = this.formGroup.controls['exitOptionIssues'] as FormGroup;
      eoG.addControl(eoItem.name, new FormControl(selected));
    });
    this.securityLoanDetails.forEach(slItem => {
      let selected = currForm.securityTypeOtherSpecification.indexOf(slItem.value) > -1;
      let slG = this.formGroup.controls['securityTypeOtherSpecification'] as FormGroup;
      slG.addControl(slItem.name, new FormControl(selected));
    })
  }

  ngOnInit(): void {
    this.taxObs$ = this.taxonomy.getAllTerms(this.utilService.GetEnvValue('riskFactors').termStoreId);
    
    this.initFormValues();

    this.formGroup.valueChanges.pipe(
      distinctUntilChanged(),
      debounceTime(500),
      takeUntil(this.unsubscribe$)
    ).subscribe(valueChange => {
      console.log({ 'formData: ': this.fdSvc }, { 'valueChange: ': valueChange }, { 'formGroup: ': this.formGroup });
      let currForm = this.fdSvc.data.formData;
      if (valueChange.risks) {
        currForm.riskFactorsInfo = [...valueChange.risks];
      }
      if (valueChange.financialInstruments) {
        let keys = Object.keys(valueChange.financialInstruments);
        currForm.selectedFinancialInstruments = keys.filter(key => valueChange.financialInstruments[key] === true);
      }
      currForm.warrantExercised = valueChange.warrantExercised;
      currForm.securityTypeDetails = valueChange.securityTypeDetails;
      currForm.securityPerfected = valueChange.securityPerfected;
      currForm.securityPerfectionStatus = valueChange.securityPerfectionStatus;
      currForm.financialInstrumentOtherDetails = valueChange.fiDetailsOther;
      currForm.exitAlternativesOtherDetails = valueChange.exitAlternativesOtherDetails;
      currForm.exitOptionOtherSpecification = valueChange.exitOptionOtherSpecification;
      currForm.relevantSupportOther = valueChange.relevantSupportOther;
    })
  }

  initFinancialInstruments(fiItems: Array<FinancialInstrument>) {
    fiItems.forEach(fiItem => {
      let selected = this.fdSvc.data.formData.selectedFinancialInstruments.indexOf(fiItem.Title) > -1;
      let fiG = this.formGroup.controls['financialInstruments'] as FormGroup;
      fiG.addControl(fiItem.Title, new FormControl(selected));
      if (selected) {
        this.fdSvc.data.risksDisplayPanel[parseInt(fiItem.SecurityType, 10)] += 1;
      }
    })
  }

  addRiskInfo(riskInfo: RiskInfo) {
    if (!this.fdSvc.data.formData.riskFactorsInfo) {
      this.fdSvc.data.formData.riskFactorsInfo = [];
    }
    if (this.fdSvc.data.formData.riskFactorsInfo) {
      const control = this.formGroup.controls['risks'] as FormArray<FormGroup<any>>;
      const newRisk = this.fb.group({
        id: [riskInfo.id],
        defaultLabel: [riskInfo.defaultLabel],
        details: [riskInfo.details, Validators.required],
        riskLevel: [riskInfo.riskLevel],
        identified: [riskInfo.identified],
        materialized: [riskInfo.materialized],
        structure: [riskInfo.structure],
        portfolio: [riskInfo.portfolio]
      });
      control.push(newRisk);
    }
  }

  get dynamicRisks() {
    return this.formGroup.get('risks') as FormArray<FormGroup<any>>;
  }

  get fi() {
    return this.formGroup.get('financialInstruments') as FormGroup;
  }

  termAdded(chip: AppMetaDataField) {
    if (!this.fdSvc.data.formData.riskFactorsInfo) {
      this.fdSvc.data.formData.riskFactorsInfo = [];
    }
    if (this.fdSvc.data.formData.riskFactorsInfo) {
      const control = this.formGroup.controls['risks'] as FormArray<FormGroup<any>>;
      const newRisk = this.fb.group({
        id: [chip.id],
        defaultLabel: [chip.defaultLabel],
        details: ['', Validators.required],
        riskLevel: [''],
        identified: [false],
        materialized: [false],
        structure: [false],
        portfolio: [false]
      });
      control.push(newRisk);
      this.selectedIndex = control.length - 1;
    }
  }

  termRemoved(data: {index: number, term: AppMetaDataField}) {
    if (this.fdSvc.data.formData.riskFactorsInfo && data.index < this.fdSvc.data.formData.riskFactorsInfo.length) {
      this.fdSvc.data.formData.riskFactorsInfo.splice(data.index, 1);
      this.dynamicRisks.removeAt(data.index);
    }
  }

  termSelected(data: {index: number, term: AppMetaDataField}) {
    this.selectedIndex = data.index;
  }

  removeTab(index: number) {
    this.fdSvc.data.formData.riskFactorsInfo.splice(index, 1);
    let fbArr = this.formGroup.controls['risks'] as FormArray;
    fbArr.removeAt(index);
  }

  toggle(item: any, list: Array<any>) {
    var noneIndex = list.indexOf('None');
    if (item.value === 'None' && noneIndex === -1) {
      list.length = 0;
    } else if (item.value !== 'None' && noneIndex > -1) {
      list.splice(noneIndex, 1);
    }
    var idx = list.indexOf(item.value)
    idx > -1 ? list.splice(idx, 1) : list.push(item.value);
  }

  toggleFinancialInstrument(fiItem: FinancialInstrument) {
    var index = this.fdSvc.data.formData.selectedFinancialInstruments.indexOf(fiItem.Title);
    if (index > -1) {
      Math.max(0, this.fdSvc.data.risksDisplayPanel[parseInt(fiItem.SecurityType, 10)] -= 1);
    } else {
      this.fdSvc.data.risksDisplayPanel[parseInt(fiItem.SecurityType, 10)] += 1;
    }
  }

  toggleSecurityType(item: any) {
    this.toggle(item, this.fdSvc.data.formData.selectedSecurityTypes);
    let stG = this.formGroup.get('securityTypes') as FormGroup;
    if (item.value === 'None') {
      let stGKeys = Object.keys(stG.controls);
      stGKeys.forEach(key => (key !== 'No Security') ? stG.controls[key].setValue(false) : null);
    } else {
      stG.controls['No Security'].setValue(false);
    }
  }

  toggleSecurityPerfected(event: MatRadioChange) {
    this.showSecurityPerfectionDetails = event.value === 'No' || event.value === 'Partial';
    if (!this.showSecurityPerfectionDetails) {
      this.formGroup.controls['securityPerfectionStatus'].setValue('');
    }
  }

  toggleExitAlt(item: any) {
    this.toggle(item, this.fdSvc.data.formData.selectedExitAlternatives);
    let eaG = this.formGroup.get('exitAlternatives') as FormGroup;
    if (item.value === 'Other') {
      this.formGroup.controls['exitAlternativesOtherDetails'].setValue('');
      eaG.controls['No Exit'].setValue(false);
    } else if (item.value === 'None') {
      let eaGKeys = Object.keys(eaG.controls);
      eaGKeys.forEach(key => (key !== 'No Exit') ? eaG.controls[key].setValue(false) : null);
      this.formGroup.controls['exitAlternativesOtherDetails'].setValue(null);
    } else {
      eaG.controls['No Exit'].setValue(false);
    }
  }

  toggleExitOption(item: any) {
    this.toggle(item, this.fdSvc.data.formData.selectedExitOptions);
    let eoG = this.formGroup.get('exitOptionIssues') as FormGroup;
    if (item.value === 'Other Exit') {
      this.formGroup.controls['exitOptionOtherSpecification'].setValue('');
      eoG.controls['No Issues'].setValue(false);
    } else if (item.value === 'None') {
      let eoGKeys = Object.keys(eoG.controls);
      eoGKeys.forEach(key => (key !== 'No Issues') ? eoG.controls[key].setValue(false) : null);
      this.formGroup.controls['exitOptionOtherSpecification'].setValue(null);
    } else {
      eoG.controls['No Issues'].setValue(false);
    }
  }

  toggleSecurityLoanDetails(item: any) {
    this.toggle(item, this.fdSvc.data.formData.securityTypeOtherSpecification);
  }

  findSupportIndex(value: string) {
    return this.fdSvc.data.formData.relevantSupport.findIndex(item => item.defaultLabel === value);
  }
}
