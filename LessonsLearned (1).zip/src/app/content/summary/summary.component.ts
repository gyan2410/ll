import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { take } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { LessonsLearnedService } from 'src/app/services/lessonslearned.service';
import { AppAttachmentFile, AppStateData, AppStates } from 'src/types/AppData';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {
  currState: AppStateData;
  @ViewChild('attachmentDialog') attachmentDialog!: TemplateRef<HTMLElement>;
  @ViewChild('fileUpload') fileUpload!: ElementRef;
  @ViewChild('confirmCopyDialog') confirmCopyDialog!: TemplateRef<HTMLElement>;
  interactionNote!: string;

  constructor(public fdSvc: FormDataService, private activatedRoute: ActivatedRoute, private matDialog: MatDialog, private lessonService: LessonsLearnedService, private router:Router) {
    this.currState = this.fdSvc.data.stateData;
    this.currState.routeProjectType = this.activatedRoute.snapshot.params['type'];
    this.currState.routeProjectId = this.activatedRoute.snapshot.params['id'];
    this.fdSvc.data.stateData.routeCurr = AppStates.summary;
    this.currState.routeNext = this.activatedRoute.snapshot.data['next'];
    this.currState.routePrev = this.activatedRoute.snapshot.data['prev'];
    this.currState.allCompleted = this.fdSvc.data.stateData.DetailsController === 'VALID' &&
      this.fdSvc.data.stateData.RisksController === 'VALID' &&
      this.fdSvc.data.stateData.SponsorController === 'VALID' &&
      this.fdSvc.data.stateData.StrategyController === 'VALID' &&
      this.fdSvc.data.stateData.LessonsController === 'VALID';
  }

  ngOnInit(): void {}

  deleteAttachment(attachment: AppAttachmentFile, attachmentIndex: number) {
    let currForm = this.fdSvc.data.formData;

    let dlgRef = this.matDialog.open(this.attachmentDialog, {
      data: {
        fileName: attachment.fileName
      }
    })
    dlgRef.afterClosed().pipe(take(1)).subscribe(result => {
      if (result) {
        var notAttached = attachment.url === null || attachment.url === '';
        var uploadIndex = -1;
        if (currForm.attachmentsToUpload) {
          uploadIndex = currForm.attachmentsToUpload.findIndex(attachment => attachment.name === attachment.fileName);
        }
        if (attachment.isLessonImage) {
          currForm.lessonImageUrl = '';
        }
        currForm.attachments.splice(attachmentIndex, 1);
        if (notAttached) {
          this.fdSvc.data.formData.attachmentsToUpload.splice(uploadIndex, 1);
          this.fileUpload.nativeElement.value = '';
        } else {
          this.lessonService.deleteAttachment(attachment.fileName).pipe(take(1)).subscribe();
        }
      }
    })
  }

  isImageFile(fileUrl: string) {
    let imageExtentionTypes = ['.jpg', '.jpeg', '.gif', '.png'];
    return imageExtentionTypes.some(ext => fileUrl.toLowerCase().indexOf(ext) > -1);
  }

  setLessonImage(attachment: AppAttachmentFile, attachmentIndex: number) {
    if (!attachment.isLessonImage) {
      this.fdSvc.data.formData.lessonImageUrl = undefined;
    } else {
      let existingLessonImageIndex = this.fdSvc.data.formData.attachments.findIndex(file => file.url === this.fdSvc.data.formData.lessonImageUrl);
      if (existingLessonImageIndex >= 0) {
        this.fdSvc.data.formData.attachments[existingLessonImageIndex].isLessonImage = false;
      }
      this.fdSvc.data.formData.lessonImageUrl = this.fdSvc.data.formData.attachments[attachmentIndex].url;
    }
  }

  setLessonPreviewImage(attachment: AppAttachmentFile, attachmentIndex: number) {
    if (!attachment.isLessonPreviewImage) {
      this.fdSvc.data.formData.lessonPreviewImageUrl = undefined;
    } else {
      let existingLessonImageIndex = this.fdSvc.data.formData.attachments.findIndex(file => file.url === this.fdSvc.data.formData.lessonPreviewImageUrl);
      if (existingLessonImageIndex >= 0) {
        this.fdSvc.data.formData.attachments[existingLessonImageIndex].isLessonPreviewImage = false;
      }
      this.fdSvc.data.formData.lessonPreviewImageUrl = this.fdSvc.data.formData.attachments[attachmentIndex].url;
    }
  }

  fileUploaded(event: Event) {
    let eventTarget = event.target as HTMLInputElement;
    if (!this.fdSvc.data.formData.attachmentsToUpload) {
      this.fdSvc.data.formData.attachmentsToUpload = [];
    }
    let fileNameArray = this.fdSvc.data.formData.attachments.map(item => item.fileName);

    if (eventTarget.files?.length) {
      for (var i = 0; i < eventTarget.files?.length; i++) {
        if (fileNameArray.indexOf(eventTarget.files[i].name) < 0) {
          this.fdSvc.data.formData.attachments.push({
            fileName: eventTarget.files[i].name,
            url: '',
            isLessonImage: false,
            isLessonPreviewImage: false
          });
          this.fdSvc.data.formData.attachmentsToUpload.push(eventTarget.files[i]);
        }
      }
    }
  }

  copyLessonData() {
    let oldUpdateUri = this.fdSvc.data.formData.updateUri;
    let oldUpdateType = this.fdSvc.data.formData.updateType;
    this.fdSvc.data.formData.accessibility = (this.fdSvc.data.formData.accessibility === 'internal') ? 'official' : 'internal';
    let dialogRef = this.matDialog.open(this.confirmCopyDialog);
    dialogRef.afterClosed().pipe(take(1)).subscribe(confirm => {
      if (confirm) {
        this.lessonService.findOrCreateLessonLearned(true, false).pipe(take(1)).subscribe(result => {
          this.fdSvc.data.formData.updateUri = result.__metadata.uri;
          this.fdSvc.data.formData.updateType = result.__metadata.type;
          this.lessonService.saveLessonLearned(false).pipe(take(1)).subscribe(result => {
            this.finalizeCopy(oldUpdateUri, oldUpdateType || '');
          }) 
        })
      }
    })
  }

  finalizeCopy(updateUri: string, updateType: string) {
    this.fdSvc.data.formData.updateUri = updateUri;
    this.fdSvc.data.formData.updateType = updateType;
    this.fdSvc.data.formData.accessibility = (this.fdSvc.data.formData.accessibility === 'internal') ? 'official' : 'internal';
  }

  routeToPreview() {
    return `/render/${this.fdSvc.data.formData.accessibility}/${this.fdSvc.data.formData.projectId}`;
  }
}
