import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InteractiveNotesResolver } from 'src/app/resolvers/interactivenotes.resolver';
import { PersonDataResolver } from 'src/app/resolvers/persondata.resolver';
import { FormComponent } from './form.component';

const routes: Routes = [
  {
    path: '',
    component: FormComponent,
    loadChildren: () => import('../main/main.module').then(m => m.MainModule),
    resolve: {
      interactionData: InteractiveNotesResolver,
      spPersonData: PersonDataResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormRoutingModule { }
