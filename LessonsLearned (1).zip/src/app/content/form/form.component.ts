import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Title } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { take, catchError, of } from 'rxjs';
import { FormDataService } from 'src/app/services/formdata.service';
import { LessonsLearnedService } from 'src/app/services/lessonslearned.service';
import { UtilitiesService } from 'src/app/services/utilities.service';
import { AppStateData, AppStates } from 'src/types/AppData';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
  @ViewChild('exitDialog') exitDialog!: TemplateRef<HTMLElement>;
  @ViewChild('savedDialog') savedDialog!: TemplateRef<HTMLElement>;
  @ViewChild('saveDialog') saveDialog!: TemplateRef<HTMLElement>;
  @ViewChild('submitDialog') submitDialog!: TemplateRef<HTMLElement>;

  
  appStates = AppStates;
  currState: AppStateData;
  siteUrl: string;

  constructor(public fdSvc: FormDataService, private utilities: UtilitiesService, private router: Router, private activatedRoute: ActivatedRoute, private matDialg: MatDialog, private lessonService: LessonsLearnedService, private title: Title) {
    this.currState = this.fdSvc.data.stateData;
    this.siteUrl = this.utilities.siteCollectionUrl('');
  }

  ngOnInit(): void {}

  nextState(event: MouseEvent, action: string) {
    if (this.fdSvc.data.stateData) {
      let route = (action === 'prev') ? this.fdSvc.data.stateData.routePrev : this.fdSvc.data.stateData.routeNext;
      let type = this.fdSvc.data.stateData.routeProjectType;
      let id = this.fdSvc.data.stateData.routeProjectId;
      let formPath = this.activatedRoute.snapshot.firstChild?.url[0].path;
      this.router.navigate([route, type, id], { relativeTo: this.activatedRoute })
    }
  }

  cancel() {
    let dialogRef = this.matDialg.open(this.exitDialog);
    dialogRef.afterClosed().pipe(take(1)).subscribe(result => {
      if(result === true) {
        if (this.fdSvc.data.formData.saveStatus === "Unsaved") {
          this.lessonService.deleteLessonLearned().pipe(take(1)).subscribe(() => {
            this.title.setTitle('Lessons Learned');
            this.fdSvc.resetData();
            this.router.navigate(['/form'], { relativeTo: this.activatedRoute });
          });
        } else {
          this.title.setTitle('Lessons Learned');
          this.fdSvc.resetData();
          this.router.navigate(['/form'], { relativeTo: this.activatedRoute });
        }
      }
    })
  }

  save(submit: boolean) {
    let dialogRef = this.matDialg.open(this.saveDialog, {
      disableClose: true
    });
    this.lessonService.saveLessonLearned(submit).pipe(
      take(1),
      catchError(err => {
        console.error(err);
        return of(null);
      })).subscribe({
        next: (result) => {
          console.log(result);
          dialogRef.close();
          if (!submit) {
            let savedRef = this.matDialg.open(this.savedDialog, {
              disableClose: true
            })
            savedRef.afterClosed().pipe(take(1)).subscribe(result => {
              if (!result) {
                this.title.setTitle('Lessons Learned');
                this.fdSvc.resetData();
                window.location.href = this.siteUrl;
              }
            })
          }
          else {
            let submitRef = this.matDialg.open(this.submitDialog, {
              disableClose: true
            })
            submitRef.afterClosed().pipe(take(1)).subscribe(result => {              
              this.title.setTitle('Lessons Learned');
              this.fdSvc.resetData();
              window.location.href = this.siteUrl;
            })
          }
        },
        error: (err) => {
          console.error(err);
        }
      })
  }
}
