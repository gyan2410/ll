import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, Observable, Subject, takeUntil } from 'rxjs';
import { AppconstantsService } from 'src/app/services/appconstants.service';
import { FormDataService } from 'src/app/services/formdata.service';
import { TaxonomyService } from 'src/app/services/taxonomy.service';
import { UtilitiesService } from 'src/app/services/utilities.service';
import { AppStateData, AppStates } from 'src/types/AppData';
import { SPTerm } from 'src/types/SPTaxonomy';

@Component({
  selector: 'app-sponsor',
  templateUrl: './sponsor.component.html',
  styleUrls: ['./sponsor.component.scss']
})
export class SponsorComponent implements OnInit, OnDestroy {
  unsubscribe$ = new Subject<boolean>();
  currState: AppStateData;
  formGroup: FormGroup;
  interactionNote = '';
  taxObs$!: Observable<any>;
  clientExpOptions = [{ "name": "Positive" }, { "name": "Neutral" }, { "name": "Negative" }];

  constructor(public fdSvc: FormDataService, private activatedRoute: ActivatedRoute, private router: Router, private fb: FormBuilder, private taxonomy: TaxonomyService, private utilService: UtilitiesService) {
    this.router.events.pipe(takeUntil(this.unsubscribe$)).subscribe(routeEvent => {
      if (routeEvent instanceof NavigationStart) {
        this.fdSvc.data.stateData.SponsorController = this.formGroup.status;
      }
    })
    
    this.currState = this.fdSvc.data.stateData;
    this.currState.routeProjectType = this.activatedRoute.snapshot.params['type'];
    this.currState.routeProjectId = this.activatedRoute.snapshot.params['id'];
    this.fdSvc.data.stateData.routeCurr = AppStates.sponsor;
    this.currState.routeNext = this.activatedRoute.snapshot.data['next'];
    this.currState.routePrev = this.activatedRoute.snapshot.data['prev'];

    let currForm = this.fdSvc.data.formData;
    this.formGroup = this.fb.group({
      clientExperience: [currForm.clientExperience, Validators.required],
      illegalActions: [currForm.illegalActions, Validators.required],
      clientExperienceDetails: [currForm.clientExperienceDetails, Validators.required],
      breachSuspicions: [currForm.breachSuspicions, Validators.required]
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next(true);
  }

  ngOnInit(): void {
    this.taxObs$ = this.taxonomy.getAllTerms(this.utilService.GetEnvValue('investmentHistory').termStoreId);

    this.formGroup.valueChanges.pipe(
      distinctUntilChanged(),
      debounceTime(500),
      takeUntil(this.unsubscribe$)
    ).subscribe(valueChange => {
      console.log({ 'formData: ': this.fdSvc }, { 'valueChange: ': valueChange }, { 'formGroup: ': this.formGroup });
      let currForm = this.fdSvc.data.formData;
      currForm.clientExperience = valueChange.clientExperience;
      currForm.clientExperienceDetails = valueChange.clientExperienceDetails;
      currForm.illegalActions = valueChange.illegalActions;
      currForm.breachSuspicions = valueChange.breachSuspicions;
    });
  }
}
