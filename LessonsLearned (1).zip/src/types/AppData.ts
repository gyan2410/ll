import { RiskInfo } from "src/app/content/risks/risks.component";
import { PartnerDetails } from "./PartnerDetails";
import { SPMetaDataField } from "./SPLessonItem";

export enum AppStates {
  details = 'details',
  risks = 'risks',
  sponsor = 'sponsor',
  strategy = 'strategy',
  lessons = 'lessons',
  summary = 'summary',
  form = 'form'
}

export interface AppAttachmentFile {
  fileExtension?: string;
  fileName: string;
  url: string | null;
  isLessonImage: boolean;
  isLessonPreviewImage: boolean;
}

export interface AppMetaDataField {
  id: string;
  defaultLabel: string;
  parentName: string;
}

export interface AppFormData {
  accessibility: string;
  attachments: Array<AppAttachmentFile>;
  attachmentsToUpload: Array<any>;
  author: string | null;
  authorEmail?: string;
  authorName?: string;
  breachSuspicions?: string;
  clientExperience?: string;
  clientExperienceDetails?: string;
  CountryZoom?: string;
  CountryCoords?: string;
  csoLessonsLearned?: string;
  curator: string | null;
  exitAlternativesOtherDetails?: string | null;
  exitOptionOtherSpecification?: string | null;
  financialInstrumentOtherDetails?: string;
  ifcLessonsLearned?: string;
  illegalActions?: string;
  internalUse?: boolean;
  investmentHistory: Array<AppMetaDataField>;
  investmentTeam: AppInvestmentTeam;
  iPortalData: PartnerDetails;
  legacyLesson?: boolean;
  lessonCountry?: string;
  lessonImageUrl?: string | null;
  lessonPreviewImageUrl?: string | null;
  lessonRegion?: string;
  lessonSector?: string;
  lessonSnippet?: string;
  lessonTitle?: string;
  lessonWeight?: number;
  projectId?: string;
  projectOverview?: string;
  publicUse?: boolean;
  recoveryMetric?: string;
  recoveryStrategies: Array<AppMetaDataField>;
  recoveryStrategiesInfo: { [key: string]: any };
  recoveryStrategyDetails?: string;
  relevantSupport: Array<AppMetaDataField>;
  relevantSupportOther?: string;
  riskFactors: Array<AppMetaDataField>;
  riskFactorsInfo: Array<RiskInfo>;
  saveStatus?: string;
  securityPerfected?: string;
  securityPerfectionStatus?: string;
  securityTypeDetails?: string;
  securityTypeOtherSpecification: Array<string>;
  selectedExitAlternatives: Array<string>;
  selectedExitOptions: Array<string>;
  selectedFinancialInstruments: Array<string>;
  selectedSecurityTypes: Array<string>;
  summaryInvestment?: string;
  summarySecurity?: string;
  summarySponsor?: string;
  team: AppTeamData;
  transferReason?: string;
  updateType?: string;
  updateUri: string;
  warrantExercised?: string;
  workoutOutcomes: Array<AppMetaDataField>;
  workoutOutcomesInfo: { [key: string]: any };
}

export interface AppStateData {
  allCompleted?: boolean;
  DetailsController?: string;
  LessonsController?: string;
  RisksController?: string;
  routeCurr?: AppStates;
  routeNext?: AppStates;
  routePrev?: AppStates;
  routeProjectId?: string;
  routeProjectType?: string;
  SponsorController?: string;
  StrategyController?: string;
  SummaryController?: string;
}

export interface AppTeamData {
  csoDirector: string | null;
  csoLawyer: string | null;
  csoLeadIo: string | null;
  csoSecondIo: string | null;
  industryDirector: string | null;
  regionalDirector: string | null;
  transactionLeader: string | null;
}

export interface AppInvestmentTeam {
  creditOfficer: string | null;
  globalHead: string | null;
  investmentLeader: string | null;
  portfolioIO: string | null;
  primaryIONB: string | null;
  primaryIOP: string | null;
  regionalHead: string | null;
}

export interface AppData {
  financialInstruments: Array<any> | null;
  formData: AppFormData;
  interactionData?: any;
  projectData: AppProjectData;
  risksDisplayPanel: Array<number>;
  stateData: AppStateData;
}

export interface AppProjectData {
  accessLevel: string;
  clientId: number;
  error: string;
  lessonCountry: string;
  lessonRegion: string;
  lessonSector: string;
  lessonTitle: string;
  loadProjectError: boolean;
  projectId: string;
  projectIdOrTitle: string;
}