export interface ProjectMember
{
    __metadata: {
        id: string;
        uri: string;
        type: string
    },
    ProjectMember: {
        __metadata: {
            id: string;
            type: string;
        },
        Title: string;
    },
    ProjectMemberId: number;
    ProjectRole: string;
    Title: string;
}