export interface InteractionNote {
    __metadata: {
        id: string;
        uri: string;
        type: string;
    },
    Title: string;
    Section: string;
    InteractionNote: string;
}