export interface iPortalProjectBasicInfo {
    project_name: string;
    project_test_name: string;
    project_short_name: string;
    project_desc: string;
    parent_proj_id: number;
    parent_proj_short_name: string;
    parent_proj_cat_code: string;
    parent_proj_rel_code: string;
    parent_proj_rel_name: string;
    client_id: number;
    client_legal_name: string;
    client_short_name: string;
    industry_cluster_id: string;
    industry_cluster_nme: string;
    country: string;
    region: string;
    project_tier_code: string;
    project_tier: string;
    sme_type: string;
    envelope_type: string;
    framework_type: string;
    covid_ida: string;
    sector_code: string;
    sector_name: string;
    partner_sector_code: string;
    partner_sector_name: string;
    owning_dept_div: string;
    industry_dept_name: string;
    regional_dept_name: string | null;
    category_code: string;
    category_name: string;
    sub_category_code: string;
    sub_category_name: string;
    ind_grp_sector_category: string;
    approval_proc_code: string;
    approval_proc_name: string;
    ida_fcs_flag: string;
    rel_to_adv_project: string;
    related_adv_projects: any[];
    partner_tier: string | null;
    partner_tier_calc_method: string | null;
    green_field_code: string;
    green_field_name: string;
    sponsors: any[];
    project_classification_code: string | null;
    project_classification_nme: string | null;
    impl_department_nme: string | null;
    orginating_dept_nme: string | null;
    project_type_code: string | null;
    project_type_nme: string | null;
    regionGlobalInd: string | null;
    covidFlag: string;
    right_to_nominate_ind: string;
    right_to_appoint_ind: string;
    cdbFlag: string;
    blendedFinanceFlag: string;
    blendedFinanceFacility: string | null;
    asop_client_details: any[]
}

export interface iPortalProjectDetails {
    product_types: string | null;
    product_category_details: string | null;
    environement_category: string;
    linked_projects: string;
    ifc_fund_facility: string | null;
    ifc_gross_amt_usd: number;
    ifc_net_amt_usd: number;
    project_size_usd_amount: number;
    total_inv_products: string | null;
    energy_efficiency: string;
    renewable_energy: string;
    loan_rating: string;
    loan_rating_date: string;
    equity_rating: string;
    equity_rating_date: string;
    credit_risk_profile_key: number;
    rating: string | null;
    rating_date: string | null;
    transaction_leader: string;
    transaction_leader_email: string;
    portfolio_officer: string;
    portfolio_officer_email: string;
    primary_IO_newBusiness: string;
    primary_IO_newBusiness_email: string;
    primary_IO_portfolio: string;
    primary_IO_portfolio_email: string;
    relationship_manager: string | null;
    disb_target_date: string;
    icr_date: string | null;
    approved_date: string;
    first_disb_actual_date: string;
    cso_status_code: string;
    cso_status: string;
    cso_start_date: string;
    cso_end_date: string;
    amc_prog_flag: string;
    pd_rating: string | null;
    lgd_rating: string | null;
    fund_focus_area_name: string | null;
    private_co_finance: string;
    business_area_details: any[],
    project_components_details: any[],
    paris_align_process: string | null;
    paris_align_bb1_process_opt: string | null;
    paris_align_bb2_process_opt: string | null;
    paris_align_intg_process_opt: string | null;
    paris_align_comment_txt: string | null;
}

export interface iPortalProjectIndicators {
    agri_business_ind: string;
    climate_ind: string | null;
    cross_cutting_section_flag: string;
    exp_ida_countries: string;
    exp_amt_ida_countries: string | null;
    exp_sub_prjt_ida_countries: string | null;
    exp_ida_countries_ifc_fund: string | null;
    fasttrack_ind: string;
    fragile_country_ind: string;
    fragile_year: string;
    frontier_country_ind: string;
    frontier_region: string | null;
    frountier_region_percentage: string | null;
    gender_ind: string | null;
    global_fin_crisis_ind: string;
    ifc_wb_collaboration: string;
    inclusive_business_ind: string;
    jobs_ind: string | null;
    org_reg_dept_code: string | null;
    org_reg_dept_name: string | null;
    potential_wbg_conflicts: string | null;
    pub_pri_partnership_ind: string | null;
    repeat_project_ind: string;
    repeat_sponsor_ind: string;
    short_term_finance: string;
    south_south_ind: string;
    subnational_fin_ind: string;
    stf_ind: string | null;
    infra_ind: string;
    global_health_program_ind: string | null;
    esHighRiskInd: string;
}

export interface iPortalProjectFlags {
    benificiary_types: string | null;
    ifcWB_collaboration_flag: string | null;
    jobs_flag: string | null;
    ict_flag: string | null;
    competition_flag: string | null;
    ppp_flag: string | null;
    tatf_flag: string | null;
    public_private_flag: string | null;
    gender_flag: string | null;
    climate_change_flag: any[];
    jips_flag: string | null;
}

export interface iPortalProject {
    project_id: number;
    security_class_code: string;
    security_class: string;
    stage_number: number;
    stage_name: string;
    status_code: string;
    status_name: string;
    project_basic_info: iPortalProjectBasicInfo,
    project_details: iPortalProjectDetails,
    project_indicators: iPortalProjectIndicators,
    project_flags: iPortalProjectFlags
}

export interface iPortalDataHeader {
    status: {
        code: string;
        message: string;
    },
    accessLevel: string;
    accessLevelMCPP: string;
}

export interface iPortalProjectData {
    Project: iPortalProject
}

export interface iPortalProjectResult {
    header: iPortalDataHeader,
    data: iPortalProjectData[]
}

export interface iPortalPartnerResult {
    header: iPortalDataHeader,
    data: iPortalPartnerData
}

export interface iPortalTeamResult {
    header: iPortalDataHeader,
    data: {
        team: {
            header: iPortalDataHeader,
            data: iPortalTeamData[]
        }
    }
}

export interface iPortalPartnerData {
    balanceInfo: {
        header: iPortalDataHeader;
        data: any;
    }
    basicInfo: {
        header: iPortalDataHeader;
        data: iPortalPartnerBasicInfo;
    }
    crrInfo: {
        header: iPortalDataHeader;
        data: any;
    }
    productCount: {
        header: iPortalDataHeader;
        data: any;
    }
    relatedProjects: {
        header: iPortalDataHeader;
        data: iPortalRelatedProject[];
    }
    team: {
        header: iPortalDataHeader;
        data: iPortalTeamData[];
    }
    teamInfo: {
        header: iPortalDataHeader;
        data: iPortalTeamInfoData;
    }
}

export interface iPortalPartnerBasicInfo {
    clientId: number;
    shortName: string;
    legalName: string;
    partnerType: string | null;
    primaryInd: string;
    descriptionText: string;
    certificationStatus: string;
    certificationDate: string;
    parentInstitutionNumber: number;
    partnetInstitutionName: string | null;
    tierCode: string;
    tierCalculationMethodFlag: string;
    tierName: string;
    sectorCode: string;
    sectorName: string;
    countryCode: string;
    countryName: string;
    regionCode: string;
    regionName: string;
    coverage: string;
    iddFlag: string;
    formattedIddate: string;
    following: string;
    fundingSources: string | null;
    clientCoverageTypeId: string | null;
    clientCoverageTypeName: string | null;
    certStatusCode: string;
    certStatusDesc: string;
    dnusNbr: string;
    webSiteUrlText: string | null;
    institRoles: string | null;
}

export interface iPortalRelatedProject {
    projectBalance: {
        header: iPortalDataHeader;
        data: iPortalRelatedProjectBalance
    }
    relatedProject: {
        header: iPortalDataHeader;
        data: iPortalRelatedProjectData;
    }
}

export interface iPortalRelatedProjectData {
    projectId: number;
    projectShortName: string;
    projectName: string;
    projectCategoryCode: string;
    projectCategoryName: string;
    projectSubCategoryCode: string;
    projectSubCategoryName: string;
    stageNumber: number;
    stageCode: string;
    stageShortName: string;
    stageName: string;
    projectStatusCode: string;
    projectStatusName: string;
    securityClassCode: string;
    securityClassName: string;
    countryCode: string;
    countryName: string;
    regionCode: string | null;
    regionName: string | null;
    environmentCategoryCode: string;
    environmentCategoryName: string;
    departmentCode: string | null;
    department: string | null;
    sectorCode: string;
    sectorName: string;
    industryCode: string | null;
    industryName: string | null;
    projectTierCode: string | null;
    projectTierName: string | null;
    souCode: string | null;
    souName: string | null;
    productTypeCode: string | null;
    legacyReference: string | null;
    primaryInd: string;
    clientId: number;
    clientName: string;
    relatedAsCode: string;
    relatedAsName: string;
    otherRelationDesc: string | null;
    transactionLeader: {
        accessorId: number;
        accessorName: string;
        accessorType: string | null;
        email: string;
        deptDivCode: string;
        deptDivAlphaCode: string;
        phoneNumber: string;
        activeInd: string;
    }
    parnershiStartDate: string;
    partnershipEndDate: string | null;
    partnershipKey: string;
    primary_IO_newBusiness: {
        accessorId: number;
        accessorName: string;
        accessorType: string | null;
        email: string;
        deptDivCode: string;
        deptDivAlphaCode: string;
        phoneNumber: string;
        activeInd: string;
    },
    projectStatustName: string;
}

export interface iPortalRelatedProjectBalance {
    disbursedAmt: number;
    outstandingAmt: number;
    undisbursedAmt: number;
    pipelineAmt: number;
    commitmentAmt: number;
}

export interface iPortalTeamData {
    cotegoryCode: string;
    categoryName: string;
    showPrimary: boolean;
    roles: iPortalTeamRole[]
}

export interface iPortalTeamRole {
    staffFunctionCode: string;
    staffFunctionName: string;
    primary: iPortalTeamInfo_Contact | null;
    proxies: iPortalTeamDataProxy[],
    accessLevel: string;
}

export interface iPortalTeamDataProxy {
    accessorId: number;
    accessorName: string;
    accessorType: string;
    email: string | null;
    deptDivCode: string | null;
    deptDivAlphaCode: string | null;
    phoneNumber: string | null;
    activeInd: string | null;
}

export interface iPortalTeamInfoData {
    clientLeader: iPortalTeamInfo_Contact;
    portfolioOfficer: iPortalTeamInfo_Contact;
    primary_IO_portfolio: iPortalTeamInfo_Contact;
    relationshipManager: iPortalTeamInfo_Contact;
}

export interface iPortalTeamInfo_Contact {
    accessorId: number;
    accessorName: string;
    accessorType: string;
    email: string;
    deptDivCode: string;
    deptDivAlphaCode: string;
    phoneNumber: string;
    activeInd: string;
}
