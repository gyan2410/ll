export interface WBProfileUser {
    url: string;
    id: string;
    upi: string;
    display_photo_flag: string;
    supervisor_id: string;
    supervisor_name: string;
    jobgrade: string;
    workoudesc: string;
    mgr: string;
    fname: string;
    spell: string[],
    locationcode: string;
    pre_bankexperience_displayflag: string;
    nick_name: string;
    aboutme_more: string;
    group_flag: string;
    title: string;
    titlesort: string;
    lname: string;
    jobcode_descr: string;
    workou: string;
    oucode: string;
    ou: string;
    photo_url_link: string;
    cn: string;
    notesname: string;
    id_i: string;
    inst: string[];
    original_vpu: string;
    location: string;
    vpu: string;
    full_name_ac: string;
    full_name: string;
    workoucode: string;
    oudesc: string;
    timestamp: string;
    email: string;
    mgr_upi: string;
    roomno: string;
}

export interface WBProfileUserResult {
    rows: number;
    os: string;
    page: string;
    total: string;
    peoples: {
        [key: string]: WBProfileUser
    }
}