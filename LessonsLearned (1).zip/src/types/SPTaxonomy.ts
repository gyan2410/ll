export interface SPTaxonomy {
    flatTaxonomy: Array<SPTerm>;
    taxonomy: Array<SPTerm>;
}

export interface SPTerm {
    cc: number;
    children: Array<SPTerm>;
    defaultLabel: string;
    id: string;
    isAvailable: boolean;
    isDeprecated: boolean;
    level: number;
    parentTerm: string;
    parentTermId: string;
    termSetId: string;
    synonyms?: string | null;
    expanded?: boolean;
}