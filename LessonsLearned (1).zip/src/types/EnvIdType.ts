export interface EnvType {
    [key: string]: EnvParams;
}

export interface EnvParams {
    columnId: string;
    termStoreId: string;
}

export interface EnvId {
    dev: EnvType;
    csoDev: EnvType;
    csoProd: EnvType;
    csoSPO: EnvType;
}