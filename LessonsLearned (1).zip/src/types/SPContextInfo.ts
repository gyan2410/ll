export interface SPWebContextInfo {
    WebFullUrl: string;
    SiteFullUrl: string;
    FormDigestValue: string;
    LibraryVersion: string;
    SupportedSchemaVersions: {results: string[]};
}
