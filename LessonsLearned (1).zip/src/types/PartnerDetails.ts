import { RelatedProjectData } from "./RelatedProject";

export interface PartnerDetails {
    partnerName: string | null;
    instituationNo: number;
    primarySector: string | null;
    country: string | null;
    region: string | null;
    tier: string | null;
    countryRRCode: string | null;
    countryRR: string | null;
    riskRating: string | null;
    riskRatingDate: string | null;
    productCount: any;
    outstandingAmt: number;
    disbursedAmt: number;
    undisbursedAmt: number;
    relatedProjects: RelatedProjectData[],
    team: {
        regionalHead: string | null;
        globalHead: string | null;
        creditOfficer: string | null;
        portfolioIO: string | null;
    }
}