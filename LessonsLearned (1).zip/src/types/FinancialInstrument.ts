export interface FinancialInstrument {
    __metadata: {
        id: string;
        uri: string;
        type: string;
    },
    Title: string;
    SecurityType: string;
}