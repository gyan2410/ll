export interface CountryCoordinate
{
    __metadata: {
        id: string;
        uri: string;
        type: string;
    },
    Title: string;
    Latitude: string;
    Longitude: string;
    Zoom: string;
}