export interface SPProfileUser {
    displayName: string;
    workEmail: string;
    UPI: string;
}

export interface SPUser {
    __metadata: {
        id: string;
        uri: string;
        type: string;
    },
    Groups: {
        __deferred: {
            uri: string;
        }
    },
    Id: number;
    IsHiddenInUI: boolean;
    LoginName: string;
    Title: string;
    PrincipalType: number;
    Email: string;
    IsSiteAdmin: boolean;
    UserId: {
        __metadata: {
            type: string;
        },
        NameId: string;
        NameIdIssuer: string;
    }
}