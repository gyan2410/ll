export interface SPSearchResult {
    rowItems: number;
    totalItems: number;
    items: Array<SPSearchResultItem>
}
export interface SPSearchResultItem {
    Rank: string;
    DocId: string;
    LessonCountry?: any;
    Title: string;
    RefinableIntFirst01: string;
    RefinableStringFirst21: string;
    RefinableStringFirst26: string;
    RefinableStringFirst27: string;
    RefinableStringFirst28: string;
    RefinableIntFirst00: string;
    RefinableStringFirst35: string;
    PartitionId: string;
    AAMEnabledManagedProperties: string;
    RenderTemplateId: string;
    LessonLatitude: string;
    LessonLongitude: string;
}