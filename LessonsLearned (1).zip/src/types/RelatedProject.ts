export interface RelatedProjectData {
    clientId?: number;
    clientName?: string;
    csoEndDate?: Date;
    csoStartDate?: Date;
    csoStatus?: string;
    csoStatusCode?: string;
    primaryIONewBusiness?: string;
    primaryIOPortfolio?: string;
    projectCategory?: string;
    projectCountry?: string;
    projectDisbursedAmt: number | null;
    projectFirstDisbursement?: string;
    projectGreenField?: string;
    projectId: number;
    projectIndustryGroupSector?: string;
    projectLastDisbursement?: null;
    projectName?: string;
    projectOutstandingAmt: number | null;
    projectOwningDept?: string;
    projectRegion?: string;
    projectSector?: string;
    projectShortName?: string;
    projectSubCategory?: string;
    projectTier?: string;
    projectUndisbursedAmt: number | null;
}