export interface SPMetaDataField {
    __metadata: {
        type: string;
    },
    results: SPTermField[]
}

export interface SPAttachmentFile {
    __metadata: {
        id: string;
        uri: string;
        type: string;
    },
    FileName: string;
    ServerRelativeUrl: string;
}

export interface SPAttachmentField {
    results: SPAttachmentFile[];
}

export interface SPTermField {
    Label: string;
    TermGuid: string;
    WssId: number;
}

export interface SPLessonItem {
    __metadata: {
        id: string;
        uri: string;
        type: string;
    },
    RoleAssignments: {
        __deferred: {
            uri: string;
        }
    },
    AttachmentFiles: SPAttachmentField,
    ContentType: {
        __deferred: {
            uri: string;
        }
    },
    FieldValuesAsHtml: {
        __deferred: {
            uri: string;
        }
    },
    FieldValuesAsText: {
        __deferred: {
            uri: string;
        }
    },
    FieldValuesForEdit: {
        __deferred: {
            uri: string;
        }
    },
    File: {
        __deferred: {
            uri: string;
        }
    },
    Folder: {
        __deferred: {
            uri: string;
        }
    },
    ParentList: {
        __deferred: {
            uri: string;
        }
    },
    FileSystemObjectType: number;
    Id: number;
    Title: string;
    BreachSuspicions: string | null;
    ClientExperience: string | null;
    ClientExperienceDetails: string | null;
    CSODirector: string | null;
    CSOLawyer: string | null;
    CSOLeadIo: string | null;
    CSOLessonsLearned: string | null;
    CSOSecondIo: string | null;
    ExitAlternatives: string | null;
    ExitAlternativesOtherDetails: string | null;
    ExitOptionIssue: string | null;
    ExitOptionOtherSpecification: string | null;
    FinancialInstruments: string | null;
    FinancialInstrumentsOther: string | null;
    IFCLessonsLearned: string | null;
    IllegalActions: string | null;
    IndustryDirector: string | null;
    InvestmentHistory: SPMetaDataField;
    PutOption: string | null;
    RecoveryStrategy: SPMetaDataField;
    RecoveryStrategyDetails: string | null;
    RegionalDirector: string | null;
    RelevantSupport: SPMetaDataField;
    RiskFactor: SPMetaDataField;
    SaveStatus: string | null;
    SecurityPerfected: string | null;
    SecurityPerfectionStatus: string | null;
    SecurityType: string | null;
    SecurityTypeDetails: string | null;
    SecurityTypeOtherSpecification: string | null;
    TransactionLeader: string | null;
    TransferReason: string | null;
    RisksIdentified: string | null;
    ProjectOverview: string | null;
    WarrantExercised: string | null;
    InternalUse: string | null;
    PublicDissemination: string | null;
    LessonImageUrl: string | null;
    LessonCountry: string | null;
    LessonRegion: string | null;
    LessonSector: string | null;
    LessonSnippet: string | null;
    LessonPreviewImageUrl: string | null;
    LessonTitle: string | null;
    ContentTypeId: string;
    WorkoutOutcome: SPMetaDataField;
    WorkoutOutcomeDetails: string | null;
    RecoveryStrategyInfo: string | null;
    OData__ModerationStatus: number;
    InvestmentTeam: string | null;
    iPortalData: string | null;
    SummarySponsor: string | null;
    SummaryInvestment: string | null;
    SummarySecurity: string | null;
    RecoveryMetric: string | null;
    RelevantSupportOther: string | null;
    RiskFactorDetails: string | null;
    LessonWeight: number;
    LegacyLesson: boolean;
    lstLesso: number;
    LessonAuthorId: string | null;
    LessonCuratorId: string | null;
    LessonsIndustry: string | null;
    WasApproved: string | null;
    ID: number;
    Modified: string;
    Created: string;
    AuthorId: number;
    EditorId: number;
    OData__UIVersionString: string;
    Attachments: boolean;
    GUID: string;
}