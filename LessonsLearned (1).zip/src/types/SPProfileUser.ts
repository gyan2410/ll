export interface SPUserProfileProperty {
    __metadata: {
        type: string;
    },
    Key: string;
    Value: string;
    ValueType: string;
}

export interface SPUserProfileResult
{
    __metadata: {
        id: string;
        uri: string;
        type: string;
    },
    DisplayName: string;
    UserProfileProperties: {
        results: Array<SPUserProfileProperty>
    }
}